cd /home/alumnogreibd/BDGE/HBaseTest/HBaseTest_new_me; JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64 /snap/netbeans/89/netbeans/java/maven/bin/mvn -Dexec.vmArgs= "-Dexec.args=${exec.vmArgs} -classpath %classpath ${exec.mainClass} ${exec.appArgs}" -Dexec.appArgs= -Dexec.mainClass=gal.usc.etse.mbd.bdge.hbasetest.test1 -Dexec.executable=/usr/lib/jvm/java-11-openjdk-amd64/bin/java --no-transfer-progress process-classes org.codehaus.mojo:exec-maven-plugin:3.0.0:exec
Scanning for projects...

------------------< gal.usc.etse.mbd.bdge:HBaseTest >-------------------
Building HBaseTest 1.0-SNAPSHOT
  from pom.xml
--------------------------------[ jar ]---------------------------------

--- resources:3.3.1:resources (default-resources) @ HBaseTest ---
skip non existing resourceDirectory /home/alumnogreibd/BDGE/HBaseTest/HBaseTest_new_me/src/main/resources

--- compiler:3.7.0:compile (default-compile) @ HBaseTest ---
Changes detected - recompiling the module!
Compiling 9 source files to /home/alumnogreibd/BDGE/HBaseTest/HBaseTest_new_me/target/classes
/home/alumnogreibd/BDGE/HBaseTest/HBaseTest_new_me/src/main/java/gal/usc/etse/mbd/bdge/hbasetest/DAOPeliculasHBase.java: /home/alumnogreibd/BDGE/HBaseTest/HBaseTest_new_me/src/main/java/gal/usc/etse/mbd/bdge/hbasetest/DAOPeliculasHBase.java uses unchecked or unsafe operations.
/home/alumnogreibd/BDGE/HBaseTest/HBaseTest_new_me/src/main/java/gal/usc/etse/mbd/bdge/hbasetest/DAOPeliculasHBase.java: Recompile with -Xlint:unchecked for details.

--- exec:3.0.0:exec (default-cli) @ HBaseTest ---
//Ejercio_1;

Titulo: Pirates of the Caribbean: On Stranger Tides
Id: 1865
Fecha Emision: 2011-05-14
Presupuesto: 380000000
Ingresos: 1045713802
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Captain Jack Sparrow, 85, Johnny Depp
  1, Angelica Teach, 955, Penélope Cruz
  2, Captain Edward "Blackbeard" Teach, 6972, Ian McShane
  3, Joshamee Gibbs, 2449, Kevin McNally
  4, Captain Hector Barbossa, 118, Geoffrey Rush
  5, Philip Swift, 237455, Sam Claflin
  6, Syrena, 469759, Astrid Bergès-Frisbey
  7, Scrum, 1115, Stephen Graham
  8, Lieutenant Theodore Groves, 4031, Greg Ellis
  9, Lieutenant Gillette, 1712, Damian O'Hare
  10, The Spaniard, 59129, Óscar Jaenada
  11, King George II, 10983, Richard Griffiths
  12, Captain Teague Sparrow, 1430, Keith Richards
  13, Tamara, 55901, Gemma Ward
  14, High Society Lady, 5309, Judi Dench
  15, Quartermaster, 199975, Ian Mercer
  16, Cabin Boy, 88392, Robbie Kay
  17, Ezekiel, 8399, Christopher Fairbank
  18, Garheng, 77955, Yuki Matsuzaki
  19, Purser, 83814, Steve Evets
  20, Cook, 75076, Bronson Webb
  21, Master-at-Arms, 51300, Derek Mears
  22, Gunner, 58758, Deobia Oparei
  23, King Ferdinand of the Spanish Empire, 229634, Sebastian Armesto
  24, John Carteret, 27397, Anton Lesser
  25, Prime Minister Henry Pelham, 11279, Roger Allam
  26, Salaman, 110075, Paul Bazely
  27, Derrick, 1321379, Richard Thomson
  28, Yeoman, 1310385, Danny Le Boyer
  29, Justice Smith, 1797040, Alan J. Utley-Moore
  30, Captain of the Guard, 214581, Luke Roberts
  31, English Girl, 1331023, Emilia Jones
  32, Mermaid, 1770474, Sanya Hughes
  33, Guard, 1131724, Daniel Ings
  34, Queen Anne's Pirate (uncredited), 1269611, LeJon
  35, British Sailor (uncredited), 1770475, Siegfried Peters
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Production, Producer, 770, Jerry Bruckheimer
  Sound, Sound Re-Recording Mixer, 900, Christopher Boyes
  Sound, Original Music Composer, 947, Hans Zimmer
  Writing, Screenplay, 1705, Ted Elliott
  Production, Executive Producer, 1706, Terry Rossio
  Writing, Screenplay, 1706, Terry Rossio
  Production, Executive Producer, 2444, Mike Stenson
  Production, Executive Producer, 2446, Chad Oman
  Costume & Make-Up, Costume Design, 4034, Penny Rose
  Sound, Music Supervisor, 5132, Bob Badami
  Editing, Editor, 6051, David Brenner
  Sound, Supervising Sound Editor, 8159, Shannon Mills
  Sound, Sound Effects Editor, 8165, Dee Selby
  Production, Executive Producer, 10122, Barry H. Waldman
  Art, Production Design, 11002, John Myhre
  Art, Set Decoration, 14915, Gordon Sim
  Directing, Director, 17633, Rob Marshall
  Sound, Orchestrator, 68016, Kevin Kaska
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Costume & Make-Up, Makeup Department Head, 406204, Ve Neill
  Production, Executive Producer, 1255687, John DeLuca
  Art, Set Decoration, 1351274, Missy Parker
  Editing, Dialogue Editor, 1352966, Michael Hertlein
  Editing, Dialogue Editor, 1352968, Margit Pfeiffer
  Directing, Script Supervisor, 1355532, Kerry Lyn McKissick
  Editing, Editor, 1368849, Wyatt Smith
  Sound, Music Editor, 1368884, Melissa Muik
  Sound, Music Supervisor, 1368884, Melissa Muik
  Sound, Supervising Sound Editor, 1378168, George Watters II
  Camera, Still Photographer, 1393883, Peter Mountain
  Sound, Sound Effects Editor, 1399117, David C. Hughes
  Sound, Music Editor, 1399327, Barbara McDermott
  Sound, Sound Effects Editor, 1401786, Ken Fischer
  Sound, Sound Effects Editor, 1415617, Adam Kopald
  Visual Effects, VFX Artist, 1463182, Aaron Williams
  Crew, Compositors, 1463185, Elizabeth McClurg
  Sound, Music Editor, 1483850, Katia Lewin Jablonsky
  Sound, Production Sound Mixer, 1545540, Lee Orloff
WARNING: An illegal reflective access operation has occurred
WARNING: Illegal reflective access by org.apache.hadoop.security.authentication.util.KerberosUtil (file:/home/alumnogreibd/.m2/repository/org/apache/hadoop/hadoop-core/1.2.1/hadoop-core-1.2.1.jar) to method sun.security.krb5.Config.getInstance()
WARNING: Please consider reporting this to the maintainers of org.apache.hadoop.security.authentication.util.KerberosUtil
WARNING: Use --illegal-access=warn to enable warnings of further illegal reflective access operations
WARNING: All illegal access operations will be denied in a future release
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:zookeeper.version=3.5.7-f0fdd52973d373ffd9c86b81d99842dc2c7f660e, built on 02/10/2020 11:30 GMT
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:host.name=greibd
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:java.version=11.0.21
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:java.vendor=Ubuntu
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:java.home=/usr/lib/jvm/java-11-openjdk-amd64
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:java.class.path=/home/alumnogreibd/BDGE/HBaseTest/HBaseTest_new_me/target/classes:/home/alumnogreibd/.m2/repository/org/apache/hadoop/hadoop-core/1.2.1/hadoop-core-1.2.1.jar:/home/alumnogreibd/.m2/repository/commons-cli/commons-cli/1.2/commons-cli-1.2.jar:/home/alumnogreibd/.m2/repository/xmlenc/xmlenc/0.52/xmlenc-0.52.jar:/home/alumnogreibd/.m2/repository/com/sun/jersey/jersey-core/1.8/jersey-core-1.8.jar:/home/alumnogreibd/.m2/repository/com/sun/jersey/jersey-json/1.8/jersey-json-1.8.jar:/home/alumnogreibd/.m2/repository/org/codehaus/jettison/jettison/1.1/jettison-1.1.jar:/home/alumnogreibd/.m2/repository/stax/stax-api/1.0.1/stax-api-1.0.1.jar:/home/alumnogreibd/.m2/repository/com/sun/xml/bind/jaxb-impl/2.2.3-1/jaxb-impl-2.2.3-1.jar:/home/alumnogreibd/.m2/repository/javax/xml/bind/jaxb-api/2.2.2/jaxb-api-2.2.2.jar:/home/alumnogreibd/.m2/repository/javax/xml/stream/stax-api/1.0-2/stax-api-1.0-2.jar:/home/alumnogreibd/.m2/repository/javax/activation/activation/1.1/activation-1.1.jar:/home/alumnogreibd/.m2/repository/org/codehaus/jackson/jackson-core-asl/1.7.1/jackson-core-asl-1.7.1.jar:/home/alumnogreibd/.m2/repository/org/codehaus/jackson/jackson-jaxrs/1.7.1/jackson-jaxrs-1.7.1.jar:/home/alumnogreibd/.m2/repository/org/codehaus/jackson/jackson-xc/1.7.1/jackson-xc-1.7.1.jar:/home/alumnogreibd/.m2/repository/com/sun/jersey/jersey-server/1.8/jersey-server-1.8.jar:/home/alumnogreibd/.m2/repository/asm/asm/3.1/asm-3.1.jar:/home/alumnogreibd/.m2/repository/commons-io/commons-io/2.1/commons-io-2.1.jar:/home/alumnogreibd/.m2/repository/commons-httpclient/commons-httpclient/3.0.1/commons-httpclient-3.0.1.jar:/home/alumnogreibd/.m2/repository/junit/junit/3.8.1/junit-3.8.1.jar:/home/alumnogreibd/.m2/repository/commons-logging/commons-logging/1.0.3/commons-logging-1.0.3.jar:/home/alumnogreibd/.m2/repository/commons-codec/commons-codec/1.4/commons-codec-1.4.jar:/home/alumnogreibd/.m2/repository/org/apache/commons/commons-math/2.1/commons-math-2.1.jar:/home/alumnogreibd/.m2/repository/commons-configuration/commons-configuration/1.6/commons-configuration-1.6.jar:/home/alumnogreibd/.m2/repository/commons-collections/commons-collections/3.2.1/commons-collections-3.2.1.jar:/home/alumnogreibd/.m2/repository/commons-lang/commons-lang/2.4/commons-lang-2.4.jar:/home/alumnogreibd/.m2/repository/commons-digester/commons-digester/1.8/commons-digester-1.8.jar:/home/alumnogreibd/.m2/repository/commons-beanutils/commons-beanutils-core/1.8.0/commons-beanutils-core-1.8.0.jar:/home/alumnogreibd/.m2/repository/commons-net/commons-net/1.4.1/commons-net-1.4.1.jar:/home/alumnogreibd/.m2/repository/org/mortbay/jetty/jetty/6.1.26/jetty-6.1.26.jar:/home/alumnogreibd/.m2/repository/org/mortbay/jetty/servlet-api/2.5-20081211/servlet-api-2.5-20081211.jar:/home/alumnogreibd/.m2/repository/org/mortbay/jetty/jetty-util/6.1.26/jetty-util-6.1.26.jar:/home/alumnogreibd/.m2/repository/tomcat/jasper-runtime/5.5.12/jasper-runtime-5.5.12.jar:/home/alumnogreibd/.m2/repository/tomcat/jasper-compiler/5.5.12/jasper-compiler-5.5.12.jar:/home/alumnogreibd/.m2/repository/org/mortbay/jetty/jsp-api-2.1/6.1.14/jsp-api-2.1-6.1.14.jar:/home/alumnogreibd/.m2/repository/org/mortbay/jetty/servlet-api-2.5/6.1.14/servlet-api-2.5-6.1.14.jar:/home/alumnogreibd/.m2/repository/org/mortbay/jetty/jsp-2.1/6.1.14/jsp-2.1-6.1.14.jar:/home/alumnogreibd/.m2/repository/ant/ant/1.6.5/ant-1.6.5.jar:/home/alumnogreibd/.m2/repository/commons-el/commons-el/1.0/commons-el-1.0.jar:/home/alumnogreibd/.m2/repository/net/java/dev/jets3t/jets3t/0.6.1/jets3t-0.6.1.jar:/home/alumnogreibd/.m2/repository/hsqldb/hsqldb/1.8.0.10/hsqldb-1.8.0.10.jar:/home/alumnogreibd/.m2/repository/oro/oro/2.0.8/oro-2.0.8.jar:/home/alumnogreibd/.m2/repository/org/eclipse/jdt/core/3.1.1/core-3.1.1.jar:/home/alumnogreibd/.m2/repository/org/codehaus/jackson/jackson-mapper-asl/1.8.8/jackson-mapper-asl-1.8.8.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-client/2.3.5/hbase-client-2.3.5.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/thirdparty/hbase-shaded-protobuf/3.3.0/hbase-shaded-protobuf-3.3.0.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-common/2.3.5/hbase-common-2.3.5.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-logging/2.3.5/hbase-logging-2.3.5.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/thirdparty/hbase-shaded-gson/3.3.0/hbase-shaded-gson-3.3.0.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-hadoop-compat/2.3.5/hbase-hadoop-compat-2.3.5.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-metrics-api/2.3.5/hbase-metrics-api-2.3.5.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-hadoop2-compat/2.3.5/hbase-hadoop2-compat-2.3.5.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-metrics/2.3.5/hbase-metrics-2.3.5.jar:/home/alumnogreibd/.m2/repository/javax/activation/javax.activation-api/1.2.0/javax.activation-api-1.2.0.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-protocol-shaded/2.3.5/hbase-protocol-shaded-2.3.5.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/hbase-protocol/2.3.5/hbase-protocol-2.3.5.jar:/home/alumnogreibd/.m2/repository/javax/annotation/javax.annotation-api/1.2/javax.annotation-api-1.2.jar:/home/alumnogreibd/.m2/repository/org/apache/commons/commons-lang3/3.9/commons-lang3-3.9.jar:/home/alumnogreibd/.m2/repository/org/slf4j/slf4j-api/1.7.30/slf4j-api-1.7.30.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/thirdparty/hbase-shaded-miscellaneous/3.3.0/hbase-shaded-miscellaneous-3.3.0.jar:/home/alumnogreibd/.m2/repository/com/google/errorprone/error_prone_annotations/2.3.4/error_prone_annotations-2.3.4.jar:/home/alumnogreibd/.m2/repository/com/google/protobuf/protobuf-java/2.5.0/protobuf-java-2.5.0.jar:/home/alumnogreibd/.m2/repository/org/apache/hbase/thirdparty/hbase-shaded-netty/3.3.0/hbase-shaded-netty-3.3.0.jar:/home/alumnogreibd/.m2/repository/org/apache/zookeeper/zookeeper/3.5.7/zookeeper-3.5.7.jar:/home/alumnogreibd/.m2/repository/org/apache/zookeeper/zookeeper-jute/3.5.7/zookeeper-jute-3.5.7.jar:/home/alumnogreibd/.m2/repository/io/netty/netty-handler/4.1.45.Final/netty-handler-4.1.45.Final.jar:/home/alumnogreibd/.m2/repository/io/netty/netty-common/4.1.45.Final/netty-common-4.1.45.Final.jar:/home/alumnogreibd/.m2/repository/io/netty/netty-buffer/4.1.45.Final/netty-buffer-4.1.45.Final.jar:/home/alumnogreibd/.m2/repository/io/netty/netty-transport/4.1.45.Final/netty-transport-4.1.45.Final.jar:/home/alumnogreibd/.m2/repository/io/netty/netty-resolver/4.1.45.Final/netty-resolver-4.1.45.Final.jar:/home/alumnogreibd/.m2/repository/io/netty/netty-codec/4.1.45.Final/netty-codec-4.1.45.Final.jar:/home/alumnogreibd/.m2/repository/io/netty/netty-transport-native-epoll/4.1.45.Final/netty-transport-native-epoll-4.1.45.Final.jar:/home/alumnogreibd/.m2/repository/io/netty/netty-transport-native-unix-common/4.1.45.Final/netty-transport-native-unix-common-4.1.45.Final.jar:/home/alumnogreibd/.m2/repository/org/apache/htrace/htrace-core4/4.2.0-incubating/htrace-core4-4.2.0-incubating.jar:/home/alumnogreibd/.m2/repository/org/jruby/jcodings/jcodings/1.0.18/jcodings-1.0.18.jar:/home/alumnogreibd/.m2/repository/org/jruby/joni/joni/2.1.11/joni-2.1.11.jar:/home/alumnogreibd/.m2/repository/io/dropwizard/metrics/metrics-core/3.2.6/metrics-core-3.2.6.jar:/home/alumnogreibd/.m2/repository/org/apache/commons/commons-crypto/1.0.0/commons-crypto-1.0.0.jar:/home/alumnogreibd/.m2/repository/org/apache/hadoop/hadoop-auth/2.10.0/hadoop-auth-2.10.0.jar:/home/alumnogreibd/.m2/repository/log4j/log4j/1.2.17/log4j-1.2.17.jar:/home/alumnogreibd/.m2/repository/org/slf4j/slf4j-log4j12/1.7.25/slf4j-log4j12-1.7.25.jar:/home/alumnogreibd/.m2/repository/org/apache/httpcomponents/httpclient/4.5.2/httpclient-4.5.2.jar:/home/alumnogreibd/.m2/repository/org/apache/httpcomponents/httpcore/4.4.4/httpcore-4.4.4.jar:/home/alumnogreibd/.m2/repository/com/nimbusds/nimbus-jose-jwt/4.41.1/nimbus-jose-jwt-4.41.1.jar:/home/alumnogreibd/.m2/repository/com/github/stephenc/jcip/jcip-annotations/1.0-1/jcip-annotations-1.0-1.jar:/home/alumnogreibd/.m2/repository/org/apache/directory/server/apacheds-kerberos-codec/2.0.0-M15/apacheds-kerberos-codec-2.0.0-M15.jar:/home/alumnogreibd/.m2/repository/org/apache/directory/server/apacheds-i18n/2.0.0-M15/apacheds-i18n-2.0.0-M15.jar:/home/alumnogreibd/.m2/repository/org/apache/directory/api/api-asn1-api/1.0.0-M20/api-asn1-api-1.0.0-M20.jar:/home/alumnogreibd/.m2/repository/org/apache/directory/api/api-util/1.0.0-M20/api-util-1.0.0-M20.jar:/home/alumnogreibd/.m2/repository/org/apache/curator/curator-framework/2.7.1/curator-framework-2.7.1.jar:/home/alumnogreibd/.m2/repository/org/apache/hadoop/hadoop-common/2.10.0/hadoop-common-2.10.0.jar:/home/alumnogreibd/.m2/repository/org/apache/hadoop/hadoop-annotations/2.10.0/hadoop-annotations-2.10.0.jar:/home/alumnogreibd/.m2/repository/com/google/guava/guava/11.0.2/guava-11.0.2.jar:/home/alumnogreibd/.m2/repository/org/apache/commons/commons-math3/3.1.1/commons-math3-3.1.1.jar:/home/alumnogreibd/.m2/repository/org/mortbay/jetty/jetty-sslengine/6.1.26/jetty-sslengine-6.1.26.jar:/home/alumnogreibd/.m2/repository/commons-beanutils/commons-beanutils/1.9.4/commons-beanutils-1.9.4.jar:/home/alumnogreibd/.m2/repository/org/apache/avro/avro/1.7.7/avro-1.7.7.jar:/home/alumnogreibd/.m2/repository/com/thoughtworks/paranamer/paranamer/2.3/paranamer-2.3.jar:/home/alumnogreibd/.m2/repository/org/xerial/snappy/snappy-java/1.0.5/snappy-java-1.0.5.jar:/home/alumnogreibd/.m2/repository/com/google/code/gson/gson/2.2.4/gson-2.2.4.jar:/home/alumnogreibd/.m2/repository/com/jcraft/jsch/0.1.54/jsch-0.1.54.jar:/home/alumnogreibd/.m2/repository/org/apache/curator/curator-client/2.7.1/curator-client-2.7.1.jar:/home/alumnogreibd/.m2/repository/org/apache/curator/curator-recipes/2.7.1/curator-recipes-2.7.1.jar:/home/alumnogreibd/.m2/repository/com/google/code/findbugs/jsr305/3.0.0/jsr305-3.0.0.jar:/home/alumnogreibd/.m2/repository/org/apache/commons/commons-compress/1.19/commons-compress-1.19.jar:/home/alumnogreibd/.m2/repository/org/codehaus/woodstox/stax2-api/3.1.4/stax2-api-3.1.4.jar:/home/alumnogreibd/.m2/repository/com/fasterxml/woodstox/woodstox-core/5.0.3/woodstox-core-5.0.3.jar:/home/alumnogreibd/.m2/repository/org/apache/yetus/audience-annotations/0.5.0/audience-annotations-0.5.0.jar:/home/alumnogreibd/.m2/repository/org/postgresql/postgresql/42.2.23/postgresql-42.2.23.jar:/home/alumnogreibd/.m2/repository/org/checkerframework/checker-qual/3.5.0/checker-qual-3.5.0.jar
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:java.library.path=/usr/java/packages/lib:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:java.io.tmpdir=/tmp
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:java.compiler=<NA>
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:os.name=Linux
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:os.arch=amd64
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:os.version=5.4.0-169-generic
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:user.name=alumnogreibd
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:user.home=/home/alumnogreibd
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:user.dir=/home/alumnogreibd/BDGE/HBaseTest/HBaseTest_new_me
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:os.memory.free=103MB
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:os.memory.max=1898MB
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Client environment:os.memory.total=119MB
23/12/22 11:58:05 INFO zookeeper.ZooKeeper: Initiating client connection, connectString=127.0.0.1:2181 sessionTimeout=90000 watcher=org.apache.hadoop.hbase.zookeeper.ReadOnlyZKClient$$Lambda$94/0x00000008401a5c40@4c3a2d14
23/12/22 11:58:05 INFO common.X509Util: Setting -D jdk.tls.rejectClientInitiatedRenegotiation=true to disable client-initiated TLS renegotiation
23/12/22 11:58:05 INFO zookeeper.ClientCnxnSocket: jute.maxbuffer value is 4194304 Bytes
23/12/22 11:58:05 INFO zookeeper.ClientCnxn: zookeeper.request.timeout value is 0. feature enabled=
23/12/22 11:58:05 INFO zookeeper.ClientCnxn: Opening socket connection to server localhost/127.0.0.1:2181. Will not attempt to authenticate using SASL (unknown error)
23/12/22 11:58:05 INFO zookeeper.ClientCnxn: Socket connection established, initiating session, client: /127.0.0.1:39400, server: localhost/127.0.0.1:2181
23/12/22 11:58:05 INFO zookeeper.ClientCnxn: Session establishment complete on server localhost/127.0.0.1:2181, sessionid = 0x100005211c40007, negotiated timeout = 40000

Titulo: Pirates of the Caribbean: On Stranger Tides
Id: 1865
Fecha Emision: 2011-05-14
Presupuesto: 1045713802
Ingresos: 380000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Captain Jack Sparrow, 85, Johnny Depp
  1, Angelica Teach, 955, Penélope Cruz
  2, Captain Edward "Blackbeard" Teach, 6972, Ian McShane
  3, Joshamee Gibbs, 2449, Kevin McNally
  4, Captain Hector Barbossa, 118, Geoffrey Rush
  5, Philip Swift, 237455, Sam Claflin
  6, Syrena, 469759, Astrid Bergès-Frisbey
  7, Scrum, 1115, Stephen Graham
  8, Lieutenant Theodore Groves, 4031, Greg Ellis
  9, Lieutenant Gillette, 1712, Damian O'Hare
  10, The Spaniard, 59129, Óscar Jaenada
  11, King George II, 10983, Richard Griffiths
  12, Captain Teague Sparrow, 1430, Keith Richards
  13, Tamara, 55901, Gemma Ward
  14, High Society Lady, 5309, Judi Dench
  15, Quartermaster, 199975, Ian Mercer
  16, Cabin Boy, 88392, Robbie Kay
  17, Ezekiel, 8399, Christopher Fairbank
  18, Garheng, 77955, Yuki Matsuzaki
  19, Purser, 83814, Steve Evets
  20, Cook, 75076, Bronson Webb
  21, Master-at-Arms, 51300, Derek Mears
  22, Gunner, 58758, Deobia Oparei
  23, King Ferdinand of the Spanish Empire, 229634, Sebastian Armesto
  24, John Carteret, 27397, Anton Lesser
  25, Prime Minister Henry Pelham, 11279, Roger Allam
  26, Salaman, 110075, Paul Bazely
  27, Derrick, 1321379, Richard Thomson
  28, Yeoman, 1310385, Danny Le Boyer
  29, Justice Smith, 1797040, Alan J. Utley-Moore
  30, Captain of the Guard, 214581, Luke Roberts
  31, English Girl, 1331023, Emilia Jones
  32, Mermaid, 1770474, Sanya Hughes
  33, Guard, 1131724, Daniel Ings
  34, Queen Anne's Pirate (uncredited), 1269611, LeJon
  35, British Sailor (uncredited), 1770475, Siegfried Peters
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Production, Producer, 770, Jerry Bruckheimer
  Sound, Sound Re-Recording Mixer, 900, Christopher Boyes
  Sound, Original Music Composer, 947, Hans Zimmer
  Writing, Screenplay, 1705, Ted Elliott
  Production, Executive Producer, 1706, Terry Rossio
  Writing, Screenplay, 1706, Terry Rossio
  Production, Executive Producer, 2444, Mike Stenson
  Production, Executive Producer, 2446, Chad Oman
  Costume & Make-Up, Costume Design, 4034, Penny Rose
  Sound, Music Supervisor, 5132, Bob Badami
  Editing, Editor, 6051, David Brenner
  Sound, Supervising Sound Editor, 8159, Shannon Mills
  Sound, Sound Effects Editor, 8165, Dee Selby
  Production, Executive Producer, 10122, Barry H. Waldman
  Art, Production Design, 11002, John Myhre
  Art, Set Decoration, 14915, Gordon Sim
  Directing, Director, 17633, Rob Marshall
  Sound, Orchestrator, 68016, Kevin Kaska
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Costume & Make-Up, Makeup Department Head, 406204, Ve Neill
  Production, Executive Producer, 1255687, John DeLuca
  Art, Set Decoration, 1351274, Missy Parker
  Editing, Dialogue Editor, 1352966, Michael Hertlein
  Editing, Dialogue Editor, 1352968, Margit Pfeiffer
  Directing, Script Supervisor, 1355532, Kerry Lyn McKissick
  Editing, Editor, 1368849, Wyatt Smith
  Sound, Music Editor, 1368884, Melissa Muik
  Sound, Music Supervisor, 1368884, Melissa Muik
  Sound, Supervising Sound Editor, 1378168, George Watters II
  Camera, Still Photographer, 1393883, Peter Mountain
  Sound, Sound Effects Editor, 1399117, David C. Hughes
  Sound, Music Editor, 1399327, Barbara McDermott
  Sound, Sound Effects Editor, 1401786, Ken Fischer
  Sound, Sound Effects Editor, 1415617, Adam Kopald
  Visual Effects, VFX Artist, 1463182, Aaron Williams
  Crew, Compositors, 1463185, Elizabeth McClurg
  Sound, Music Editor, 1483850, Katia Lewin Jablonsky
  Sound, Production Sound Mixer, 1545540, Lee Orloff
//Ejercicio_2;
23/12/22 11:58:07 INFO zookeeper.ZooKeeper: Session: 0x100005211c40007 closed
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: EventThread shut down for session: 0x100005211c40007

Titulo: Avatar
Id: 19995
Fecha Emision: 2009-12-10
Presupuesto: 237000000
Ingresos: 2787965087
Reparto (Orden, Personaje, Id, Actriz/Actor)
  0, Jake Sully, 65731, Sam Worthington
  1, Princess Neytiri, 8691, Zoe Saldana
  2, Dr. Grace Augustine, 10205, Sigourney Weaver
  3, Col. Quaritch, 32747, Stephen Lang
  4, Trudy Chacon, 17647, Michelle Rodriguez
  5, Selfridge, 1771, Giovanni Ribisi
  6, Norm Spellman, 59231, Joel David Moore
  7, Moat, 30485, CCH Pounder
  8, Eytukan, 15853, Wes Studi
  9, Tsu'Tey, 10964, Laz Alonso
  10, Dr. Max Patel, 95697, Dileep Rao
  11, Lyle Wainfleet, 98215, Matt Gerald
  12, Private Fike, 154153, Sean Anthony Moran
  13, Cryo Vault Med Tech, 397312, Jason Whyte
  14, Venture Star Crew Chief, 42317, Scott Lawrence
  15, Lock Up Trooper, 986734, Kelly Kilgour
  16, Shuttle Pilot, 1207227, James Patrick Pitt
  17, Shuttle Co-Pilot, 1180936, Sean Patrick Murphy
  18, Shuttle Crew Chief, 1019578, Peter Dillon
  19, Tractor Operator / Troupe, 91443, Kevin Dorman
  20, Dragon Gunship Pilot, 173391, Kelson Henderson
  21, Dragon Gunship Gunner, 1207236, David Van Horn
  22, Dragon Gunship Navigator, 215913, Jacob Tomuri
  23, Suit #1, 143206, Michael Blain-Rozgay
  24, Suit #2, 169676, Jon Curry
  25, Ambient Room Tech, 1048610, Luke Hawker
  26, Ambient Room Tech / Troupe, 42288, Woody Schultz
  27, Horse Clan Leader, 68278, Peter Mensah
  28, Link Room Tech, 1207247, Sonia Yee
  29, Basketball Avatar / Troupe, 1207248, Jahnel Curfman
  30, Basketball Avatar, 89714, Ilram Choi
  31, Na'vi Child, 1207249, Kyla Warren
  32, Troupe, 1207250, Lisa Roumain
  33, Troupe, 83105, Debra Wilson
  34, Troupe, 1207253, Chris Mala
  35, Troupe, 1207251, Taylor Kibby
  36, Troupe, 1207252, Jodie Landau
  37, Troupe, 1207254, Julie Lamm
  38, Troupe, 1207257, Cullen B. Madden
  39, Troupe, 1207259, Joseph Brady Madden
  40, Troupe, 1207262, Frankie Torres
  41, Troupe, 1158600, Austin Wilson
  42, Troupe, 983705, Sara Wilson
  43, Troupe, 1207263, Tamica Washington-Miller
  44, Op Center Staff, 1145098, Lucy Briant
  45, Op Center Staff, 33305, Nathan Meister
  46, Op Center Staff, 1207264, Gerry Blair
  47, Op Center Staff, 33311, Matthew Chamberlain
  48, Op Center Staff, 1207265, Paul Yates
  49, Op Center Duty Officer, 1207266, Wray Wilson
  50, Op Center Staff, 54492, James Gaylyn
  51, Dancer, 1207267, Melvin Leno Clark III
  52, Dancer, 1207268, Carvon Futrell
  53, Dancer, 1207269, Brandon Jelkes
  54, Dancer, 1207270, Micah Moch
  55, Dancer, 1207271, Hanniyah Muhammad
  56, Dancer, 1207272, Christopher Nolen
  57, Dancer, 1207273, Christa Oliver
  58, Dancer, 1207274, April Marie Thomas
  59, Dancer, 1207275, Bravita A. Threatt
  60, Mining Chief (uncredited), 1207276, Colin Bleasdale
  61, Veteran Miner (uncredited), 107969, Mike Bodnar
  62, Richard (uncredited), 1207278, Matt Clayton
  63, Nav'i (uncredited), 147898, Nicole Dionne
  64, Trooper (uncredited), 1207280, Jamie Harrison
  65, Trooper (uncredited), 1207281, Allan Henry
  66, Ground Technician (uncredited), 1207282, Anthony Ingruber
  67, Flight Crew Mechanic (uncredited), 1207283, Ashley Jeffery
  68, Samson Pilot, 98216, Dean Knowsley
  69, Trooper (uncredited), 1201399, Joseph Mika-Hunt
  70, Banshee (uncredited), 236696, Terry Notary
  71, Soldier (uncredited), 1207287, Kai Pantano
  72, Blast Technician (uncredited), 1207288, Logan Pithyou
  73, Vindum Raah (uncredited), 1207289, Stuart Pollock
  74, Hero (uncredited), 584868, Raja
  75, Ops Centreworker (uncredited), 1207290, Gareth Ruck
  76, Engineer (uncredited), 1062463, Rhian Sheehan
  77, Col. Quaritch's Mech Suit (uncredited), 60656, T. J. Storm
  78, Female Marine (uncredited), 1207291, Jodie Taylor
  79, Ikran Clan Leader (uncredited), 1186027, Alicia Vela-Bailey
  80, Geologist (uncredited), 1207292, Richard Whiteside
  81, Na'vi (uncredited), 103259, Nikie Zambo
  82, Ambient Room Tech / Troupe, 42286, Julene Renee
23/12/22 11:58:07 INFO zookeeper.ZooKeeper: Initiating client connection, connectString=127.0.0.1:2181 sessionTimeout=90000 watcher=org.apache.hadoop.hbase.zookeeper.ReadOnlyZKClient$$Lambda$94/0x00000008401a5c40@4c3a2d14
23/12/22 11:58:07 INFO zookeeper.ClientCnxnSocket: jute.maxbuffer value is 4194304 Bytes
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: zookeeper.request.timeout value is 0. feature enabled=
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: Opening socket connection to server localhost/127.0.0.1:2181. Will not attempt to authenticate using SASL (unknown error)
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: Socket connection established, initiating session, client: /127.0.0.1:39402, server: localhost/127.0.0.1:2181
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: Session establishment complete on server localhost/127.0.0.1:2181, sessionid = 0x100005211c40008, negotiated timeout = 40000

Titulo: Avatar
Id: 19995
Fecha Emision: 2009-12-10
Presupuesto: 2787965087
Ingresos: 237000000
Reparto (Orden, Personaje, Id, Actriz/Actor)
  0, Jake Sully, 65731, Sam Worthington
  1, Princess Neytiri, 8691, Zoe Saldana
  2, Dr. Grace Augustine, 10205, Sigourney Weaver
  3, Col. Quaritch, 32747, Stephen Lang
  4, Trudy Chacon, 17647, Michelle Rodriguez
  5, Selfridge, 1771, Giovanni Ribisi
  6, Norm Spellman, 59231, Joel David Moore
  7, Moat, 30485, CCH Pounder
  8, Eytukan, 15853, Wes Studi
  9, Tsu'Tey, 10964, Laz Alonso
  10, Dr. Max Patel, 95697, Dileep Rao
  11, Lyle Wainfleet, 98215, Matt Gerald
  12, Private Fike, 154153, Sean Anthony Moran
  13, Cryo Vault Med Tech, 397312, Jason Whyte
  14, Venture Star Crew Chief, 42317, Scott Lawrence
  15, Lock Up Trooper, 986734, Kelly Kilgour
  16, Shuttle Pilot, 1207227, James Patrick Pitt
  17, Shuttle Co-Pilot, 1180936, Sean Patrick Murphy
  18, Shuttle Crew Chief, 1019578, Peter Dillon
  19, Tractor Operator / Troupe, 91443, Kevin Dorman
  20, Dragon Gunship Pilot, 173391, Kelson Henderson
  21, Dragon Gunship Gunner, 1207236, David Van Horn
  22, Dragon Gunship Navigator, 215913, Jacob Tomuri
  23, Suit #1, 143206, Michael Blain-Rozgay
  24, Suit #2, 169676, Jon Curry
  25, Ambient Room Tech, 1048610, Luke Hawker
  26, Ambient Room Tech / Troupe, 42288, Woody Schultz
  27, Horse Clan Leader, 68278, Peter Mensah
  28, Link Room Tech, 1207247, Sonia Yee
  29, Basketball Avatar / Troupe, 1207248, Jahnel Curfman
  30, Basketball Avatar, 89714, Ilram Choi
  31, Na'vi Child, 1207249, Kyla Warren
  32, Troupe, 1207250, Lisa Roumain
  33, Troupe, 83105, Debra Wilson
  34, Troupe, 1207253, Chris Mala
  35, Troupe, 1207251, Taylor Kibby
  36, Troupe, 1207252, Jodie Landau
  37, Troupe, 1207254, Julie Lamm
  38, Troupe, 1207257, Cullen B. Madden
  39, Troupe, 1207259, Joseph Brady Madden
  40, Troupe, 1207262, Frankie Torres
  41, Troupe, 1158600, Austin Wilson
  42, Troupe, 983705, Sara Wilson
  43, Troupe, 1207263, Tamica Washington-Miller
  44, Op Center Staff, 1145098, Lucy Briant
  45, Op Center Staff, 33305, Nathan Meister
  46, Op Center Staff, 1207264, Gerry Blair
  47, Op Center Staff, 33311, Matthew Chamberlain
  48, Op Center Staff, 1207265, Paul Yates
  49, Op Center Duty Officer, 1207266, Wray Wilson
  50, Op Center Staff, 54492, James Gaylyn
  51, Dancer, 1207267, Melvin Leno Clark III
  52, Dancer, 1207268, Carvon Futrell
  53, Dancer, 1207269, Brandon Jelkes
  54, Dancer, 1207270, Micah Moch
  55, Dancer, 1207271, Hanniyah Muhammad
  56, Dancer, 1207272, Christopher Nolen
  57, Dancer, 1207273, Christa Oliver
  58, Dancer, 1207274, April Marie Thomas
  59, Dancer, 1207275, Bravita A. Threatt
  60, Mining Chief (uncredited), 1207276, Colin Bleasdale
  61, Veteran Miner (uncredited), 107969, Mike Bodnar
  62, Richard (uncredited), 1207278, Matt Clayton
  63, Nav'i (uncredited), 147898, Nicole Dionne
  64, Trooper (uncredited), 1207280, Jamie Harrison
  65, Trooper (uncredited), 1207281, Allan Henry
  66, Ground Technician (uncredited), 1207282, Anthony Ingruber
  67, Flight Crew Mechanic (uncredited), 1207283, Ashley Jeffery
  68, Samson Pilot, 98216, Dean Knowsley
  69, Trooper (uncredited), 1201399, Joseph Mika-Hunt
  70, Banshee (uncredited), 236696, Terry Notary
  71, Soldier (uncredited), 1207287, Kai Pantano
  72, Blast Technician (uncredited), 1207288, Logan Pithyou
  73, Vindum Raah (uncredited), 1207289, Stuart Pollock
  74, Hero (uncredited), 584868, Raja
  75, Ops Centreworker (uncredited), 1207290, Gareth Ruck
  76, Engineer (uncredited), 1062463, Rhian Sheehan
  77, Col. Quaritch's Mech Suit (uncredited), 60656, T. J. Storm
  78, Female Marine (uncredited), 1207291, Jodie Taylor
  79, Ikran Clan Leader (uncredited), 1186027, Alicia Vela-Bailey
  80, Geologist (uncredited), 1207292, Richard Whiteside
  81, Na'vi (uncredited), 103259, Nikie Zambo
  82, Ambient Room Tech / Troupe, 42286, Julene Renee
//Ejercicio_3

Titulo: Pirates of the Caribbean: On Stranger Tides
Id: 1865
Fecha Emision: 2011-05-14
Presupuesto: 380000000
Ingresos: 1045713802

Titulo: Pirates of the Caribbean: At World's End
Id: 285
Fecha Emision: 2007-05-19
Presupuesto: 300000000
Ingresos: 961000000

Titulo: Avengers: Age of Ultron
Id: 99861
Fecha Emision: 2015-04-22
Presupuesto: 280000000
Ingresos: 1405403694

Titulo: Superman Returns
Id: 1452
Fecha Emision: 2006-06-28
Presupuesto: 270000000
Ingresos: 391081192

Titulo: Tangled
Id: 38757
Fecha Emision: 2010-11-24
Presupuesto: 260000000
Ingresos: 591794936

Titulo: John Carter
Id: 49529
Fecha Emision: 2012-03-07
Presupuesto: 260000000
Ingresos: 284139100

Titulo: Transformers: The Last Knight
Id: 335988
Fecha Emision: 2017-06-21
Presupuesto: 260000000
Ingresos: 604942143

Titulo: Spider-Man 3
Id: 559
Fecha Emision: 2007-05-01
Presupuesto: 258000000
Ingresos: 890871626

Titulo: The Lone Ranger
Id: 57201
Fecha Emision: 2013-07-03
Presupuesto: 255000000
Ingresos: 89289910
23/12/22 11:58:07 INFO zookeeper.ZooKeeper: Session: 0x100005211c40008 closed
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: EventThread shut down for session: 0x100005211c40008
23/12/22 11:58:07 INFO zookeeper.ZooKeeper: Initiating client connection, connectString=127.0.0.1:2181 sessionTimeout=90000 watcher=org.apache.hadoop.hbase.zookeeper.ReadOnlyZKClient$$Lambda$94/0x00000008401a5c40@4c3a2d14
23/12/22 11:58:07 INFO zookeeper.ClientCnxnSocket: jute.maxbuffer value is 4194304 Bytes
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: zookeeper.request.timeout value is 0. feature enabled=
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: Opening socket connection to server localhost/127.0.0.1:2181. Will not attempt to authenticate using SASL (unknown error)
23/12/22 11:58:07 INFO zookeeper.ClientCnxn: Socket connection established, initiating session, client: /127.0.0.1:39406, server: localhost/127.0.0.1:2181
23/12/22 11:58:08 INFO zookeeper.ClientCnxn: Session establishment complete on server localhost/127.0.0.1:2181, sessionid = 0x100005211c40009, negotiated timeout = 40000

Titulo: Pirates of the Caribbean: At World's End
Id: 285
Fecha Emision: 2007-05-19
Presupuesto: 961000000
Ingresos: 300000000

Titulo: Spider-Man 3
Id: 559
Fecha Emision: 2007-05-01
Presupuesto: 890871626
Ingresos: 258000000

Titulo: Superman Returns
Id: 1452
Fecha Emision: 2006-06-28
Presupuesto: 391081192
Ingresos: 270000000

Titulo: Pirates of the Caribbean: On Stranger Tides
Id: 1865
Fecha Emision: 2011-05-14
Presupuesto: 1045713802
Ingresos: 380000000

Titulo: Tangled
Id: 38757
Fecha Emision: 2010-11-24
Presupuesto: 591794936
Ingresos: 260000000

Titulo: John Carter
Id: 49529
Fecha Emision: 2012-03-07
Presupuesto: 284139100
Ingresos: 260000000

Titulo: The Lone Ranger
Id: 57201
Fecha Emision: 2013-07-03
Presupuesto: 89289910
Ingresos: 255000000

Titulo: Avengers: Age of Ultron
Id: 99861
Fecha Emision: 2015-04-22
Presupuesto: 1405403694
Ingresos: 280000000

Titulo: Transformers: The Last Knight
Id: 335988
Fecha Emision: 2017-06-21
Presupuesto: 604942143
Ingresos: 260000000
//Ejercicio_4
23/12/22 11:58:08 INFO zookeeper.ZooKeeper: Session: 0x100005211c40009 closed
23/12/22 11:58:08 INFO zookeeper.ClientCnxn: EventThread shut down for session: 0x100005211c40009

Titulo: Kingsman: The Secret Service
Id: 207703
Fecha Emision: 2015-01-29
Presupuesto: 81000000
Ingresos: 414351546
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Harry Hart / Galahad, 5472, Colin Firth

Titulo: Blackhat
Id: 201088
Fecha Emision: 2015-01-13
Presupuesto: 70000000
Ingresos: 17752940
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nicholas Hathaway, 74568, Chris Hemsworth

Titulo: Mortdecai
Id: 210860
Fecha Emision: 2015-01-21
Presupuesto: 60000000
Ingresos: 30418560
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles Mortdecai, 85, Johnny Depp

Titulo: Wild Card
Id: 265208
Fecha Emision: 2015-01-14
Presupuesto: 30000000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nick Wild, 976, Jason Statham

Titulo: The Wedding Ringer
Id: 252838
Fecha Emision: 2015-01-16
Presupuesto: 23000000
Ingresos: 79799880
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jimmy Callahan / Bic, 55638, Kevin Hart

Titulo: Robot Overlords
Id: 240483
Fecha Emision: 2015-01-29
Presupuesto: 21000000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Connor, 1425134, Milo Parker

Titulo: I
Id: 263471
Fecha Emision: 2015-01-04
Presupuesto: 16000000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Lingesan, 93191, Vikram

Titulo: Ex Machina
Id: 264660
Fecha Emision: 2015-01-21
Presupuesto: 15000000
Ingresos: 36869414
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Caleb Smith, 93210, Domhnall Gleeson

Titulo: Project Almanac
Id: 227719
Fecha Emision: 2015-01-29
Presupuesto: 12000000
Ingresos: 32248241
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Raskin, 928575, Jonny Weston

Titulo: Tracers
Id: 290764
Fecha Emision: 2015-01-15
Presupuesto: 11000000
Ingresos: 593683
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Harry Hart / Galahad, 5472, Colin Firth

Titulo: Admiral
Id: 277154
Fecha Emision: 2015-01-29
Presupuesto: 10000000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nicholas Hathaway, 74568, Chris Hemsworth

Titulo: Vice
Id: 307663
Fecha Emision: 2015-01-16
Presupuesto: 10000000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles Mortdecai, 85, Johnny Depp

Titulo: Serial Killer 1
Id: 307103
Fecha Emision: 2015-01-07
Presupuesto: 5290000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nick Wild, 976, Jason Statham

Titulo: The Boy Next Door
Id: 241251
Fecha Emision: 2015-01-23
Presupuesto: 4000000
Ingresos: 52425855
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jimmy Callahan / Bic, 55638, Kevin Hart

Titulo: Justice League: Throne of Atlantis
Id: 297556
Fecha Emision: 2015-01-27
Presupuesto: 3500000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Connor, 1425134, Milo Parker

Titulo: The Master Plan
Id: 308160
Fecha Emision: 2015-01-16
Presupuesto: 3500000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Lingesan, 93191, Vikram

Titulo: The Lazarus Effect
Id: 243940
Fecha Emision: 2015-01-29
Presupuesto: 3300000
Ingresos: 64110728
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Caleb Smith, 93210, Domhnall Gleeson

Titulo: Loucas pra Casar
Id: 261461
Fecha Emision: 2015-01-08
Presupuesto: 3000000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Raskin, 928575, Jonny Weston

Titulo: What Men Do! 2
Id: 314952
Fecha Emision: 2015-01-01
Presupuesto: 2000000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michiel de Ruyter, 43643, Frank Lammers

Titulo: Italiano medio
Id: 320316
Fecha Emision: 2015-01-29
Presupuesto: 1816720
Ingresos: 4541800
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kelly, 75330, Ambyr Childers

Titulo: Aferim!
Id: 319993
Fecha Emision: 2015-01-22
Presupuesto: 1379375
Ingresos: 105097
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Claire Peterson, 16866, Jennifer Lopez

Titulo: Buddy Hutchins
Id: 322266
Fecha Emision: 2015-01-01
Presupuesto: 1200000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shazam (voice), 1328, Sean Astin

Titulo: Ratter
Id: 320048
Fecha Emision: 2015-01-24
Presupuesto: 500000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles-Ingvar Jönsson, 135726, Simon J. Berger

Titulo: Caffeinated
Id: 321530
Fecha Emision: 2015-01-31
Presupuesto: 200000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Zoe McConnell, 59315, Olivia Wilde

Titulo: Crumbs
Id: 322614
Fecha Emision: 2015-01-27
Presupuesto: 200000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Giulio Verme / Antonino Verme / Mariottide, 1258076, Maccio Capatonda

Titulo: Hoovey
Id: 305747
Fecha Emision: 2015-01-31
Presupuesto: 2
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Emma, 78030, Ashley Benson

Titulo: Uncanny
Id: 137333
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Kressen, 4451, Mark Webber

Titulo: The Mask You Live In
Id: 224972
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Harry Hart / Galahad, 5472, Colin Firth

Titulo: Backmask
Id: 226458
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nicholas Hathaway, 74568, Chris Hemsworth

Titulo: Little Accidents
Id: 244260
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles Mortdecai, 85, Johnny Depp

Titulo: German Angst
Id: 252596
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nick Wild, 976, Jason Statham

Titulo: Spare Parts
Id: 264337
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jimmy Callahan / Bic, 55638, Kevin Hart

Titulo: Something, Anything
Id: 271039
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Connor, 1425134, Milo Parker

Titulo: Everly
Id: 277355
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Lingesan, 93191, Vikram

Titulo: A Grain of Truth
Id: 278677
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Caleb Smith, 93210, Domhnall Gleeson

Titulo: Hungry Hearts
Id: 283698
Fecha Emision: 2015-01-15
Presupuesto: 0
Ingresos: 6921
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Raskin, 928575, Jonny Weston

Titulo: Felix and Meira
Id: 285848
Fecha Emision: 2015-01-11
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michiel de Ruyter, 43643, Frank Lammers

Titulo: The World Made Straight
Id: 289716
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kelly, 75330, Ambyr Childers

Titulo: I Am Michael
Id: 291869
Fecha Emision: 2015-01-29
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Claire Peterson, 16866, Jennifer Lopez

Titulo: Psycho-Pass: The Movie
Id: 296917
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shazam (voice), 1328, Sean Astin

Titulo: The Scorpion King: Quest for Power
Id: 297291
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles-Ingvar Jönsson, 135726, Simon J. Berger

Titulo: Gangnam Blues
Id: 297721
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Zoe McConnell, 59315, Olivia Wilde

Titulo: The Atticus Institute
Id: 299551
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Giulio Verme / Antonino Verme / Mariottide, 1258076, Maccio Capatonda

Titulo: Sidetracked
Id: 300596
Fecha Emision: 2015-01-30
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Emma, 78030, Ashley Benson

Titulo: Racing Extinction
Id: 300792
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Kressen, 4451, Mark Webber

Titulo: Terminus
Id: 301729
Fecha Emision: 2015-01-30
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Father Conway, 32747, Stephen Lang

Titulo: Strange Magic
Id: 302429
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 13603453
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Diane Doyle, 9281, Elizabeth Banks

Titulo: Young Sophie Bell
Id: 303636
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Final Girl, 1439081, Lola Gave

Titulo: Partisan
Id: 306482
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Oscar Vazquez, 215186, Carlos PenaVega

Titulo: Homies
Id: 306543
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Teodor Szacki, 127856, Robert Więckiewicz

Titulo: Son of Mine
Id: 306547
Fecha Emision: 2015-01-29
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jude, 1023139, Adam Driver

Titulo: Dark Summer
Id: 306969
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shank, 9640, Haley Joel Osment

Titulo: 88
Id: 307479
Fecha Emision: 2015-01-06
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michael Glatze, 17051, James Franco

Titulo: The Visit: An Alien Encounter
Id: 308063
Fecha Emision: 2015-01-26
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Akane Tsunemori (voice), 119143, Kana Hanazawa

Titulo: 3 Türken und ein Baby
Id: 308174
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Mathayus, the Scorpion King, 1215144, Victor Webster

Titulo: Stockholm, Pennsylvania
Id: 308361
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kim Jong-dae, 1245104, Lee Min-ho

Titulo: Songs My Brothers Taught Me
Id: 308640
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Alberto, 34021, Raúl Arévalo

Titulo: Away and Back
Id: 308715
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself, 57563, Elon Musk

Titulo: The Ouija Experiment 2: Theatre of Death
Id: 309063
Fecha Emision: 2015-01-13
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Chamberlain, 144501, Jai Koutrae

Titulo: 8 New Dates
Id: 309739
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Bog King (voice), 10697, Alan Cumming

Titulo: Patterns of Evidence: The Exodus
Id: 309882
Fecha Emision: 2015-01-14
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Celal Yildiz, 5202, Kostja Ullmann

Titulo: Seoul Searching
Id: 310001
Fecha Emision: 2015-01-30
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jack Peterson, 11662, Jason Lee

Titulo: A Novel Romance
Id: 311181
Fecha Emision: 2015-01-10
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nikita, 139459, Vladimir Zelenskiy

Titulo: Roles in the Wind
Id: 311215
Fecha Emision: 2015-01-08
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Mr. Kim, 142425, Cha In-pyo

Titulo: My Skinny Sister
Id: 311770
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Stella, 1400149, Rebecka Josephson

Titulo: The Phoenix Project
Id: 312131
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Harry Hart / Galahad, 5472, Colin Firth

Titulo: James White
Id: 312804
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nicholas Hathaway, 74568, Chris Hemsworth

Titulo: Ivy
Id: 312849
Fecha Emision: 2015-01-26
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles Mortdecai, 85, Johnny Depp

Titulo: All She Wishes
Id: 313371
Fecha Emision: 2015-01-15
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nick Wild, 976, Jason Statham

Titulo: Love Forecast
Id: 313628
Fecha Emision: 2015-01-15
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jimmy Callahan / Bic, 55638, Kevin Hart

Titulo: Roald Dahl's Esio Trot
Id: 313867
Fecha Emision: 2015-01-02
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Connor, 1425134, Milo Parker

Titulo: Baby
Id: 314389
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Lingesan, 93191, Vikram

Titulo: Body
Id: 314420
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Caleb Smith, 93210, Domhnall Gleeson

Titulo: Three Heroes and Julius Caesar
Id: 314946
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Raskin, 928575, Jonny Weston

Titulo: Adult Camp
Id: 315049
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michiel de Ruyter, 43643, Frank Lammers

Titulo: Surprised by Love
Id: 315134
Fecha Emision: 2015-01-03
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kelly, 75330, Ambyr Childers

Titulo: Lokmanya: Ek Yug Purush
Id: 315226
Fecha Emision: 2015-01-02
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Claire Peterson, 16866, Jennifer Lopez

Titulo: Sneeuwwitje En De Zeven Kleine Mensen: Een Modern Sprookje
Id: 315252
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shazam (voice), 1328, Sean Astin

Titulo: We Accept Miracles
Id: 315319
Fecha Emision: 2015-01-02
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles-Ingvar Jönsson, 135726, Simon J. Berger

Titulo: Frau Müller muss weg!
Id: 315335
Fecha Emision: 2015-01-15
Presupuesto: 0
Ingresos: 9127383
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Zoe McConnell, 59315, Olivia Wilde

Titulo: Beck 27 - Rum 302
Id: 315360
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Giulio Verme / Antonino Verme / Mariottide, 1258076, Maccio Capatonda

Titulo: Beck 28 - Familjen
Id: 315362
Fecha Emision: 2015-01-10
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Emma, 78030, Ashley Benson

Titulo: Beaver Trilogy Part IV
Id: 315882
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Kressen, 4451, Mark Webber

Titulo: My Life as a Dead Girl
Id: 316015
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Father Conway, 32747, Stephen Lang

Titulo: Misery Loves Comedy
Id: 316067
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Diane Doyle, 9281, Elizabeth Banks

Titulo: What's Between Us
Id: 316074
Fecha Emision: 2015-01-07
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Final Girl, 1439081, Lola Gave

Titulo: Tired Moonlight
Id: 316179
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Oscar Vazquez, 215186, Carlos PenaVega

Titulo: The Sky Above Us
Id: 316310
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Teodor Szacki, 127856, Robert Więckiewicz

Titulo: Barbie in Princess Power
Id: 316322
Fecha Emision: 2015-01-29
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jude, 1023139, Adam Driver

Titulo: A Horse for Summer
Id: 316347
Fecha Emision: 2015-01-06
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shank, 9640, Haley Joel Osment

Titulo: Bound
Id: 316410
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michael Glatze, 17051, James Franco

Titulo: The Eichmann Show
Id: 316715
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Akane Tsunemori (voice), 119143, Kana Hanazawa

Titulo: Above and Below
Id: 316883
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Mathayus, the Scorpion King, 1215144, Victor Webster

Titulo: Bridgend
Id: 316885
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kim Jong-dae, 1245104, Lee Min-ho

Titulo: Bridal Wave
Id: 317114
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Alberto, 34021, Raúl Arévalo

Titulo: Cyberbully
Id: 317144
Fecha Emision: 2015-01-15
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself, 57563, Elon Musk

Titulo: From A to B
Id: 317214
Fecha Emision: 2015-01-08
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Chamberlain, 144501, Jai Koutrae

Titulo: Being Evel
Id: 317655
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Bog King (voice), 10697, Alan Cumming

Titulo: Banana Pancakes and the Children of Sticky Rice
Id: 317988
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Celal Yildiz, 5202, Kostja Ullmann

Titulo: What Happened, Miss Simone?
Id: 318044
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jack Peterson, 11662, Jason Lee

Titulo: The Man in the Wall
Id: 318052
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nikita, 139459, Vladimir Zelenskiy

Titulo: No Men Beyond This Point
Id: 318054
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Mr. Kim, 142425, Cha In-pyo

Titulo: Going Clear: Scientology and the Prison of Belief
Id: 318224
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Stella, 1400149, Rebecka Josephson

Titulo: Meru
Id: 318279
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 2334228
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, James White, 984629, Christopher Abbott

Titulo: Young Tiger
Id: 318373
Fecha Emision: 2015-01-14
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Narrator, 55466, James Corden

Titulo: (T)ERROR
Id: 318972
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Fulvio Canfora, 233334, Alessandro Siani

Titulo: Drunk Stoned Brilliant Dead: The Story of the National Lampoon
Id: 319070
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Leo Hurwitz, 57829, Anthony LaPaglia

Titulo: In Football We Trust
Id: 319074
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Casey Jacobs, 1181313, Maisie Williams

Titulo: Most Likely to Succeed
Id: 319078
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Herself, 960479, Nina Simone

Titulo: The Black Panthers: Vanguard of the Revolution
Id: 319089
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Ajala Bhatt, 62717, Rekha Sharma

Titulo: The Russian Woodpecker
Id: 319092
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself - Interviewee, 455, Paul Haggis

Titulo: Whitney
Id: 319096
Fecha Emision: 2015-01-17
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Many, 1439712, Harmandeep Palminder

Titulo: I Kissed a Girl
Id: 319340
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself / Actor (archive footage), 7171, John Belushi

Titulo: Joker Game
Id: 319669
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jérémie Deprez, 146287, Pio Marmaï

Titulo: Gary Owen: I Agree With Myself
Id: 319971
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Harry Hart / Galahad, 5472, Colin Firth

Titulo: Body
Id: 319999
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nicholas Hathaway, 74568, Chris Hemsworth

Titulo: Volcano
Id: 320001
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles Mortdecai, 85, Johnny Depp

Titulo: Il nome del figlio
Id: 320028
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nick Wild, 976, Jason Statham

Titulo: Resistance
Id: 320179
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jimmy Callahan / Bic, 55638, Kevin Hart

Titulo: Ever Been to the Moon?
Id: 320302
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Connor, 1425134, Milo Parker

Titulo: Wolf Hall
Id: 320311
Fecha Emision: 2015-01-21
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Lingesan, 93191, Vikram

Titulo: Senior Project
Id: 320430
Fecha Emision: 2015-01-07
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Caleb Smith, 93210, Domhnall Gleeson

Titulo: Kyle Kinane: I Liked His Old Stuff Better
Id: 320892
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Raskin, 928575, Jonny Weston

Titulo: Iliza Shlesinger: Freezing Hot
Id: 320996
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michiel de Ruyter, 43643, Frank Lammers

Titulo: Bitter Lake
Id: 321109
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kelly, 75330, Ambyr Childers

Titulo: With This Ring
Id: 321160
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Claire Peterson, 16866, Jennifer Lopez

Titulo: Chronicle of a Blood Merchant
Id: 321191
Fecha Emision: 2015-01-14
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shazam (voice), 1328, Sean Astin

Titulo: Louis C.K.: Live at The Comedy Store
Id: 321594
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles-Ingvar Jönsson, 135726, Simon J. Berger

Titulo: The Throwaways
Id: 321621
Fecha Emision: 2015-01-30
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Zoe McConnell, 59315, Olivia Wilde

Titulo: PMMP – Life is Right Here
Id: 321678
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Giulio Verme / Antonino Verme / Mariottide, 1258076, Maccio Capatonda

Titulo: Classmates
Id: 322039
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Emma, 78030, Ashley Benson

Titulo: Talvivaaran miehet
Id: 322270
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Kressen, 4451, Mark Webber

Titulo: Christ lives in Siberia
Id: 322317
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Father Conway, 32747, Stephen Lang

Titulo: Nice People
Id: 322378
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Diane Doyle, 9281, Elizabeth Banks

Titulo: Sweet Micky for President
Id: 322746
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Final Girl, 1439081, Lola Gave

Titulo: Beautiful & Twisted
Id: 322766
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Oscar Vazquez, 215186, Carlos PenaVega

Titulo: Mel Brooks: Live at the Geffen
Id: 322785
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Teodor Szacki, 127856, Robert Więckiewicz

Titulo: Darkness on the Edge of Town
Id: 323149
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jude, 1023139, Adam Driver

Titulo: The Resurrection of Jake the Snake
Id: 324181
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shank, 9640, Haley Joel Osment

Titulo: Kingdom of Shadows
Id: 324279
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michael Glatze, 17051, James Franco

Titulo: Photographer
Id: 324631
Fecha Emision: 2015-01-08
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Akane Tsunemori (voice), 119143, Kana Hanazawa

Titulo: Pirate's Passage
Id: 324978
Fecha Emision: 2015-01-04
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Mathayus, the Scorpion King, 1215144, Victor Webster

Titulo: Marry Me
Id: 326253
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kim Jong-dae, 1245104, Lee Min-ho

Titulo: Snowden’s Great Escape
Id: 326723
Fecha Emision: 2015-01-12
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Alberto, 34021, Raúl Arévalo

Titulo: Dial a Prayer
Id: 328448
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself, 57563, Elon Musk

Titulo: It's Me, Hilary: The Man Who Drew Eloise
Id: 328799
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Chamberlain, 144501, Jai Koutrae

Titulo: Anti-Social
Id: 330206
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Bog King (voice), 10697, Alan Cumming

Titulo: Robo-Dog
Id: 332212
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Celal Yildiz, 5202, Kostja Ullmann

Titulo: Bana Masal Anlatma
Id: 332534
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jack Peterson, 11662, Jason Lee

Titulo: Little Forest: Winter/Spring
Id: 336026
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nikita, 139459, Vladimir Zelenskiy

Titulo: The Here After
Id: 336806
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Mr. Kim, 142425, Cha In-pyo

Titulo: Almost Mercy
Id: 337073
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Stella, 1400149, Rebecka Josephson

Titulo: Dennis Rodman's Big Bang in PyongYang
Id: 338353
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, James White, 984629, Christopher Abbott

Titulo: Anarchy Parlor
Id: 339342
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Narrator, 55466, James Corden

Titulo: Harry & Snowman
Id: 340223
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Fulvio Canfora, 233334, Alessandro Siani

Titulo: Bolshoi Babylon
Id: 341045
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Leo Hurwitz, 57829, Anthony LaPaglia

Titulo: Convergence
Id: 341050
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Casey Jacobs, 1181313, Maisie Williams

Titulo: Deep Dark
Id: 341051
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Herself, 960479, Nina Simone

Titulo: Carte Blanche
Id: 342765
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Ajala Bhatt, 62717, Rekha Sharma

Titulo: The Saboteurs
Id: 345575
Fecha Emision: 2015-01-04
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself - Interviewee, 455, Paul Haggis

Titulo: The Zohar Secret
Id: 346472
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Many, 1439712, Harmandeep Palminder

Titulo: The Entity
Id: 347767
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself / Actor (archive footage), 7171, John Belushi

Titulo: Víkend
Id: 352917
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jérémie Deprez, 146287, Pio Marmaï

Titulo: Manoman
Id: 353406
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, María, 1460792, María Mercedes Coroy

Titulo: Everything Will Be Okay
Id: 365909
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Paolo Pontecorvo, 57345, Alessandro Gassman

Titulo: Abandoned Dead
Id: 370664
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Giulia, 115208, Liz Solari

Titulo: Nobody Walks in L.A.
Id: 380013
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Thomas Cromwell, 40900, Mark Rylance

Titulo: Helix
Id: 382651
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Peter, 515510, Ryan Potter

Titulo: Romantically Speaking
Id: 403330
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Agent Langstrom, 1070855, Peter Brooke

Titulo: The Secret World of Lewis Carroll
Id: 413011
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Ichiko, 559413, Ai Hashimoto

Titulo: The Morning After
Id: 420346
Fecha Emision: 2015-01-11
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, John, 1457428, Ulrik Munther
23/12/22 11:58:08 INFO zookeeper.ZooKeeper: Initiating client connection, connectString=127.0.0.1:2181 sessionTimeout=90000 watcher=org.apache.hadoop.hbase.zookeeper.ReadOnlyZKClient$$Lambda$94/0x00000008401a5c40@4c3a2d14
23/12/22 11:58:08 INFO zookeeper.ClientCnxnSocket: jute.maxbuffer value is 4194304 Bytes
23/12/22 11:58:08 INFO zookeeper.ClientCnxn: zookeeper.request.timeout value is 0. feature enabled=
23/12/22 11:58:08 INFO zookeeper.ClientCnxn: Opening socket connection to server localhost/127.0.0.1:2181. Will not attempt to authenticate using SASL (unknown error)
23/12/22 11:58:08 INFO zookeeper.ClientCnxn: Socket connection established, initiating session, client: /127.0.0.1:39420, server: localhost/127.0.0.1:2181
23/12/22 11:58:08 INFO zookeeper.ClientCnxn: Session establishment complete on server localhost/127.0.0.1:2181, sessionid = 0x100005211c4000a, negotiated timeout = 40000

Titulo: Uncanny
Id: 137333
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Kressen, 4451, Mark Webber

Titulo: Blackhat
Id: 201088
Fecha Emision: 2015-01-13
Presupuesto: 17752940
Ingresos: 70000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nicholas Hathaway, 74568, Chris Hemsworth

Titulo: Kingsman: The Secret Service
Id: 207703
Fecha Emision: 2015-01-29
Presupuesto: 414351546
Ingresos: 81000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Harry Hart / Galahad, 5472, Colin Firth

Titulo: Mortdecai
Id: 210860
Fecha Emision: 2015-01-21
Presupuesto: 30418560
Ingresos: 60000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles Mortdecai, 85, Johnny Depp

Titulo: The Mask You Live In
Id: 224972
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Backmask
Id: 226458
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Father Conway, 32747, Stephen Lang

Titulo: Project Almanac
Id: 227719
Fecha Emision: 2015-01-29
Presupuesto: 32248241
Ingresos: 12000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Raskin, 928575, Jonny Weston

Titulo: Robot Overlords
Id: 240483
Fecha Emision: 2015-01-29
Presupuesto: 0
Ingresos: 21000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Connor, 1425134, Milo Parker

Titulo: The Boy Next Door
Id: 241251
Fecha Emision: 2015-01-23
Presupuesto: 52425855
Ingresos: 4000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Claire Peterson, 16866, Jennifer Lopez

Titulo: The Lazarus Effect
Id: 243940
Fecha Emision: 2015-01-29
Presupuesto: 64110728
Ingresos: 3300000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Zoe McConnell, 59315, Olivia Wilde

Titulo: Little Accidents
Id: 244260
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Diane Doyle, 9281, Elizabeth Banks

Titulo: German Angst
Id: 252596
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Final Girl, 1439081, Lola Gave

Titulo: The Wedding Ringer
Id: 252838
Fecha Emision: 2015-01-16
Presupuesto: 79799880
Ingresos: 23000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jimmy Callahan / Bic, 55638, Kevin Hart

Titulo: Loucas pra Casar
Id: 261461
Fecha Emision: 2015-01-08
Presupuesto: 0
Ingresos: 3000000
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: I
Id: 263471
Fecha Emision: 2015-01-04
Presupuesto: 0
Ingresos: 16000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Lingesan, 93191, Vikram

Titulo: Spare Parts
Id: 264337
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Oscar Vazquez, 215186, Carlos PenaVega

Titulo: Ex Machina
Id: 264660
Fecha Emision: 2015-01-21
Presupuesto: 36869414
Ingresos: 15000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Caleb Smith, 93210, Domhnall Gleeson

Titulo: Wild Card
Id: 265208
Fecha Emision: 2015-01-14
Presupuesto: 0
Ingresos: 30000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nick Wild, 976, Jason Statham

Titulo: Something, Anything
Id: 271039
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Admiral
Id: 277154
Fecha Emision: 2015-01-29
Presupuesto: 0
Ingresos: 10000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michiel de Ruyter, 43643, Frank Lammers

Titulo: Everly
Id: 277355
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: A Grain of Truth
Id: 278677
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Teodor Szacki, 127856, Robert Więckiewicz

Titulo: Hungry Hearts
Id: 283698
Fecha Emision: 2015-01-15
Presupuesto: 6921
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jude, 1023139, Adam Driver

Titulo: Felix and Meira
Id: 285848
Fecha Emision: 2015-01-11
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The World Made Straight
Id: 289716
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shank, 9640, Haley Joel Osment

Titulo: Tracers
Id: 290764
Fecha Emision: 2015-01-15
Presupuesto: 593683
Ingresos: 11000000
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: I Am Michael
Id: 291869
Fecha Emision: 2015-01-29
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Michael Glatze, 17051, James Franco

Titulo: Psycho-Pass: The Movie
Id: 296917
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Akane Tsunemori (voice), 119143, Kana Hanazawa

Titulo: The Scorpion King: Quest for Power
Id: 297291
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Mathayus, the Scorpion King, 1215144, Victor Webster

Titulo: Justice League: Throne of Atlantis
Id: 297556
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 3500000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Shazam (voice), 1328, Sean Astin

Titulo: Gangnam Blues
Id: 297721
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kim Jong-dae, 1245104, Lee Min-ho

Titulo: The Atticus Institute
Id: 299551
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Sidetracked
Id: 300596
Fecha Emision: 2015-01-30
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Alberto, 34021, Raúl Arévalo

Titulo: Racing Extinction
Id: 300792
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself, 57563, Elon Musk

Titulo: Terminus
Id: 301729
Fecha Emision: 2015-01-30
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, David Chamberlain, 144501, Jai Koutrae

Titulo: Strange Magic
Id: 302429
Fecha Emision: 2015-01-23
Presupuesto: 13603453
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Bog King (voice), 10697, Alan Cumming

Titulo: Young Sophie Bell
Id: 303636
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Hoovey
Id: 305747
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 2
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Partisan
Id: 306482
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Homies
Id: 306543
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Son of Mine
Id: 306547
Fecha Emision: 2015-01-29
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Dark Summer
Id: 306969
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Serial Killer 1
Id: 307103
Fecha Emision: 2015-01-07
Presupuesto: 0
Ingresos: 5290000
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: 88
Id: 307479
Fecha Emision: 2015-01-06
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Vice
Id: 307663
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 10000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kelly, 75330, Ambyr Childers

Titulo: The Visit: An Alien Encounter
Id: 308063
Fecha Emision: 2015-01-26
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The Master Plan
Id: 308160
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 3500000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Charles-Ingvar Jönsson, 135726, Simon J. Berger

Titulo: 3 Türken und ein Baby
Id: 308174
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Celal Yildiz, 5202, Kostja Ullmann

Titulo: Stockholm, Pennsylvania
Id: 308361
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Songs My Brothers Taught Me
Id: 308640
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Away and Back
Id: 308715
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jack Peterson, 11662, Jason Lee

Titulo: The Ouija Experiment 2: Theatre of Death
Id: 309063
Fecha Emision: 2015-01-13
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: 8 New Dates
Id: 309739
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Nikita, 139459, Vladimir Zelenskiy

Titulo: Patterns of Evidence: The Exodus
Id: 309882
Fecha Emision: 2015-01-14
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Seoul Searching
Id: 310001
Fecha Emision: 2015-01-30
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Mr. Kim, 142425, Cha In-pyo

Titulo: A Novel Romance
Id: 311181
Fecha Emision: 2015-01-10
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Roles in the Wind
Id: 311215
Fecha Emision: 2015-01-08
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: My Skinny Sister
Id: 311770
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Stella, 1400149, Rebecka Josephson

Titulo: The Phoenix Project
Id: 312131
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: James White
Id: 312804
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, James White, 984629, Christopher Abbott

Titulo: Ivy
Id: 312849
Fecha Emision: 2015-01-26
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: All She Wishes
Id: 313371
Fecha Emision: 2015-01-15
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Love Forecast
Id: 313628
Fecha Emision: 2015-01-15
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Roald Dahl's Esio Trot
Id: 313867
Fecha Emision: 2015-01-02
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Narrator, 55466, James Corden

Titulo: Baby
Id: 314389
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Body
Id: 314420
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Three Heroes and Julius Caesar
Id: 314946
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: What Men Do! 2
Id: 314952
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 2000000
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Adult Camp
Id: 315049
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Surprised by Love
Id: 315134
Fecha Emision: 2015-01-03
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Lokmanya: Ek Yug Purush
Id: 315226
Fecha Emision: 2015-01-02
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Sneeuwwitje En De Zeven Kleine Mensen: Een Modern Sprookje
Id: 315252
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: We Accept Miracles
Id: 315319
Fecha Emision: 2015-01-02
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Fulvio Canfora, 233334, Alessandro Siani

Titulo: Frau Müller muss weg!
Id: 315335
Fecha Emision: 2015-01-15
Presupuesto: 9127383
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Beck 27 - Rum 302
Id: 315360
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Beck 28 - Familjen
Id: 315362
Fecha Emision: 2015-01-10
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Beaver Trilogy Part IV
Id: 315882
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: My Life as a Dead Girl
Id: 316015
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Misery Loves Comedy
Id: 316067
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: What's Between Us
Id: 316074
Fecha Emision: 2015-01-07
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Tired Moonlight
Id: 316179
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The Sky Above Us
Id: 316310
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Barbie in Princess Power
Id: 316322
Fecha Emision: 2015-01-29
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: A Horse for Summer
Id: 316347
Fecha Emision: 2015-01-06
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Bound
Id: 316410
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The Eichmann Show
Id: 316715
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Leo Hurwitz, 57829, Anthony LaPaglia

Titulo: Above and Below
Id: 316883
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Bridgend
Id: 316885
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Bridal Wave
Id: 317114
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Cyberbully
Id: 317144
Fecha Emision: 2015-01-15
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Casey Jacobs, 1181313, Maisie Williams

Titulo: From A to B
Id: 317214
Fecha Emision: 2015-01-08
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Being Evel
Id: 317655
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Banana Pancakes and the Children of Sticky Rice
Id: 317988
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: What Happened, Miss Simone?
Id: 318044
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Herself, 960479, Nina Simone

Titulo: The Man in the Wall
Id: 318052
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: No Men Beyond This Point
Id: 318054
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Ajala Bhatt, 62717, Rekha Sharma

Titulo: Going Clear: Scientology and the Prison of Belief
Id: 318224
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself - Interviewee, 455, Paul Haggis

Titulo: Meru
Id: 318279
Fecha Emision: 2015-01-25
Presupuesto: 2334228
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Young Tiger
Id: 318373
Fecha Emision: 2015-01-14
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Many, 1439712, Harmandeep Palminder

Titulo: (T)ERROR
Id: 318972
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Drunk Stoned Brilliant Dead: The Story of the National Lampoon
Id: 319070
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself / Actor (archive footage), 7171, John Belushi

Titulo: In Football We Trust
Id: 319074
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Most Likely to Succeed
Id: 319078
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The Black Panthers: Vanguard of the Revolution
Id: 319089
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The Russian Woodpecker
Id: 319092
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Whitney
Id: 319096
Fecha Emision: 2015-01-17
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: I Kissed a Girl
Id: 319340
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Jérémie Deprez, 146287, Pio Marmaï

Titulo: Joker Game
Id: 319669
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Gary Owen: I Agree With Myself
Id: 319971
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Aferim!
Id: 319993
Fecha Emision: 2015-01-22
Presupuesto: 105097
Ingresos: 1379375
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Body
Id: 319999
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Volcano
Id: 320001
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, María, 1460792, María Mercedes Coroy

Titulo: Il nome del figlio
Id: 320028
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Paolo Pontecorvo, 57345, Alessandro Gassman

Titulo: Ratter
Id: 320048
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 500000
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Emma, 78030, Ashley Benson

Titulo: Resistance
Id: 320179
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Ever Been to the Moon?
Id: 320302
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Giulia, 115208, Liz Solari

Titulo: Wolf Hall
Id: 320311
Fecha Emision: 2015-01-21
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Thomas Cromwell, 40900, Mark Rylance

Titulo: Italiano medio
Id: 320316
Fecha Emision: 2015-01-29
Presupuesto: 4541800
Ingresos: 1816720
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Giulio Verme / Antonino Verme / Mariottide, 1258076, Maccio Capatonda

Titulo: Senior Project
Id: 320430
Fecha Emision: 2015-01-07
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Peter, 515510, Ryan Potter

Titulo: Kyle Kinane: I Liked His Old Stuff Better
Id: 320892
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Iliza Shlesinger: Freezing Hot
Id: 320996
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Bitter Lake
Id: 321109
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: With This Ring
Id: 321160
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Chronicle of a Blood Merchant
Id: 321191
Fecha Emision: 2015-01-14
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Caffeinated
Id: 321530
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 200000
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Louis C.K.: Live at The Comedy Store
Id: 321594
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The Throwaways
Id: 321621
Fecha Emision: 2015-01-30
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Agent Langstrom, 1070855, Peter Brooke

Titulo: PMMP – Life is Right Here
Id: 321678
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Classmates
Id: 322039
Fecha Emision: 2015-01-16
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Buddy Hutchins
Id: 322266
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 1200000
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Talvivaaran miehet
Id: 322270
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Christ lives in Siberia
Id: 322317
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Nice People
Id: 322378
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Crumbs
Id: 322614
Fecha Emision: 2015-01-27
Presupuesto: 0
Ingresos: 200000
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Sweet Micky for President
Id: 322746
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Beautiful & Twisted
Id: 322766
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Mel Brooks: Live at the Geffen
Id: 322785
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Darkness on the Edge of Town
Id: 323149
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The Resurrection of Jake the Snake
Id: 324181
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Kingdom of Shadows
Id: 324279
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Photographer
Id: 324631
Fecha Emision: 2015-01-08
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Pirate's Passage
Id: 324978
Fecha Emision: 2015-01-04
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Marry Me
Id: 326253
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Snowden’s Great Escape
Id: 326723
Fecha Emision: 2015-01-12
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Dial a Prayer
Id: 328448
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: It's Me, Hilary: The Man Who Drew Eloise
Id: 328799
Fecha Emision: 2015-01-24
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Anti-Social
Id: 330206
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Robo-Dog
Id: 332212
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Bana Masal Anlatma
Id: 332534
Fecha Emision: 2015-01-09
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Little Forest: Winter/Spring
Id: 336026
Fecha Emision: 2015-01-28
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Ichiko, 559413, Ai Hashimoto

Titulo: The Here After
Id: 336806
Fecha Emision: 2015-01-20
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, John, 1457428, Ulrik Munther

Titulo: Almost Mercy
Id: 337073
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Dennis Rodman's Big Bang in PyongYang
Id: 338353
Fecha Emision: 2015-01-25
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Anarchy Parlor
Id: 339342
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Harry & Snowman
Id: 340223
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Bolshoi Babylon
Id: 341045
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Convergence
Id: 341050
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Daniel, 58019, Ethan Embry

Titulo: Deep Dark
Id: 341051
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Hermann Haig, 1195091, Sean McGrath

Titulo: Carte Blanche
Id: 342765
Fecha Emision: 2015-01-23
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Kacper, 82313, Andrzej Chyra

Titulo: The Saboteurs
Id: 345575
Fecha Emision: 2015-01-04
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Leif Tronstad, 74738, Espen Klouman-Høiner

Titulo: The Zohar Secret
Id: 346472
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: The Entity
Id: 347767
Fecha Emision: 2015-01-22
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Víkend
Id: 352917
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Manoman
Id: 353406
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Everything Will Be Okay
Id: 365909
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Abandoned Dead
Id: 370664
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Doctor Pamela Myers, 97913, Judith O'Dea

Titulo: Nobody Walks in L.A.
Id: 380013
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)

Titulo: Helix
Id: 382651
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Filtano, 1577237, Robert L. Duncan

Titulo: Romantically Speaking
Id: 403330
Fecha Emision: 2015-01-01
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Ariel, 221606, Heather Morris

Titulo: The Secret World of Lewis Carroll
Id: 413011
Fecha Emision: 2015-01-31
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
  0, Himself - Forensic Imagery Analyst, 1670938, David Anley

Titulo: The Morning After
Id: 420346
Fecha Emision: 2015-01-11
Presupuesto: 0
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
//Ejercio_5
23/12/22 11:58:09 INFO zookeeper.ZooKeeper: Session: 0x100005211c4000a closed
23/12/22 11:58:09 INFO zookeeper.ClientCnxn: EventThread shut down for session: 0x100005211c4000a

Titulo: Blade Runner
Id: 78
Fecha Emision: 1982-06-25
Presupuesto: 28000000
Ingresos: 33139618
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Additional Photography, 473, Brian Tufano
  Directing, Director, 578, Ridley Scott
  Production, Producer, 581, Michael Deeley
  Writing, Screenplay, 583, Hampton Fancher
  Writing, Novel, 584, Philip K. Dick
  Crew, Thanks, 584, Philip K. Dick
  Camera, Director of Photography, 594, Jordan Cronenweth
  Sound, Original Music Composer, 595, Vangelis
  Art, Production Design, 596, Lawrence G. Paull
  Production, Casting, 597, Jane Feinberg
  Production, Casting, 598, Mike Fenton
  Production, Casting, 599, Marci Liroff
  Editing, Editor, 600, Marsha Nakashima
  Art, Art Direction, 601, David L. Snyder
  Art, Set Decoration, 602, Linda DeScenna
  Art, Set Decoration, 603, Leslie McCarthy-Frankenheimer
  Costume & Make-Up, Costume Design, 605, Michael Kaplan
  Costume & Make-Up, Costume Design, 606, Charles Knode
  Camera, Additional Photography, 1590, Steven Poster
  Art, Set Decoration, 4712, Thomas L. Roysden
  Writing, Screenplay, 7191, David Webb Peoples
  Production, Production Manager, 50237, Alan Collis
  Production, Publicist, 55244, Saul Kahan
  Art, Production Illustrator, 60283, Tom Southwell
  Sound, Sound mixer, 91875, Bud Alper
  Crew, Stunt Coordinator, 999716, Gary Combs
  Camera, Still Photographer, 1390535, Stephen Vaughan
  Art, Assistant Art Director, 1404757, Stephen Dane
  Art, Construction Coordinator, 1404758, James F. Orendorff
  Crew, Property Master, 1404759, Terry E. Lewis
  Art, Production Illustrator, 1404760, Mentor Huebner
  Art, Production Illustrator, 1404761, Sherman Labby
  Editing, Dialogue Editor, 1404763, Mike Hopkins
  Sound, Sound Editor, 1404764, Peter Pennell
  Camera, Camera Operator, 1404765, Albert Bettcher
  Camera, Camera Operator, 1404766, Dick Colean
  Camera, Camera Operator, 1404767, Robert C. Thomas

Titulo: Gladiator
Id: 98
Fecha Emision: 2000-05-01
Presupuesto: 103000000
Ingresos: 457640427
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Executive Producer, 578, Ridley Scott
  Production, Producer, 929, David Franzoni
  Writing, Screenplay, 929, David Franzoni
  Production, Producer, 930, Branko Lustig
  Production, Producer, 931, Douglas Wick
  Writing, Screenplay, 932, John Logan
  Writing, Screenplay, 933, William Nicholson
  Camera, Director of Photography, 943, John Mathieson
  Art, Production Design, 944, Arthur Max
  Art, Set Decoration, 945, Crispian Sallis
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Sound, Original Music Composer, 947, Hans Zimmer
  Sound, Original Music Composer, 948, Lisa Gerrard
  Production, Casting, 949, Louis DiGiaimo
  Editing, Editor, 950, Pietro Scalia
  Visual Effects, Visual Effects, 951, Colin Coull
  Production, Executive Producer, 2212, Walter F. Parkes
  Sound, Sound, 3193, Scott Martin Gershin
  Art, Supervising Art Director, 4710, Benjamín Fernández
  Crew, Animatronic and Prosthetic Effects, 6060, Neil Corbould
  Art, Art Direction, 7790, Peter Russell
  Crew, Post Production Supervisor, 8532, Lisa Dennis Kennedy
  Art, Art Direction, 8646, Keith Pain
  Production, Executive Producer, 8701, Laurie MacDonald
  Costume & Make-Up, Makeup Artist, 8939, Paul Engelen
  Costume & Make-Up, Hairstylist, 9161, Carmel Jackson
  Art, Assistant Art Director, 9822, Adam O'Neill
  Production, Associate Producer, 12785, Terry Needham
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Crew, Second Unit Cinematographer, 17649, Alexander Witt
  Art, Supervising Art Director, 34513, John King
  Production, Casting Associate, 54489, Stephanie Corsalini
  Art, Supervising Art Director, 71579, David Allday
  Crew, Property Master, 117226, Graeme Purdy
  Sound, Foley, 548439, James Moriana
  Sound, Foley, 548445, Jeffrey Wilhoit
  Camera, Camera Operator, 569913, Branko Knez
  Directing, Assistant Director, 1102140, Adam Somner
  Crew, Stunts, 1185530, Eddie Stacey
  Visual Effects, Visual Effects Producer, 1290901, Nikki Penny
  Costume & Make-Up, Makeup Artist, 1317305, Trefor Proud
  Costume & Make-Up, Hairstylist, 1319624, Alex King
  Costume & Make-Up, Hairstylist, 1319625, Marese Langan
  Costume & Make-Up, Makeup Artist, 1332186, Ivana Primorac
  Camera, Steadicam Operator, 1332515, Klemens Becker
  Costume & Make-Up, Makeup Artist, 1334490, Laura McIntosh
  Art, Greensman, 1335543, Roger Holden
  Sound, Foley, 1338372, Dan O'Connell
  Sound, Sound Effects Editor, 1342657, Jon Title
  Sound, Sound Re-Recording Mixer, 1345595, Scott Millan
  Sound, Foley, 1367493, John T. Cucci
  Crew, Property Master, 1370841, Philip McDonald
  Crew, Stunt Coordinator, 1378239, Phil Neilson
  Editing, First Assistant Editor, 1388921, Chisako Yokoyama
  Sound, Sound Re-Recording Mixer, 1391571, Bob Beemer
  Sound, Sound Effects Editor, 1392081, Randy Kelley
  Camera, Camera Operator, 1392246, Clive Jackson
  Crew, Compositors, 1392629, Simon Stanley-Clamp
  Editing, Dialogue Editor, 1392901, Lauren Stephens
  Camera, Camera Operator, 1393364, Peter Taylor
  Camera, Still Photographer, 1393448, Jaap Buitendijk
  Sound, Sound Re-Recording Mixer, 1394130, Frank A. Montaño
  Art, Assistant Art Director, 1394775, José Luis del Barco
  Visual Effects, Visual Effects Supervisor, 1404221, Tim Burke
  Crew, Unit Publicist, 1405246, Rob Harris
  Sound, ADR & Dubbing, 1406616, Chris Jargo
  Sound, ADR & Dubbing, 1408672, Laura Graham
  Sound, ADR & Dubbing, 1408779, David A. Cohen
  Production, Location Manager, 1410333, Jeremy Johns
  Visual Effects, Visual Effects Supervisor, 1411090, Rob Harvey
  Production, Location Manager, 1411120, Terry Blyther
  Costume & Make-Up, Hairstylist, 1419186, Ivana Nemec
  Crew, CG Supervisor, 1425484, Laurent Hugueniot
  Costume & Make-Up, Hairstylist, 1427823, Graham Johnston
  Art, Property Master, 1428473, Bruce Bigg
  Editing, Color Timer, 1429549, Dale E. Grahn
  Costume & Make-Up, Hairstylist, 1429628, Anita Burger
  Editing, Dialogue Editor, 1454536, Simon Coke
  Costume & Make-Up, Makeup Artist, 1456365, Melissa Lackersteen
  Costume & Make-Up, Makeup Artist, 1456366, Jo Allen
  Crew, Scenic Artist, 1456369, Cynthia Sadler
  Crew, Scenic Artist, 1456370, Bob Walker
  Crew, Animatronic and Prosthetic Effects, 1456371, Astrig Akseralian
  Crew, Visual Effects Editor, 1456373, Wesley Sewell
  Visual Effects, Visual Effects Supervisor, 1456374, John Nelson
  Camera, Camera Operator, 1456375, Ben Gooder
  Camera, Camera Operator, 1456376, Felix Schroer
  Camera, Camera Technician, 1456378, Agapios Louka
  Production, Casting, 1456379, Mustapha Charif
  Production, Casting, 1456380, Kathleen Mackie
  Editing, First Assistant Editor, 1456381, Michael Reynolds
  Sound, Music Editor, 1456383, Dashiell Rae
  Crew, Transportation Coordinator, 1456384, Gerry Gore
  Production, Location Manager, 1456385, Mike Higgins
  Crew, Stunts, 1506768, Miroslav Lhotka
  Lighting, Gaffer, 1597990, Daniele Botteselle
  Crew, Special Effects, 1603859, John Evans
  Crew, Title Graphics, 1604352, Robert Dawson
  Directing, Assistant Director, 1643667, Ali Cherkaoui

Titulo: Alien
Id: 348
Fecha Emision: 1979-05-25
Presupuesto: 11000000
Ingresos: 104931801
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Casting, 668, Mary Selway
  Production, Producer, 915, David Giler
  Production, Producer, 1723, Walter Hill
  Sound, Original Music Composer, 1760, Jerry Goldsmith
  Art, Production Design, 4616, Michael Seymour
  Writing, Screenplay, 5045, Dan O'Bannon
  Production, Executive Producer, 5046, Ronald Shusett
  Writing, Writer, 5046, Ronald Shusett
  Production, Producer, 5053, Gordon Carroll
  Production, Producer, 5054, Ivor Powell
  Camera, Director of Photography, 5055, Derek Vanlint
  Editing, Editor, 5056, Terry Rawlings
  Editing, Editor, 5057, Peter Weatherley
  Art, Art Direction, 5058, Roger Christian
  Art, Production Design, 5058, Roger Christian
  Art, Art Direction, 5059, Leslie Dilley
  Art, Set Decoration, 5060, Ian Whittaker
  Costume & Make-Up, Costume Design, 5061, John Mollo
  Sound, Sound Editor, 5062, Robert Hathaway
  Art, Production Design, 9136, H.R. Giger
  Crew, Special Effects, 9402, Brian Johnson
  Production, Casting, 23349, Mary Goldberg
  Art, Conceptual Design, 62460, Jean Giraud
  Art, Assistant Art Director, 1378834, Jonathan Amberston
  Crew, Property Master, 1378835, Dave Jordan
  Editing, Dialogue Editor, 1378836, Bryan Tilling
  Sound, Dolby Consultant, 1378837, Max Bell
  Crew, Stunt Coordinator, 1378838, Roy Scammell
  Camera, Still Photographer, 1378839, Bob Penn

Titulo: Black Hawk Down
Id: 855
Fecha Emision: 2001-12-28
Presupuesto: 92000000
Ingresos: 172989651
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Producer, 770, Jerry Bruckheimer
  Production, Casting, 897, Bonnie Timmermann
  Production, Executive Producer, 930, Branko Lustig
  Production, Unit Production Manager, 930, Branko Lustig
  Art, Production Design, 944, Arthur Max
  Sound, Original Music Composer, 947, Hans Zimmer
  Editing, Editor, 950, Pietro Scalia
  Camera, Director of Photography, 1129, Slawomir Idziak
  Production, Executive Producer, 2444, Mike Stenson
  Production, Executive Producer, 2446, Chad Oman
  Production, Associate Producer, 2448, Pat Sandston
  Sound, Music Supervisor, 5132, Bob Badami
  Art, Supervising Art Director, 5673, Marco Trentini
  Visual Effects, Special Effects Supervisor, 6060, Neil Corbould
  Art, Art Direction, 7789, Cliff Robinson
  Art, Art Direction, 8646, Keith Pain
  Camera, Steadicam Operator, 8673, Daniele Massaccesi
  Costume & Make-Up, Costume Design, 11271, Sammy Sheldon
  Sound, Supervising ADR Editor, 12562, Anna MacKenzie
  Writing, Novel, 12782, Mark Bowden
  Writing, Screenplay, 12783, Ken Nolan
  Production, Associate Producer, 12785, Terry Needham
  Directing, First Assistant Director, 12785, Terry Needham
  Production, Executive Producer, 12786, Simon West
  Art, Set Decoration, 12787, Elli Griff
  Costume & Make-Up, Costume Design, 12788, David Murphy
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Production, Executive In Charge Of Production, 15004, Charles Newirth
  Art, Art Direction, 16595, Pier Luigi Basile
  Crew, Additional Music, 19016, Michael Brook
  Art, Art Direction, 23364, Gianni Giovagnoni
  Art, Art Direction, 34512, Ivo Hušnjak
  Production, Assistant Production Coordinator, 40838, Damian Anderson
  Production, Casting Associate, 60935, Seth Yanklewitz
  Sound, Music Editor, 63421, Marc Streitenfeld
  Camera, Aerial Camera (suggest in addition to Helicopter Camera), 91123, Michael Kelem
  Editing, Dialogue Editor, 91891, Mark L. Mangino
  Sound, Production Sound Mixer, 105780, Chris Munro
  Crew, Property Master, 117226, Graeme Purdy
  Costume & Make-Up, Key Hair Stylist, 138639, Giancarlo De Leonardis
  Crew, Armorer, 570129, Branko Repalust
  Directing, Script Supervisor, 570136, Nada Pinter
  Production, Production Supervisor, 998152, Lucio Trentini
  Sound, Foley, 1116937, John Roesch
  Crew, Armory Coordinator, 1117347, Simon Atherton
  Sound, Boom Operator, 1311960, Andrew Griffiths
  Costume & Make-Up, Wardrobe Supervisor, 1331983, Dana Schondelmeyer
  Art, Greensman, 1335543, Roger Holden
  Visual Effects, Visual Effects Supervisor, 1337418, Nathan McGuinness
  Sound, Foley, 1338372, Dan O'Connell
  Sound, Additional Sound Re-Recording Mixer, 1342242, Rick Ash
  Sound, Foley Editor, 1352966, Michael Hertlein
  Sound, Foley, 1367493, John T. Cucci
  Sound, Sound Effects Editor, 1367667, Perry Robertson
  Crew, Armorer, 1373558, Nick Komornicki
  Crew, Stunt Coordinator, 1378239, Phil Neilson
  Directing, Script Supervisor, 1385884, Sally Jones
  Editing, First Assistant Editor, 1388921, Chisako Yokoyama
  Editing, Dialogue Editor, 1392901, Lauren Stephens
  Camera, Camera Operator, 1394783, Martin Kenzie
  Production, Casting, 1398505, Suzanne M. Smith
  Sound, Sound Re-Recording Mixer, 1399141, Michael Minkler
  Production, Production Supervisor, 1399484, Angela Quiles
  Lighting, Electrician, 1403545, Dean Brkic
  Costume & Make-Up, Key Makeup Artist, 1404200, Fabrizio Sforza
  Crew, Makeup Effects, 1404201, Rob Mayor
  Production, Production Manager, 1404202, Ahmed Darif
  Production, Production Manager, 1404203, T. David Pash
  Production, Production Manager, 1404204, Jamal Souissi
  Crew, Post Production Supervisor, 1404205, Teresa Kelly
  Art, Art Department Coordinator, 1404206, Annick Biltresse
  Art, Set Designer, 1404207, Roberta Federico
  Art, Set Designer, 1404208, Monica Sallustio
  Art, Leadman, 1404209, Erik Mulet
  Sound, Supervising Sound Editor, 1404212, Karen Baker Landers
  Crew, Sound Recordist, 1404213, Andrea Eliseyan
  Editing, Dialogue Editor, 1404214, Stephanie Flack
  Sound, Sound Effects Editor, 1404215, Gregory Hainer
  Sound, Sound Effects Editor, 1404216, Michael A. Reagan
  Sound, Sound Effects Editor, 1404217, Peter Staubli
  Sound, Sound Re-Recording Mixer, 1404218, Myron Nettinga
  Crew, Special Effects Coordinator, 1404219, Carol McAulay
  Crew, Special Effects Coordinator, 1404220, Mark Meddings
  Visual Effects, Visual Effects Supervisor, 1404221, Tim Burke
  Crew, Visual Effects Editor, 1404222, Kristopher Kasper
  Crew, Visual Effects Editor, 1404223, Lars Vinther
  Visual Effects, Visual Effects Producer, 1404225, Lindsay Hallett
  Camera, Still Photographer, 1404230, Sidney Ray Baldwin
  Lighting, Chief Lighting Technician, 1404231, Marek Modzelewski
  Costume & Make-Up, Set Costumer, 1404232, Ali Lammari
  Costume & Make-Up, Set Costumer, 1404233, Adam Roach
  Crew, Transportation Coordinator, 1404234, Ravi Dube
  Crew, Unit Publicist, 1404235, Michael Singer
  Production, Location Manager, 1404238, Khalid Nekmouche
  Crew, Dialect Coach, 1404241, Sandra Butterworth
  Production, Location Manager, 1404243, Majid Aoulad Abdellah
  Camera, Aerial Director of Photography, 1404244, John Marzano
  Sound, ADR Editor, 1404841, Zack Davis
  Crew, Carpenter, 1405377, Francesco Valento
  Sound, Supervising Dialogue Editor, 1405382, Chris Hogan
  Crew, CG Supervisor, 1425484, Laurent Hugueniot
  Crew, Utility Stunts, 1444646, Stanislav Satko
  Editing, Associate Editor, 1456373, Wesley Sewell
  Editing, First Assistant Editor, 1456381, Michael Reynolds
  Writing, Storyboard, 1487590, Sylvain Despretz
  Writing, Story Editor, 1510846, René Brar
  Crew, Stand In, 1525014, Baron Jay
  Sound, Music Supervisor, 1530166, Kathy Nelson
  Art, Construction Coordinator, 1532615, Dan Pemberton
  Costume & Make-Up, Costume Coordinator, 1535950, Darryl M. Athons
  Production, Researcher, 1536521, Vanessa Bendetti
  Crew, Armorer, 1536582, Tommy Dunne
  Crew, Armorer, 1536588, John Nixon
  Crew, Armorer, 1536589, Trevor Rochester
  Camera, First Assistant Camera, 1536592, Henryk Jedynak
  Lighting, Lighting Technician, 1536593, Jacek Kurowski
  Visual Effects, Visual Effects Coordinator, 1536594, Laya Armian
  Editing, Color Timer, 1550730, Bob Kaiser
  Art, Painter, 1554018, Glauco Isidori
  Costume & Make-Up, Hairstylist, 1554019, Michele Vigliotta
  Costume & Make-Up, Prosthetic Supervisor, 1554020, Simon Rose
  Crew, Second Unit, 1554023, Nicholas Livesey
  Crew, Set Medic, 1554024, Celine Dechanet Painchaux
  Crew, Set Production Assistant, 1554025, Pierre Ellul
  Crew, Stunts, 1554026, Younes Afroukh
  Crew, Transportation Captain, 1554028, David Pash
  Production, Unit Production Manager, 1554029, Pamela Hochschartner
  Lighting, Best Boy Electric, 1554030, Najib Ben Fares
  Production, Associate Producer, 1554033, Harry Humphries
  Production, Production Accountant, 1554037, Donna Glasser-Hancock
  Sound, First Assistant Sound Editor, 1554039, Tony Negrete
  Sound, Orchestrator, 1554041, Bruce Fowler
  Sound, Sound Engineer, 1554044, Kevin Globerman
  Visual Effects, 3D Artist, 1554045, Paul Amer
  Visual Effects, Digital Compositors, 1554046, Chris Elson
  Camera, Camera Technician, 1554047, Stefan Baur
  Art, Set Dresser, 1554048, Mark Allett
  Sound, Assistant Sound Editor, 1580665, Todd Egan
  Camera, Key Grip, 1592605, David Appleby
  Lighting, Gaffer, 1610679, Mateusz Kuzniak
  Crew, Aerial Coordinator, 1685460, David Paris
  Art, Assistant Property Master, 1739747, Steve Payne
  Camera, Camera Loader, 1739760, Abdellatif El Ansary
  Camera, Dolly Grip, 1739761, Mic Mueller
  Camera, Grip, 1739763, Lahcen Herraf
  Costume & Make-Up, Makeup Artist, 1739770, Gianbattista Graziano
  Crew, Pilot, 1739822, Francisco Paco Garcia
  Directing, Second Assistant Director, 1739825, Darin Rivetti
  Directing, Third Assistant Director, 1739826, William Dodds
  Production, Casting Assistant, 1739828, Jose Cabrera
  Sound, Musician, 1739829, Jim Dooley
  Visual Effects, 2D Artist, 1739830, Hani AlYousif

Titulo: 1492: Conquest of Paradise
Id: 1492
Fecha Emision: 1992-10-09
Presupuesto: 47000000
Ingresos: 7191399
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Sound, Music Editor, 296, Robin Clarke
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Sound, Original Music Composer, 595, Vangelis
  Costume & Make-Up, Costume Design, 606, Charles Knode
  Production, Casting, 949, Louis DiGiaimo
  Editing, Editor, 2705, William M. Anderson
  Production, Casting, 3311, Priscilla John
  Art, Supervising Art Director, 4710, Benjamín Fernández
  Art, Supervising Art Director, 5021, Leslie Tomkins
  Camera, Director of Photography, 7783, Adrian Biddle
  Art, Assistant Art Director, 7790, Peter Russell
  Production, Executive Producer, 8374, Iain Smith
  Art, Art Direction, 8382, Kevin Phipps
  Sound, Supervising Sound Editor, 9854, Jim Shields
  Visual Effects, Visual Effects Supervisor, 10721, Kent Houston
  Crew, Stunt Coordinator, 10976, Greg Powell
  Editing, Editor, 16403, Françoise Bonnot
  Production, Producer, 16928, Alain Goldman
  Production, Executive Producer, 17398, Mimi Polk Gitlin
  Art, Production Design, 17400, Norris Spencer
  Writing, Author, 21269, Roselyne Bosch
  Editing, Editor, 21271, Armen Minasian
  Editing, Editor, 21272, Les Healey
  Camera, Camera Operator, 40765, David Worley
  Camera, Still Photographer, 40796, David Appleby
  Editing, Editor, 44046, Deborah Zeitman
  Art, Art Direction, 75799, Martin Hitchcock
  Production, Location Manager, 75804, Kevin De La Noy
  Art, Set Decoration, 100983, Ann Mollo
  Art, Art Direction, 190090, Luke Scott
  Production, Producer, 550414, Rose Bosch
  Production, Casting, 577810, Dan Parada
  Production, Location Manager, 947694, Mark Albela
  Production, Producer, 948498, Marc Boyman
  Production, Producer, 980086, Garth Thomas
  Lighting, Gaffer, 1010007, Francesc Brualla
  Production, Producer, 1102072, Pere Fages
  Directing, Script Supervisor, 1262129, Luca Kouimelis
  Art, Art Direction, 1327919, Antonio Patón
  Costume & Make-Up, Costume Design, 1327921, Barbara Rutter
  Crew, Property Master, 1335181, Terry Wells
  Art, Assistant Art Director, 1377119, Tony Rimmington
  Art, Assistant Art Director, 1394774, Luciano Arroyo
  Art, Assistant Art Director, 1394775, José Luis del Barco
  Art, Assistant Art Director, 1394776, Amado Conejo
  Crew, Property Master, 1394777, Charles Torbett
  Art, Greensman, 1394778, Camilo Lira Colin
  Art, Greensman, 1394779, German Ramirez
  Art, Sculptor, 1394780, Peter Voysey
  Lighting, Gaffer, 1394782, Kevin Day
  Camera, Camera Operator, 1394783, Martin Kenzie
  Directing, Script Supervisor, 1394786, Guillermo Cano
  Production, Location Manager, 1394787, Juan Carlos Caro
  Crew, Chef, 1394789, Gina McShane
  Crew, Chef, 1394790, Luis Puig
  Production, Location Manager, 1394791, Eduardo Santana
  Crew, Chef, 1394792, John Whelan

Titulo: Kingdom of Heaven
Id: 1495
Fecha Emision: 2005-05-03
Presupuesto: 130000000
Ingresos: 211643158
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Casting, 474, Jina Jay
  Production, Casting, 495, Debra Zane
  Editing, Editor, 563, Dody Dorn
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Executive Producer, 930, Branko Lustig
  Production, Unit Production Manager, 930, Branko Lustig
  Camera, Director of Photography, 943, John Mathieson
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Production, Casting, 4406, Antoinette Boulat
  Sound, Original Music Composer, 5553, Harry Gregson-Williams
  Art, Supervising Art Director, 5673, Marco Trentini
  Visual Effects, Special Effects Supervisor, 6060, Neil Corbould
  Camera, Steadicam Operator, 8673, Daniele Massaccesi
  Camera, Camera Operator, 8674, Martin Hume
  Costume & Make-Up, Makeup Designer, 8939, Paul Engelen
  Production, Co-Producer, 10903, Henning Molfenter
  Production, Executive Producer, 12785, Terry Needham
  Sound, Sound Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Sound, Sound Effects Editor, 15331, Bryan Bowen
  Production, Co-Producer, 19619, Thierry Potok
  Art, Set Decoration, 20507, Sonja Klaus
  Crew, Second Unit Cinematographer, 22100, Hugh Johnson
  Art, Art Direction, 23453, Robert Cowper
  Writing, Screenplay, 34510, William Monahan
  Production, Executive Producer, 34511, Lisa Ellzey
  Art, Art Direction, 34512, Ivo Hušnjak
  Art, Art Direction, 34513, John King
  Sound, Assistant Sound Editor, 40769, David Mackie
  Sound, Sound Mixer, 40772, David Stephenson
  Sound, Boom Operator, 40773, Gary Dodkin
  Camera, Still Photographer, 40796, David Appleby
  Crew, Post-Production Manager, 60934, Patrick Esposito
  Camera, First Assistant Camera, 60941, Ben Wilson
  Sound, Music Supervisor, 63421, Marc Streitenfeld
  Crew, Visual Effects Editor, 67201, Ian Differ
  Art, Construction Coordinator, 92214, Alain Brochu
  Visual Effects, Visual Effects Producer, 113674, Victoria Alonso
  Art, Sculptor, 117220, Colin Jackman
  Art, Property Master, 117226, Graeme Purdy
  Visual Effects, Visual Effects Supervisor, 122274, Peter Chiang
  Production, Line Producer, 582915, José Luis Escolar
  Production, Co-Producer, 947694, Mark Albela
  Production, Co-Producer, 959332, Denise O'Dell
  Crew, Additional Music, 1001706, Stephen Barton
  Art, Construction Foreman, 1085575, Damir Gabelica
  Art, Art Direction, 1087318, Carlos Bodelón
  Production, Unit Manager, 1119466, Alex Corven Caronia
  Lighting, Rigging Grip, 1141914, Emanuele Salvatore
  Costume & Make-Up, Hairstylist, 1182554, Marcelle Genovese
  Production, Casting Associate, 1212071, Tannis Vallely
  Costume & Make-Up, Costume Supervisor, 1322137, Clare Spragge
  Art, Set Designer, 1323112, Iñigo Navarro
  Crew, CG Supervisor, 1373716, Gary Brozenich
  Lighting, Gaffer, 1373728, Chuck Finch
  Sound, Sound Recordist, 1374790, Daniel Urdiales
  Crew, Post Production Assistant, 1389524, Carmen Ruiz de Huidobro
  Directing, Script Supervisor, 1389548, Anna Worley
  Crew, Sequence Supervisor, 1394721, Adam Gascoyne
  Art, Assistant Art Director, 1398083, Abdellah Baadil
  Lighting, Lighting Artist, 1400403, Shawn Walsh
  Lighting, Rigging Gaffer, 1403545, Dean Brkic
  Production, Publicist, 1403550, Steve Newman
  Production, Associate Producer, 1404205, Teresa Kelly
  Crew, Special Effects Coordinator, 1404220, Mark Meddings
  Camera, Aerial Director of Photography, 1404244, John Marzano
  Crew, Transportation Coordinator, 1405243, Brian Baverstock
  Art, Art Department Coordinator, 1405374, Francesca Birri
  Editing, Dialogue Editor, 1408378, Simon Chase
  Art, Art Direction, 1412085, Alessandro Alberti
  Visual Effects, Visual Effects Coordinator, 1417821, Claudia Dehmel
  Sound, Foley Editor, 1418322, Harry Barnes
  Sound, ADR & Dubbing, 1424935, Paul Conway
  Crew, Dialect Coach, 1457374, Roisin Carty
  Production, Associate Producer, 1463279, Ty Warren
  Production, Co-Producer, 1471199, Bruce Devan
  Production, Production Manager, 1471199, Bruce Devan
  Crew, Set Production Assistant, 1475344, Topaz Adizes
  Production, Line Producer, 1476831, Karim Abouobayd
  Crew, Motion Capture Artist, 1559186, Gary Roberts
  Art, Painter, 1574114, Giancarlo Di Fusco
  Writing, Storyboard, 1574145, Cristiano Donzelli
  Crew, Video Assist Operator, 1578650, Robert Hamilton
  Costume & Make-Up, Makeup Artist, 1579406, Mariam Lee Abounouom
  Costume & Make-Up, Costume Design, 1583781, Louis Joon
  Camera, Grip, 1592605, David Appleby
  Production, Production Accountant, 1607659, Giorgio Catalano
  Art, Production Illustrator, 1621395, Lora E. Revitt
  Crew, Stunts, 1627984, Rachid Abbad
  Crew, Armorer, 1698595, Brian Bero
  Art, Art Department Assistant, 1733726, Saida Elidrissi
  Costume & Make-Up, Assistant Costume Designer, 1739256, Andrea Cripps
  Art, Greensman, 1846280, Fatiha Aitbadi
  Camera, Additional Camera, 1846288, Brahim Ait Belkas
  Costume & Make-Up, Set Costumer, 1846738, Gabi Brown
  Crew, Carpenter, 1846739, Robert Capan
  Crew, CGI Supervisor, 1846740, John Harvey
  Crew, Driver, 1846742, Diego Campos
  Crew, Loader, 1846744, Lewis Hume
  Crew, Mix Technician, 1846746, Esther Smith
  Crew, Stand In, 1846747, Abdellah Achir
  Crew, Stunt Coordinator, 1846748, Gustáv Kyselica
  Crew, Transportation Captain, 1846749, El Mahjoub Najma
  Crew, Unit Publicist, 1846750, Quinn Donoghue
  Crew, Utility Stunts, 1846751, Oleg Botin
  Directing, Assistant Director, 1846755, Adil Abdelwahab
  Lighting, Electrician, 1846758, Sam Horsefield
  Lighting, Lighting Technician, 1846759, Fred Brown
  Production, Location Manager, 1846762, Gonzalo Cañellas
  Production, Production Coordinator, 1846763, Patricia Nieto
  Production, Production Supervisor, 1846764, Kimberley Ann Berdy
  Visual Effects, Digital Compositors, 1846766, Judy Barr

Titulo: Thelma & Louise
Id: 1541
Fecha Emision: 1991-05-24
Presupuesto: 16000000
Ingresos: 45361000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Sound, Original Music Composer, 947, Hans Zimmer
  Production, Casting, 949, Louis DiGiaimo
  Costume & Make-Up, Costume Design, 5710, Elizabeth McBride
  Sound, Music Editor, 5712, Laura Perlman
  Camera, Director of Photography, 7783, Adrian Biddle
  Art, Art Direction, 7849, Lisa Dean
  Sound, Supervising Sound Editor, 9854, Jim Shields
  Crew, Dialect Coach, 13050, Tim Monich
  Art, Set Decoration, 13677, Anne H. Ahrens
  Sound, ADR Editor, 14459, John Poyner
  Crew, Stunt Coordinator, 16659, Bobby Bass
  Production, Co-Producer, 17397, Callie Khouri
  Writing, Screenplay, 17397, Callie Khouri
  Production, Producer, 17398, Mimi Polk Gitlin
  Editing, Editor, 17399, Thom Noble
  Art, Production Design, 17400, Norris Spencer
  Camera, Camera Operator, 17649, Alexander Witt
  Directing, First Assistant Director, 55600, Steve Danton
  Costume & Make-Up, Hairstylist, 74968, Leslie Ann Anderson
  Costume & Make-Up, Makeup Artist, 74969, Richard Arrington
  Production, Unit Production Manager, 76160, Mel Dellar
  Costume & Make-Up, Hairstylist, 90194, Anthony Cortino
  Costume & Make-Up, Hairstylist, 548413, Karl Wesson
  Camera, Key Grip, 557873, Bob Rose
  Directing, Script Supervisor, 1262129, Luca Kouimelis
  Camera, Still Photographer, 1272269, Roland Neveu
  Crew, Aerial Coordinator, 1278542, Robert 'Bobby Z' Zajonc
  Costume & Make-Up, Key Costumer, 1380704, Taneia Lednicky
  Art, Property Master, 1389589, Vic Petrotta Jr.
  Crew, Special Effects Coordinator, 1403399, Stan Parks
  Camera, Aerial Director of Photography, 1403415, David B. Nowell
  Art, Leadman, 1425908, Kenneth Turek
  Production, Co-Producer, 1434780, Dean O'Brien
  Production, Unit Production Manager, 1434780, Dean O'Brien
  Sound, Music Supervisor, 1530166, Kathy Nelson
  Costume & Make-Up, Makeup Artist, 1531899, Bonita DeHaven
  Art, Painter, 1565941, Gary Clark
  Sound, Boom Operator, 1574659, Timothy P. Salmon
  Sound, Sound Effects Editor, 1621243, Bob Risk
  Camera, Dolly Grip, 1760567, Brad Rea
  Art, Set Designer, 1805997, Alan S. Kaye
  Art, Title Designer, 1806132, Anthony Goldschmidt
  Art, Construction Coordinator, 1875004, Richard J. Bayard
  Art, Construction Foreman, 1875007, Roger M. Janson
  Art, Construction Foreman, 1875009, Jim Olson
  Art, Greensman, 1875012, Robert Butch Samarzich
  Art, Construction Foreman, 1875014, Scott Snyder
  Art, Construction Foreman, 1875015, Mark Vitale
  Lighting, Best Boy Electrician, 1875016, Paul Amorelli
  Camera, Dolly Grip, 1875017, R. Scott Judge
  Production, Production Coordinator, 1875075, Christine Baer
  Crew, Pilot, 1875076, Don Hildebrand

Titulo: Black Rain
Id: 4105
Fecha Emision: 1989-09-22
Presupuesto: 30000000
Ingresos: 45892212
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Art, Set Decoration, 796, John M. Dwyer
  Sound, Original Music Composer, 947, Hans Zimmer
  Editing, Editor, 1047, Tom Rolf
  Production, Casting, 1221, Dianne Crittenden
  Art, Art Direction, 2083, Herman F. Zimmerman
  Camera, Director of Photography, 2209, Jan de Bont
  Art, Art Direction, 2999, John Jay Moore
  Art, Set Decoration, 4188, Leslie Bloom
  Costume & Make-Up, Costume Design, 7735, Ellen Mirojnick
  Art, Set Decoration, 14342, Richard C. Goddard
  Art, Production Design, 17400, Norris Spencer
  Production, Unit Production Manager, 17630, Michael Tadross
  Art, Set Decoration, 17877, Alan Hicks
  Writing, Author, 19893, Warren Lewis
  Production, Casting Assistant, 25830, Debi Manwiller
  Writing, Author, 34692, Craig Bolotin
  Production, Executive Producer, 34692, Craig Bolotin
  Production, Producer, 34693, Stanley R. Jaffe
  Production, Executive Producer, 34694, Julie Kirkham
  Production, Producer, 34695, Sherry Lansing
  Production, Line Producer, 34696, Yosuke Mizuno
  Production, Casting Associate, 35491, Joy Dickson
  Production, Unit Production Manager, 76160, Mel Dellar
  Crew, Pilot, 91042, Al Cerullo
  Production, Associate Producer, 113225, Alan Poul
  Production, Location Manager, 553347, Atsushi Takayama
  Directing, Script Supervisor, 1262129, Luca Kouimelis
  Crew, Pilot, 1278542, Robert 'Bobby Z' Zajonc
  Production, Location Manager, 1453320, Eric Klosterman
  Production, Unit Production Manager, 1551963, David Salven
  Production, Location Manager, 1645977, Ken Haber
  Production, Casting, 1685817, Nobuaki Murooka
  Art, Set Designer, 1691936, James R. Bayliss
  Production, Unit Production Manager, 1782974, William Watkins
  Art, Set Designer, 1805997, Alan S. Kaye
  Art, Set Designer, 1805998, Robert Maddy
  Production, Location Manager, 1806126, Robert Doyle
  Production, Location Manager, 1806127, Susumu Ejima
  Production, Location Manager, 1806128, Kazuaki Enomoto
  Production, Location Manager, 1806129, Kenichi Horii
  Production, Location Manager, 1806130, Steven Shkolnik
  Art, Title Designer, 1806132, Anthony Goldschmidt

Titulo: G.I. Jane
Id: 4421
Fecha Emision: 1997-08-22
Presupuesto: 50000000
Ingresos: 48169156
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Producer, 551, Suzanne Todd
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Production, Casting, 949, Louis DiGiaimo
  Editing, Editor, 950, Pietro Scalia
  Production, Producer, 3416, Demi Moore
  Production, Producer, 4504, Roger Birnbaum
  Sound, Original Music Composer, 7020, Trevor Jones
  Costume & Make-Up, Costume Design, 7719, Marilyn Vance
  Art, Art Direction, 8285, Richard L. Johnson
  Art, Set Decoration, 11079, Cindy Carr
  Camera, Director of Photography, 22100, Hugh Johnson
  Writing, Screenplay, 28239, David Twohy
  Writing, Screenplay, 37208, Danielle Alexandra
  Production, Casting, 577752, Brett Goldstein

Titulo: American Gangster
Id: 4982
Fecha Emision: 2007-11-02
Presupuesto: 100000000
Ingresos: 266465037
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Producer, 339, Brian Grazer
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Executive Producer, 930, Branko Lustig
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Production, Executive Producer, 2260, Steven Zaillian
  Writing, Screenplay, 2260, Steven Zaillian
  Production, Casting, 2952, Avy Kaufman
  Production, Co-Producer, 5286, Jonathan Filley
  Art, Set Decoration, 6191, Leslie E. Rollins
  Production, Executive Producer, 7163, Nicholas Pileggi
  Camera, Director of Photography, 10688, Harris Savides
  Art, Set Decoration, 12258, Beth A. Rubino
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Art, Art Direction, 27040, Nicholas Lundy
  Writing, Writer, 34542, Mark Jacobson
  Production, Executive Producer, 40374, Michael Costigan
  Production, Executive Producer, 40375, James Whitaker
  Directing, Assistant Director, 60858, Apichart Chusakul
  Sound, Original Music Composer, 63421, Marc Streitenfeld
  Crew, Thanks, 65605, Muhammad Ali
  Crew, Thanks, 107375, Joe Frazier
  Crew, Utility Stunts, 206398, John Cenatiempo
  Editing, Dialogue Editor, 548437, Kimaree Long
  Camera, Camera Operator, 957361, Craig Haagensen
  Camera, Camera Operator, 983118, Larry McConkey
  Camera, Steadicam Operator, 983118, Larry McConkey
  Editing, First Assistant Editor, 1017296, Billy Rich
  Sound, Music Editor, 1049333, Del Spiva
  Crew, Stunt Coordinator, 1074163, G.A. Aguilar
  Sound, Additional Soundtrack, 1216495, Anthony Hamilton
  Costume & Make-Up, Set Costumer, 1333607, Hartsell Taylor
  Sound, Sound Effects Editor, 1342657, Jon Title
  Editing, Dialogue Editor, 1342658, Frederick H. Stahly
  Costume & Make-Up, Makeup Artist, 1353528, Felice Diamond
  Costume & Make-Up, Makeup Artist, 1378068, Carl Fullerton
  Sound, Sound Re-Recording Mixer, 1391571, Bob Beemer
  Sound, Sound Re-Recording Mixer, 1399141, Michael Minkler
  Production, Production Coordinator, 1399484, Angela Quiles
  Crew, Post Production Supervisor, 1404205, Teresa Kelly
  Sound, Supervising Sound Editor, 1404212, Karen Baker Landers
  Sound, Sound Effects Editor, 1404217, Peter Staubli
  Crew, Unit Publicist, 1405246, Rob Harris
  Sound, Sound Effects Editor, 1406390, Dan Hegeman
  Costume & Make-Up, Hairstylist, 1410208, Bert Reo Anderson
  Costume & Make-Up, Hair Department Head, 1414488, Kenneth Walker
  Directing, Script Supervisor, 1464541, Mary A. Kelly
  Production, Casting Associate, 1473182, Elizabeth Greenberg
  Sound, Music Supervisor, 1530166, Kathy Nelson
  Camera, Still Photographer, 1537446, David Lee
  Sound, Production Sound Mixer, 1551041, William Sarokin
  Editing, Color Timer, 1552549, David Orr
  Sound, Boom Operator, 1565211, George Leong
  Art, Art Department Coordinator, 1565212, Julia G. Hickman
  Crew, Stunts, 1579312, Gabriel Hansen
  Camera, Grip, 1606370, Matt Blades

Titulo: Someone to Watch Over Me
Id: 31650
Fecha Emision: 1987-10-09
Presupuesto: 17000000
Ingresos: 10278549
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Costume & Make-Up, Costume Design, 557, Colleen Atwood
  Directing, Director, 578, Ridley Scott
  Writing, Writer, 2357, Howard Franklin

Titulo: Matchstick Men
Id: 7270
Fecha Emision: 2003-09-01
Presupuesto: 62000000
Ingresos: 65565672
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Executive Producer, 24, Robert Zemeckis
  Production, Producer, 30, Steve Starkey
  Production, Casting Associate, 494, Terri Taylor
  Production, Casting, 495, Debra Zane
  Editing, Editor, 563, Dody Dorn
  Sound, Music Supervisor, 563, Dody Dorn
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Costume & Make-Up, Costume Design, 605, Michael Kaplan
  Camera, Director of Photography, 943, John Mathieson
  Sound, Original Music Composer, 947, Hans Zimmer
  Production, Producer, 1886, Ted Griffin
  Writing, Screenplay, 1886, Ted Griffin
  Sound, ADR & Dubbing, 12562, Anna MacKenzie
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Production, Producer, 23779, Jack Rapke
  Costume & Make-Up, Hair Department Head, 32282, Mary L. Mastro
  Production, Producer, 39387, Sean Bailey
  Art, Set Decoration, 53182, Nancy Nye
  Art, Production Design, 56518, Tom Foden
  Production, Co-Producer, 58787, Giannina Facio
  Sound, Music Editor, 63421, Marc Streitenfeld
  Production, Co-Producer, 77512, Charles J.D. Schlissel
  Writing, Book, 114406, Eric Garcia
  Costume & Make-Up, Makeup Artist, 134564, Amy L. Disarro
  Costume & Make-Up, Hairstylist, 578729, Larry Waggoner
  Crew, Special Effects Coordinator, 1172335, Martin Bresin
  Camera, Still Photographer, 1177850, François Duhamel
  Writing, Screenplay, 1196739, Nicholas Griffin
  Costume & Make-Up, Makeup Department Head, 1269670, Tarra D. Day
  Costume & Make-Up, Costume Supervisor, 1319744, Linda Matthews
  Art, Art Direction, 1324829, Michael Manson
  Art, Assistant Art Director, 1338148, Daniel R. Jennings
  Art, Construction Coordinator, 1376897, John Villarino
  Art, Art Department Coordinator, 1378752, Cheree Welsh
  Camera, Camera Operator, 1395463, Mitch Dubin
  Sound, Sound Re-Recording Mixer, 1399141, Michael Minkler
  Visual Effects, Visual Effects Producer, 1400563, Cari Thomas
  Sound, Sound Re-Recording Mixer, 1404218, Myron Nettinga
  Visual Effects, Visual Effects Supervisor, 1405385, Sheena Duggal
  Sound, ADR & Dubbing, 1406616, Chris Jargo
  Crew, CG Supervisor, 1415628, David Alexander Smith
  Costume & Make-Up, Makeup Artist, 1427397, Kristina Vogel
  Costume & Make-Up, Makeup Artist, 1458527, Allen Weisinger
  Sound, Sound Re-Recording Mixer, 1459647, Tom Lalley
  Camera, First Assistant Camera, 1476175, Steven Meizler
  Costume & Make-Up, Set Costumer, 1532197, Lorraine Crossman
  Lighting, Rigging Gaffer, 1538440, James Keys
  Crew, Visual Effects Editor, 1546812, Andrea Maxwell
  Art, Art Department Coordinator, 1549276, Adam Khalid
  Camera, Helicopter Camera, 1549288, Ralph Mendoza

Titulo: A Good Year
Id: 9726
Fecha Emision: 2006-09-09
Presupuesto: 35000000
23/12/22 11:58:09 INFO zookeeper.ZooKeeper: Initiating client connection, connectString=127.0.0.1:2181 sessionTimeout=90000 watcher=org.apache.hadoop.hbase.zookeeper.ReadOnlyZKClient$$Lambda$94/0x00000008401a5c40@4c3a2d14
23/12/22 11:58:09 INFO zookeeper.ClientCnxnSocket: jute.maxbuffer value is 4194304 Bytes
23/12/22 11:58:09 INFO zookeeper.ClientCnxn: zookeeper.request.timeout value is 0. feature enabled=
23/12/22 11:58:09 INFO zookeeper.ClientCnxn: Opening socket connection to server localhost/127.0.0.1:2181. Will not attempt to authenticate using SASL (unknown error)
23/12/22 11:58:09 INFO zookeeper.ClientCnxn: Socket connection established, initiating session, client: /127.0.0.1:47860, server: localhost/127.0.0.1:2181
23/12/22 11:58:09 INFO zookeeper.ClientCnxn: Session establishment complete on server localhost/127.0.0.1:2181, sessionid = 0x100005211c4000b, negotiated timeout = 40000
Ingresos: 42064105
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Casting, 474, Jina Jay
  Editing, Editor, 563, Dody Dorn
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Casting, 4406, Antoinette Boulat
  Costume & Make-Up, Costume Design, 19058, Catherine Leterrier
  Art, Production Design, 20507, Sonja Klaus
  Art, Art Direction, 23453, Robert Cowper
  Costume & Make-Up, Hairstylist, 32354, Hayat Ouled Dahhou
  Art, Set Decoration, 54745, Bárbara Pérez-Solero
  Writing, Author, 58789, Marc Klein
  Writing, Author, 58790, Peter Mayle
  Sound, Original Music Composer, 63421, Marc Streitenfeld
  Camera, Director of Photography, 63422, Philippe Le Sourd
  Art, Art Direction, 63601, Frederic Evard
  Crew, Unit Publicist, 91941, Ernie Malik
  Costume & Make-Up, Makeup Artist, 1404200, Fabrizio Sforza
  Art, Art Department Coordinator, 1419166, Amy Simons
  Directing, Script Supervisor, 1462919, Nikki Clapp

Titulo: Hannibal
Id: 9740
Fecha Emision: 2001-02-08
Presupuesto: 87000000
Ingresos: 351692268
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Executive Producer, 930, Branko Lustig
  Camera, Director of Photography, 943, John Mathieson
  Art, Set Decoration, 945, Crispian Sallis
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Sound, Original Music Composer, 947, Hans Zimmer
  Production, Casting, 949, Louis DiGiaimo
  Editing, Editor, 950, Pietro Scalia
  Writing, Screenplay, 1255, David Mamet
  Writing, Screenplay, 2260, Steven Zaillian
  Production, Producer, 5398, Dino De Laurentiis
  Camera, Additional Camera, 8673, Daniele Massaccesi
  Camera, Camera Operator, 11113, David M. Dunlap
  Camera, Still Photographer, 12579, Phil Bray
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Costume & Make-Up, Makeup Artist, 15907, Alessandra Sampaolo
  Costume & Make-Up, Hairstylist, 15908, Elisabetta De Leonardis
  Art, Supervising Art Director, 16595, Pier Luigi Basile
  Writing, Novel, 16786, Thomas Harris
  Art, Production Design, 17400, Norris Spencer
  Crew, Second Unit Cinematographer, 17649, Alexander Witt
  Production, Producer, 19051, Martha De Laurentiis
  Sound, Music Editor, 63421, Marc Streitenfeld
  Art, Assistant Art Director, 77251, Halina Gebarowicz
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Art, Art Direction, 958921, David Crank
  Art, Assistant Art Director, 968175, Doug Huszti
  Directing, Script Supervisor, 1262129, Luca Kouimelis
  Costume & Make-Up, Costume Supervisor, 1328406, Dan Bronson
  Camera, Steadicam Operator, 1332515, Klemens Becker
  Sound, Foley, 1338372, Dan O'Connell
  Sound, Sound Effects Editor, 1342657, Jon Title
  Sound, Foley, 1367493, John T. Cucci
  Sound, Sound Re-Recording Mixer, 1377220, Doug Hemphill
  Crew, Stunt Coordinator, 1378239, Phil Neilson
  Costume & Make-Up, Set Costumer, 1378766, Catharine Fletcher Incaprera
  Editing, First Assistant Editor, 1388921, Chisako Yokoyama
  Editing, Dialogue Editor, 1392901, Lauren Stephens
  Costume & Make-Up, Set Costumer, 1400735, Marci R. Johnson
  Sound, ADR & Dubbing, 1401631, Michelle Pazer
  Lighting, Gaffer, 1401997, Bill O'Leary
  Costume & Make-Up, Makeup Department Head, 1404200, Fabrizio Sforza
  Sound, Supervising Sound Editor, 1404212, Karen Baker Landers
  Visual Effects, Visual Effects Supervisor, 1404221, Tim Burke
  Crew, Unit Publicist, 1405246, Rob Harris
  Editing, Dialogue Editor, 1405382, Chris Hogan
  Sound, ADR & Dubbing, 1405814, Jessica Gallavan
  Sound, Sound Effects Editor, 1406390, Dan Hegeman
  Editing, Dialogue Editor, 1408779, David A. Cohen
  Sound, Sound Effects Editor, 1423757, Scott Sanders
  Crew, CG Supervisor, 1425484, Laurent Hugueniot
  Sound, Music Editor, 1433743, Vicki Hiatt
  Costume & Make-Up, Hairstylist, 1445469, Aaron F. Quarles
  Costume & Make-Up, Hairstylist, 1464513, Barbara De Leonardis
  Art, Art Department Coordinator, 1464515, Susan Maye
  Crew, Property Master, 1464516, Douglas T. Madison
  Art, Construction Coordinator, 1464517, Richard Blankenship
  Crew, Visual Effects Editor, 1464518, Nicholas Atkinson
  Visual Effects, Visual Effects Producer, 1464519, Emma Norton
  Lighting, Gaffer, 1464520, Alberico Novelli
  Lighting, Rigging Gaffer, 1464521, Richie Ford
  Costume & Make-Up, Set Costumer, 1464522, Linda M. Boyland
  Crew, Picture Car Coordinator, 1464523, Mike Barbour
  Crew, Transportation Coordinator, 1464524, Bob Foster
  Lighting, Gaffer, 1597990, Daniele Botteselle

Titulo: White Squall
Id: 10534
Fecha Emision: 1996-02-02
Presupuesto: 38000000
Ingresos: 10300000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Executive Producer, 578, Ridley Scott
  Editing, Editor, 9163, Gerry Hambling
  Writing, Screenplay, 16829, Todd Robinson
  Production, Producer, 17398, Mimi Polk Gitlin
  Camera, Director of Photography, 22100, Hugh Johnson
  Production, Producer, 27148, Rocky Lang
  Sound, Original Music Composer, 59472, Jeff Rona
  Writing, Novel, 65546, Charles Gieg Jr.
  Writing, Novel, 65547, Felix Sutton

Titulo: The Duellists
Id: 19067
Fecha Emision: 1977-08-31
Presupuesto: 900000
Ingresos: 0
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Casting, 668, Mary Selway
  Production, Associate Producer, 5054, Ivor Powell
  Writing, Story, 8327, Joseph Conrad
  Production, Producer, 8967, David Puttnam
  Editing, Editor, 22104, Pamela Power
  Sound, Original Music Composer, 33319, Howard Blake
  Camera, Director of Photography, 59955, Frank Tidy
  Costume & Make-Up, Costume Design, 75801, Tom Rand
  Writing, Screenplay, 1073190, Gerald Vaughan-Hughes
  Art, Art Direction, 1370814, Bryan Graves
  Art, Production Design, 1405375, Peter J. Hampton

Titulo: Robin Hood
Id: 20662
Fecha Emision: 2010-05-12
Presupuesto: 200000000
Ingresos: 310669540
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Producer, 339, Brian Grazer
  Production, Casting, 474, Jina Jay
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Producer, 934, Russell Crowe
  Camera, Director of Photography, 943, John Mathieson
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Writing, Screenplay, 4723, Brian Helgeland
  Art, Set Decoration, 20507, Sonja Klaus
  Camera, Still Photographer, 40796, David Appleby
  Sound, Original Music Composer, 63421, Marc Streitenfeld
  Directing, Script Supervisor, 190914, Elizabeth West
  Sound, Music Editor, 1049333, Del Spiva
  Art, Art Department Coordinator, 1335179, Katie Gabriel
  Sound, Music Editor, 1378722, Joseph Bonn
  Art, Art Department Coordinator, 1400008, Heather Noble

Titulo: Legend
Id: 11976
Fecha Emision: 1985-07-19
Presupuesto: 25000000
Ingresos: 15502112
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Producer, 376, Arnon Milchan
  Directing, Director, 578, Ridley Scott
  Sound, Original Music Composer, 1760, Jerry Goldsmith
  Editing, Editor, 5056, Terry Rawlings
  Writing, Writer, 9167, William Hjortsberg
  Camera, Director of Photography, 21516, Alex Thomson
  Production, Co-Producer, 57241, Tim Hampton
  Production, Executive Producer, 71144, Joseph P. Grace
  Costume & Make-Up, Makeup Effects Designer, 101608, Rob Bottin
  Art, Production Design, 589936, Assheton Gorton
  Sound, Music, 942947, Tangerine Dream

Titulo: Body of Lies
Id: 12113
Fecha Emision: 2008-10-10
Presupuesto: 70000000
Ingresos: 113280098
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Casting, 474, Jina Jay
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Production, Casting, 2952, Avy Kaufman
  Art, Supervising Art Director, 5673, Marco Trentini
  Camera, Steadicam Operator, 8673, Daniele Massaccesi
  Crew, Dialect Coach, 13050, Tim Monich
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Camera, Director of Photography, 17649, Alexander Witt
  Art, Set Decoration, 20507, Sonja Klaus
  Art, Art Direction, 23453, Robert Cowper
  Writing, Screenplay, 34510, William Monahan
  Production, Executive Producer, 40374, Michael Costigan
  Visual Effects, Visual Effects Producer, 42291, Jacquie Barnbrook
  Art, Supervising Art Director, 56697, Charley Beal
  Lighting, Gaffer, 57600, Robert Steadman
  Production, Producer, 58470, Donald De Line
  Crew, Dialect Coach, 59040, Judy Dickerson
  Camera, Camera Operator, 59370, David Insley
  Sound, Music, 63421, Marc Streitenfeld
  Writing, Novel, 71311, David Ignatius
  Writing, Screenplay, 71311, David Ignatius
  Production, Line Producer, 77511, Zakaria Alaoui
  Production, Executive Producer, 77512, Charles J.D. Schlissel
  Art, Art Direction, 77513, Alessandro Santucci
  Crew, Dialect Coach, 83114, Sam Sako
  Crew, Unit Publicist, 91941, Ernie Malik
  Art, Assistant Art Director, 119180, Saverio Sammali
  Costume & Make-Up, Makeup Artist, 142152, Bernadette Mazur
  Camera, Steadicam Operator, 983118, Larry McConkey
  Production, Production Manager, 998152, Lucio Trentini
  Crew, Visual Effects Editor, 1017296, Billy Rich
  Sound, Music Editor, 1049333, Del Spiva
  Crew, Stunt Coordinator, 1074163, G.A. Aguilar
  Visual Effects, Visual Effects Producer, 1169459, Julia Frey
  Camera, Still Photographer, 1177850, François Duhamel
  Crew, Special Effects Coordinator, 1224272, John McLeod
  Costume & Make-Up, Costume Supervisor, 1322137, Clare Spragge
  Costume & Make-Up, Costume Supervisor, 1331895, Abdelkrim Akallach
  Crew, Property Master, 1334779, Brad Einhorn
  Sound, Foley, 1338372, Dan O'Connell
  Editing, Dialogue Editor, 1342658, Frederick H. Stahly
  Sound, Foley, 1367493, John T. Cucci
  Art, Art Department Coordinator, 1387217, Wendy Means
  Directing, Script Supervisor, 1390388, Annie Penn
  Sound, Sound Re-Recording Mixer, 1391571, Bob Beemer
  Art, Assistant Art Director, 1398083, Abdellah Baadil
  Sound, Sound Re-Recording Mixer, 1399141, Michael Minkler
  Art, Set Designer, 1400066, Rich Romig
  Production, Location Manager, 1401599, Christian McWilliams
  Camera, Helicopter Camera, 1403415, David B. Nowell
  Art, Assistant Art Director, 1403698, Antonio Tarolla
  Crew, Post Production Supervisor, 1404205, Teresa Kelly
  Art, Assistant Art Director, 1404208, Monica Sallustio
  Sound, Supervising Sound Editor, 1404212, Karen Baker Landers
  Sound, Sound Effects Editor, 1404217, Peter Staubli
  Camera, Helicopter Camera, 1404244, John Marzano
  Costume & Make-Up, Hairstylist, 1405373, Audrey L. Anzures
  Art, Art Department Coordinator, 1405374, Francesca Birri
  Art, Supervising Art Director, 1405375, Peter J. Hampton
  Art, Set Designer, 1405376, Alex McCarroll
  Art, Construction Foreman, 1405377, Francesco Valento
  Art, Leadman, 1405378, R. Scott Doran
  Art, Leadman, 1405379, Chris Ashley
  Editing, Dialogue Editor, 1405382, Chris Hogan
  Visual Effects, Visual Effects Supervisor, 1405385, Sheena Duggal
  Camera, Camera Operator, 1405388, Alessandro Chiara
  Camera, Camera Operator, 1405389, Ronald Hersey
  Camera, Camera Operator, 1405391, Stefan H. Fritz Hummel
  Camera, Camera Operator, 1405394, Marco Sacerdoti
  Camera, Camera Operator, 1405401, Mark Schmidt
  Editing, Digital Intermediate, 1405419, Nick Monton
  Crew, Transportation Coordinator, 1405420, Gary Shephard
  Crew, Picture Car Coordinator, 1405422, Gary Duncan
  Crew, Picture Car Coordinator, 1405423, Mounir Badia
  Production, Location Manager, 1405427, Carol Flaisher
  Production, Location Manager, 1405428, J. Chan Claggett
  Production, Location Manager, 1405429, Driss Benchhiba
  Art, Construction Coordinator, 1532615, Dan Pemberton
  Lighting, Gaffer, 1553236, Stefano Marino

Titulo: Exodus: Gods and Kings
Id: 147441
Fecha Emision: 2014-12-03
Presupuesto: 140000000
Ingresos: 268031828
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Sound, Music, 405, Alberto Iglesias
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Writing, Screenplay, 2260, Steven Zaillian
  Art, Supervising Art Director, 4710, Benjamín Fernández
  Production, Producer, 8401, Mark Huffam
  Writing, Screenplay, 10704, Jeffrey Caine
  Production, Casting, 16363, Nina Gold
  Sound, Sound Designer, 16683, James Harrison
  Art, Set Decoration, 16995, Pilar Revuelta
  Production, Producer, 22498, Michael Schaefer
  Costume & Make-Up, Hairstylist, 23426, Nicola Buck
  Costume & Make-Up, Makeup Artist, 27205, Luigi Rocchetti
  Production, Producer, 36427, Jenno Topping
  Crew, Stunt Coordinator, 40713, Rob Inch
  Sound, Foley, 40823, Peter Burgis
  Writing, Screenplay, 59265, Adam Cooper
  Writing, Screenplay, 59266, Bill Collage
  Crew, Second Unit Cinematographer, 59528, Flavio Martínez Labiano
  Art, Art Direction, 71577, Matthew Gray
  Costume & Make-Up, Hairstylist, 75081, Nana Fischer
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Visual Effects, Visual Effects Supervisor, 122274, Peter Chiang
  Editing, Digital Intermediate, 134572, James Long
  Production, Producer, 266920, Peter Chernin
  Art, Art Direction, 422701, Luigi Marchione
  Art, Set Decoration, 957666, Celia Bobak
  Lighting, Gaffer, 1002096, José Luis Rodríguez
  Editing, Editor, 1017296, Billy Rich
  Camera, Underwater Camera, 1189807, Tim Wooster
  Art, Art Direction, 1299324, Gavin Fitch
  Art, Art Direction, 1299326, Matt Wynne
  Costume & Make-Up, Costume Supervisor, 1319160, Ken Crouch
  Art, Art Direction, 1327139, Alex Cameron
  Art, Supervising Art Director, 1327141, Marc Homes
  Art, Art Direction, 1331893, Alejandro Fernández
  Crew, Property Master, 1335047, Dennis Wiseman
  Art, Greensman, 1335543, Roger Holden
  Art, Greensman, 1335544, Will Holden
  Sound, Sound Designer, 1335556, Michael Fentum
  Sound, Foley, 1337412, Jason Swanscott
  Sound, Music Editor, 1337420, Robert Houston
  Sound, Music Editor, 1338287, Tony Lewis
  Art, Art Direction, 1340110, Ashley Winter
  Art, Art Direction, 1354916, Ravi Bansal
  Directing, Script Supervisor, 1357600, Julia Chiavetta
  Costume & Make-Up, Hairstylist, 1359989, Denise Kum
  Visual Effects, Visual Effects Supervisor, 1387184, Simon Carr
  Camera, Camera Operator, 1388897, Julian Morson
  Camera, Still Photographer, 1390366, Kerry Brown
  Camera, Camera Operator, 1390368, Graham Hall
  Directing, Script Supervisor, 1390388, Annie Penn
  Visual Effects, Visual Effects Producer, 1392622, Lisa Goldberg
  Sound, Sound Effects Editor, 1393119, Mark Taylor
  Sound, Foley, 1393300, Jack Stew
  Sound, Foley, 1398918, Andrea King
  Visual Effects, Visual Effects Producer, 1398927, Stefan Drury
  Costume & Make-Up, Wigmaker, 1401126, Alex Rouse
  Crew, Visual Effects Editor, 1403467, Xinyi Puah
  Visual Effects, Visual Effects Supervisor, 1403468, Stephan Trojansky
  Camera, Helicopter Camera, 1404244, John Marzano
  Camera, Helicopter Camera, 1405241, Adam Dale
  Crew, Visual Effects Editor, 1406757, Abi Cadogan
  Sound, Sound Designer, 1408373, Oliver Tarney
  Crew, Visual Effects Editor, 1408812, Aled Robinson
  Crew, Unit Publicist, 1408850, Linda Gamble
  Costume & Make-Up, Wigmaker, 1409293, Orlando Bassi
  Production, Location Manager, 1409308, Matt Jones
  Production, Location Manager, 1409858, Félix Rosell
  Costume & Make-Up, Wigmaker, 1411074, Ray Marston
  Crew, Animatronic and Prosthetic Effects, 1411086, Darren Robinson
  Costume & Make-Up, Makeup Department Head, 1414090, Tina Earnshaw
  Crew, Visual Effects Editor, 1417820, Nick Dacey
  Crew, Visual Effects Editor, 1418807, Matthew Ozerski
  Crew, Animatronic and Prosthetic Effects, 1424925, Peter Hawkins
  Art, Art Direction, 1428907, Hayley Easton Street
  Costume & Make-Up, Makeup Artist, 1428914, Jessica Brooks
  Camera, Camera Operator, 1428917, Stefan Stankowski
  Costume & Make-Up, Makeup Artist, 1439132, Nora Robertson
  Crew, Special Effects Coordinator, 1439161, Victoria Stokes
  Production, Location Manager, 1439756, Izaskun Montilla
  Crew, Visual Effects Editor, 1442139, Andrew Edmondson
  Crew, Sequence Supervisor, 1450948, Tim Ledbury
  Crew, Compositors, 1456696, Brian N. Bentley
  Crew, Dialect Coach, 1457374, Roisin Carty
  Crew, Visual Effects Editor, 1458115, Leanne Young
  Production, Producer, 1459846, Mohamed El Raie
  Art, Art Direction, 1459850, Óscar Sempere
  Costume & Make-Up, Hairstylist, 1459851, Carolyn Cousins
  Costume & Make-Up, Hairstylist, 1459852, Sian Miller
  Costume & Make-Up, Hairstylist, 1459853, Pippa Woods
  Costume & Make-Up, Hairstylist, 1459854, Alexis Continente
  Costume & Make-Up, Hairstylist, 1459855, Eva Marieges Moore
  Costume & Make-Up, Makeup Artist, 1459856, Robb Crafer
  Costume & Make-Up, Makeup Artist, 1459857, Audrey Doyle
  Costume & Make-Up, Makeup Artist, 1459858, Kristin Rasch
  Costume & Make-Up, Makeup Artist, 1459859, Matteo Silvi
  Crew, Animatronic and Prosthetic Effects, 1459860, Matthew MacMurray
  Crew, Animatronic and Prosthetic Effects, 1459861, Rubén Serra
  Art, Art Department Coordinator, 1459862, Felicity Hickson
  Art, Assistant Art Director, 1459864, Quinn Robinson
  Art, Assistant Art Director, 1459865, Florian Müller
  Crew, Property Master, 1459866, Juan Aguirre
  Art, Assistant Art Director, 1459867, Philip Gilmore
  Art, Construction Coordinator, 1459870, Sarah Hunt
  Art, Lead Painter, 1459872, Alan Gooch
  Art, Sculptor, 1459873, Mike Jones
  Art, Set Decoration Buyer, 1459874, Elena Machado Hernandez
  Sound, ADR & Dubbing, 1459875, Rachael Tate
  Editing, Dialogue Editor, 1459875, Rachael Tate
  Visual Effects, Animation Director, 1459878, Marlene Chazot
  Visual Effects, Animation Supervisor, 1459879, Paul Chung
  Visual Effects, Animation Supervisor, 1459880, Stafford Lawrence
  Crew, Visual Effects Editor, 1459895, Shawn Broes
  Crew, Visual Effects Editor, 1459896, Lauren Camilleri
  Visual Effects, Visual Effects Producer, 1459897, Pierre Escande
  Visual Effects, Visual Effects Producer, 1459898, Moriah Etherington-Sparks
  Crew, Visual Effects Editor, 1459899, Struan Farquhar
  Visual Effects, Visual Effects Producer, 1459901, Paul Kolsanoff
  Visual Effects, Visual Effects Producer, 1459902, Daniel Matley
  Visual Effects, Visual Effects Producer, 1459905, Charlotte Raffi
  Visual Effects, Visual Effects Producer, 1459906, Jamie Stevenson
  Visual Effects, Visual Effects Producer, 1459909, Abbie Tucker-Williams
  Crew, Visual Effects Editor, 1459910, Garrett Wilson
  Crew, Visual Effects Editor, 1459911, Mark S. Wright
  Visual Effects, Visual Effects Supervisor, 1459912, Asregadoo Arundi
  Visual Effects, Visual Effects Supervisor, 1459913, Jessica Norman
  Crew, Visual Effects Art Director, 1459914, Stefano Trivelli
  Crew, Visual Effects Art Director, 1459915, Claas Henke
  Crew, Sequence Supervisor, 1459917, Jennifer Herbert
  Crew, Sequence Supervisor, 1459921, Tom Rolfe
  Crew, CG Supervisor, 1459922, James Rustad
  Crew, CG Supervisor, 1459923, Tim Zaccheo
  Crew, CGI Supervisor, 1459924, Lukas Lepicovsky
  Crew, CG Supervisor, 1459925, Daniel Pastore
  Camera, Camera Operator, 1459927, David Acereto
  Camera, Camera Operator, 1459929, Al Hindley
  Camera, Camera Operator, 1459930, Imanol Nabea
  Camera, Camera Operator, 1459931, Julio Vallejo
  Camera, Camera Operator, 1459932, Ibon Antuñano
  Camera, Still Photographer, 1459933, Inesa De La Roche
  Costume & Make-Up, Costume Supervisor, 1459935, Cristina Sopeña
  Costume & Make-Up, Set Costumer, 1459936, Amanda Trewin
  Editing, First Assistant Editor, 1459937, Laurence Johnson
  Crew, Transportation Coordinator, 1459938, Andrés Leal Chele
  Crew, Transportation Coordinator, 1459939, Melina Frías
  Crew, Transportation Coordinator, 1459940, Lee David Hollingsworth
  Crew, Transportation Coordinator, 1459941, David Louis Jones
  Crew, Transportation Coordinator, 1459942, Aline Rajan-Harjani
  Production, Location Manager, 1459944, Ahmed Sobhy
  Crew, Actor's Assistant, 1459946, Luis Gamazo
  Production, Casting, 1459947, Sandra Mooney

Titulo: The Counselor
Id: 109091
Fecha Emision: 2013-10-25
Presupuesto: 25000000
Ingresos: 71009334
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Production, Casting, 2952, Avy Kaufman
  Production, Producer, 6468, Nick Wechsler
  Production, Executive Producer, 8401, Mark Huffam
  Production, Casting, 16363, Nina Gold
  Production, Executive Producer, 22498, Michael Schaefer
  Production, Executive Producer, 40374, Michael Costigan
  Production, Executive Producer, 51736, Cormac McCarthy
  Writing, Writer, 51736, Cormac McCarthy
  Production, Producer, 566958, Paula Mae Schwartz
  Production, Producer, 566962, Steve Schwartz
  Sound, Original Music Composer, 582922, Daniel Pemberton

Titulo: Alien: Covenant
Id: 126889
Fecha Emision: 2017-05-09
Presupuesto: 97000000
Ingresos: 232380243
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Producer, 915, David Giler
  Writing, Screenplay, 932, John Logan
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Production, Producer, 1723, Walter Hill
  Writing, Characters, 5045, Dan O'Bannon
  Writing, Characters, 5046, Ronald Shusett
  Art, Set Decoration, 6055, Victor J. Zolfo
  Production, Producer, 8401, Mark Huffam
  Art, Art Direction, 9583, Charlie Revai
  Production, Producer, 22498, Michael Schaefer
  Art, Supervising Art Director, 33195, Ian Gracie
  Production, Casting, 51922, Carmen Cuba
  Art, Production Design, 60579, Chris Seagers
  Art, Conceptual Design, 74089, Steve Burg
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Sound, Assistant Sound Editor, 158596, Alex Ferguson
  Writing, Story, 191937, Michael Green
  Writing, Screenplay, 231826, Dante Harper
  Sound, Music, 549315, Jed Kurzel
  Sound, Music Director, 549315, Jed Kurzel
  Costume & Make-Up, Hair Designer, 961143, Lesley Vanderwalt
  Costume & Make-Up, Makeup Designer, 961143, Lesley Vanderwalt
  Costume & Make-Up, Makeup Supervisor, 961143, Lesley Vanderwalt
  Art, Art Direction, 962431, Damien Drew
  Sound, Foley, 1079085, Sue Harding
  Writing, Story, 1155661, Jack Paglen
  Camera, Camera Operator, 1190661, Damian Wyvill
  Crew, In Memory Of, 1247285, Julie Payne
  Costume & Make-Up, Costume Supervisor, 1334493, Sarah Robinson
  Sound, Sound Designer, 1335556, Michael Fentum
  Sound, Music Editor, 1338287, Tony Lewis
  Costume & Make-Up, Costume Supervisor, 1355543, Robyn Elliott
  Camera, Camera Operator, 1357066, P. Scott Sakamoto
  Visual Effects, Visual Effects Supervisor, 1368871, Charley Henley
  Crew, Visual Effects Editor, 1384371, Mark Carr
  Art, Art Direction, 1391711, Jacinta Leong
  Sound, Foley, 1393300, Jack Stew
  Camera, Additional Photography, 1399033, Shaun O'Dell
  Costume & Make-Up, Key Hair Stylist, 1401639, Jennifer Stanfield
  Production, Location Manager, 1401743, Mary Barltrop
  Sound, Sound Designer, 1408373, Oliver Tarney
  Sound, Supervising Sound Editor, 1408373, Oliver Tarney
  Sound, Sound Effects Editor, 1408374, Dillon Bennett
  Lighting, Rigging Gaffer, 1411238, Mark Jefferies
  Camera, Still Photographer, 1418310, Mark Rogers
  Costume & Make-Up, Makeup Artist, 1418802, Tess Natoli
  Sound, ADR & Dubbing, 1432596, Derek Casari
  Crew, Visual Effects Editor, 1444969, Paolo Buzzetti
  Visual Effects, Animation Supervisor, 1453612, Gabriele Zucchelli
  Sound, ADR Supervisor, 1459875, Rachael Tate
  Editing, First Assistant Editor, 1459937, Laurence Johnson
  Crew, Visual Effects Editor, 1461629, Lukasz Bukowiecki
  Visual Effects, Pre-Visualization Supervisor, 1466454, Jason McDonald
  Directing, Script Supervisor, 1470970, Melina Burns
  Art, Assistant Art Director, 1518775, Andrew Chan
  Camera, Camera Operator, 1527926, Matt Toll
  Production, Casting Associate, 1538204, Wittney Horton
  Camera, Steadicam Operator, 1569342, Andrew Johnson
  Visual Effects, Visual Effects Producer, 1574096, Sona Pak
  Directing, Assistant Director, 1578651, Raymond Kirk
  Costume & Make-Up, Hairstylist, 1585743, Lara Jade Birch
  Visual Effects, Visual Effects Producer, 1595166, Tomi Nieminen
  Costume & Make-Up, Hairstylist, 1634542, Rebecca Allen
  Production, Unit Production Manager, 1634544, Dean Hood
  Art, Set Designer, 1634555, Belinda Cusmano
  Art, Conceptual Design, 1634557, Wayne John Haag
  Art, Conceptual Design, 1634558, Dane Hallett
  Art, Conceptual Design, 1634559, Mark Hatton
  Camera, Aerial Director of Photography, 1644252, Peter Beeh
  Production, Researcher, 1649534, Lizzy Jane Klein
  Visual Effects, 2D Supervisor, 1721454, Anthony Smith
  Sound, ADR & Dubbing, 1737654, Judah Getz
  Art, Art Department Coordinator, 1746248, Lauren Wild
  Directing, Script Supervisor, 1746249, Merran Elliot
  Production, Casting Assistant, 1746251, Ebony Hardin
  Camera, Dolly Grip, 1746428, Mal Booth
  Lighting, Gaffer, 1746429, Mark Glindeman
  Lighting, Rigging Grip, 1746430, Theo Thomas
  Camera, Key Grip, 1746431, Toby Copping
  Visual Effects, Animation Supervisor, 1746432, Alexandre Ronco
  Crew, CG Supervisor, 1746433, Alexandre Cancado
  Visual Effects, Creature Technical Director, 1746434, Maxime Cazaly
  Visual Effects, Creature Technical Director, 1746435, Francis Leong
  Visual Effects, Creature Technical Director, 1746436, Will Fife
  Visual Effects, Creature Technical Director, 1746437, Victor Pillet
  Lighting, Lighting Director, 1746438, Boyan Baynov
  Lighting, Lighting Director, 1746439, Spencer Fitch
  Lighting, Lighting Director, 1746440, Britton Plewes
  Lighting, Lighting Director, 1746441, Leonardo Bianchi
  Lighting, Lighting Director, 1746442, Matthieu Paugam
  Lighting, Lighting Director, 1746443, Manjusha Balachandran
  Lighting, Lighting Director, 1746444, Elisabeth Leeb
  Visual Effects, Modeling, 1746445, Manmath Matondkar
  Visual Effects, Modeling, 1746446, Luke Wilding
  Visual Effects, Modeling, 1746447, William Bell
  Visual Effects, Special Effects Supervisor, 1746449, Dan Oliver
  Costume & Make-Up, Assistant Costume Designer, 1746451, Mark Campbell
  Costume & Make-Up, Costume Coordinator, 1746452, Bronwyn Doughty
  Costume & Make-Up, Costume Coordinator, 1746453, Maria Salcher
  Costume & Make-Up, Set Costumer, 1746454, Anna Burstall
  Costume & Make-Up, Set Costumer, 1746455, Ivana Daniele
  Costume & Make-Up, Set Costumer, 1746456, Dan Owen
  Costume & Make-Up, Costume Illustrator, 1746457, Anna Haigh
  Directing, Second Assistant Director, 1805808, Scott Lovelock
  Directing, Third Assistant Director, 1805809, Greg Tynan
  Editing, Additional Editing, 1816348, Cheryl Potter
  Editing, Assistant Editor, 1816349, Justin Tillett
  Production, Location Manager, 1816350, Jeremy Peek
  Sound, Assistant Sound Editor, 1816351, Arabella Winter
  Camera, Camera Operator, 1816353, Ben Ruffell
  Directing, Second Assistant Director, 1816354, Danielle Blake
  Camera, Additional Photography, 1816355, Claire Frayn
  Directing, Third Assistant Director, 1816355, Claire Frayn
  Camera, Additional Photography, 1816356, Sarah Hood
  Directing, Second Assistant Director, 1816356, Sarah Hood
  Directing, Third Assistant Director, 1816357, Matthew Webb
  Art, Set Dresser, 1816358, Dion Boothby
  Art, Set Designer, 1816359, Tony Drew
  Art, Set Designer, 1816360, Andrew Kattie
  Art, Set Designer, 1816361, Kate McCowage
  Art, Set Designer, 1816362, Alasdair Mott
  Crew, Stunt Coordinator, 1830633, Kyle Gardiner

Titulo: Prometheus
Id: 70981
Fecha Emision: 2012-05-30
Presupuesto: 130000000
Ingresos: 403170142
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Producer, 915, David Giler
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Production, Producer, 1723, Walter Hill
  Production, Casting, 2952, Avy Kaufman
  Production, Executive Producer, 8401, Mark Huffam
  Camera, Camera Operator, 8673, Daniele Massaccesi
  Camera, Steadicam Operator, 8673, Daniele Massaccesi
  Sound, Supervising Sound Editor, 15332, Mark P. Stoeckinger
  Sound, Sound Re-Recording Mixer, 16177, Ron Bartlett
  Production, Casting, 16363, Nina Gold
  Art, Set Decoration, 20507, Sonja Klaus
  Costume & Make-Up, Makeup Artist, 25060, Jana Carboni
  Production, Executive Producer, 28974, Damon Lindelof
  Writing, Writer, 28974, Damon Lindelof
  Art, Art Direction, 30463, Paul Inglis
  Art, Art Direction, 34005, Karen Wakefield
  Art, Supervising Art Director, 34513, John King
  Production, Executive Producer, 40374, Michael Costigan
  Crew, Stunt Coordinator, 40713, Rob Inch
  Sound, Original Music Composer, 63421, Marc Streitenfeld
  Costume & Make-Up, Hair Designer, 75081, Nana Fischer
  Art, Assistant Art Director, 80424, Philip Elton
  Crew, Sound Recordist, 113048, Tim Gomillion
  Crew, Sound Recordist, 113089, Dennis Rogers
  Visual Effects, Visual Effects Supervisor, 141483, Jamie Dixon
  Writing, Writer, 564940, Jon Spaihts
  Production, Executive Producer, 1018939, Michael Ellenberg
  Sound, Music Editor, 1049333, Del Spiva
  Art, Art Direction, 1327139, Alex Cameron
  Art, Art Direction, 1327141, Marc Homes
  Art, Assistant Art Director, 1330898, Claudio Campana
  Art, Assistant Art Director, 1335552, Tom Whitehead
  Sound, Foley, 1338372, Dan O'Connell
  Editing, Dialogue Editor, 1352966, Michael Hertlein
  Editing, Dialogue Editor, 1352968, Margit Pfeiffer
  Editing, Dialogue Editor, 1364410, Julie Feiner
  Sound, Foley, 1367493, John T. Cucci
  Sound, Sound Re-Recording Mixer, 1377220, Doug Hemphill
  Visual Effects, Visual Effects Producer, 1377294, Michelle Eisenreich
  Sound, Music Editor, 1378722, Joseph Bonn
  Art, Art Direction, 1385883, Anthony Caron-Delion
  Art, Art Direction, 1388850, Peter Dorme
  Crew, Transportation Coordinator, 1388881, Peter Devlin
  Camera, Camera Operator, 1388899, Gary Spratling
  Costume & Make-Up, Set Costumer, 1389543, Calandra Meredith
  Art, Construction Coordinator, 1390340, Laura Davison
  Art, Art Department Coordinator, 1390344, Sarah Griggs
  Art, Assistant Art Director, 1390349, Tom Weaving
  Art, Assistant Art Director, 1390350, Helen Xenopoulos
  Crew, Scenic Artist, 1390352, James Newell
  Sound, Supervising Sound Editor, 1390353, Victor Ray Ennis
  Visual Effects, Visual Effects Supervisor, 1390357, Trent Claus
  Visual Effects, Visual Effects Supervisor, 1390360, Dick Edwards
  Visual Effects, Visual Effects Supervisor, 1390362, Martin Hill
  Visual Effects, Visual Effects Producer, 1390363, Annette Wullems
  Visual Effects, Visual Effects Producer, 1390364, Allen Maris
  Camera, Still Photographer, 1390366, Kerry Brown
  Lighting, Gaffer, 1390367, Perry Evans
  Camera, Camera Operator, 1390368, Graham Hall
  Camera, Camera Operator, 1390372, David Morgan
  Costume & Make-Up, Costume Supervisor, 1390373, Gordon Harmer
  Costume & Make-Up, Set Costumer, 1390375, Georgiana Sayer
  Costume & Make-Up, Set Costumer, 1390376, Bruno de Santa
  Sound, Music Editor, 1390382, Kirsty Whalley
  Directing, Script Coordinator, 1390384, Amal Baggar
  Crew, Dialect Coach, 1390386, Catherine Charlton
  Production, Location Manager, 1390387, Steve Hart
  Directing, Script Supervisor, 1390388, Annie Penn
  Directing, Script Supervisor, 1390389, Louise Wade
  Art, Conceptual Design, 1405574, David Vyle Levy
  Costume & Make-Up, Hairstylist, 1437620, Peta Dunstall
  Crew, Compositors, 1457935, Michael Queen
  Costume & Make-Up, Hair Designer, 1462918, Enzo Angileri
  Production, Production Coordinator, 1537723, Miranda Marks
  Costume & Make-Up, Makeup Artist, 1537724, Aisling Nairn
  Costume & Make-Up, Hairstylist, 1537725, Nicky Knowles

Titulo: The Martian
Id: 286217
Fecha Emision: 2015-09-30
Presupuesto: 108000000
Ingresos: 630161890
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Sound, Original Music Composer, 5553, Harry Gregson-Williams
  Visual Effects, Special Effects Supervisor, 6060, Neil Corbould
  Production, Producer, 8401, Mark Huffam
  Camera, Camera Operator, 8673, Daniele Massaccesi
  Production, Producer, 11092, Simon Kinberg
  Visual Effects, Visual Effects Producer, 15357, Nina Fallon
  Production, Casting, 16363, Nina Gold
  Sound, Sound Effects Editor, 16683, James Harrison
  Production, Producer, 22498, Michael Schaefer
  Art, Art Direction, 23453, Robert Cowper
  Costume & Make-Up, Makeup Artist, 25060, Jana Carboni
  Editing, Digital Intermediate, 32806, Paul Carlin
  Sound, Foley, 40815, Hugo Adams
  Writing, Screenplay, 47506, Drew Goddard
  Production, Casting, 49670, Zsolt Csutak
  Production, Casting, 51922, Carmen Cuba
  Lighting, Gaffer, 75117, Julian White
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Art, Set Decoration, 957666, Celia Bobak
  Art, Art Direction, 962164, Jason Knox-Johnston
  Art, Art Direction, 968805, Mónika Esztán
  Visual Effects, Special Effects Supervisor, 1129208, Steven Warner
  Art, Set Decoration, 1177771, Zoltán Horváth
  Costume & Make-Up, Assistant Costume Designer, 1285933, Michael Mooney
  Art, Art Direction, 1299326, Matt Wynne
  Production, Casting Associate, 1300064, Theo Park
  Visual Effects, Visual Effects Supervisor, 1318830, Sara Bennett
  Production, Executive Producer, 1320090, Aditya Sood
  Art, Supervising Art Director, 1327141, Marc Homes
  Art, Art Direction, 1334420, Phil Sims
  Costume & Make-Up, Costume Supervisor, 1334493, Sarah Robinson
  Sound, Sound Designer, 1335556, Michael Fentum
  Sound, Music Editor, 1338287, Tony Lewis
  Writing, Novel, 1352085, Andy Weir
  Costume & Make-Up, Assistant Costume Designer, 1354914, Richard Sale
  Visual Effects, Visual Effects Producer, 1376804, Clare Norman
  Directing, Script Supervisor, 1379059, Lizzie Pritchard
  Visual Effects, VFX Editor, 1384371, Mark Carr
  Visual Effects, Visual Effects Supervisor, 1384386, Richard Stammers
  Visual Effects, Visual Effects Supervisor, 1386912, Mohen Leo
  Art, Assistant Art Director, 1388860, Matt Sims
  Art, Art Department Coordinator, 1392588, Éva Zöld
  Art, Assistant Art Director, 1392589, Annamária Orosz
  Sound, Foley, 1393300, Jack Stew
  Visual Effects, Visual Effects Producer, 1393323, Barrie Hemsley
  Camera, Still Photographer, 1393883, Peter Mountain
  Crew, Property Master, 1398913, Noel Cowell
  Sound, Foley, 1398918, Andrea King
  Camera, Camera Operator, 1399639, László Bille
  Visual Effects, Visual Effects Producer, 1400077, Paula Pope
  Costume & Make-Up, Wigmaker, 1401126, Alex Rouse
  Camera, Helicopter Camera, 1404244, John Marzano
  Sound, Sound Designer, 1408373, Oliver Tarney
  Sound, Supervising Sound Editor, 1408373, Oliver Tarney
  Editing, Digital Intermediate, 1409305, Todd Kleparski
  Costume & Make-Up, Key Hair Stylist, 1411067, Maralyn Sherman
  Visual Effects, Visual Effects Producer, 1411249, Clare Heneghan
  Art, Art Direction, 1411329, Stefan Speth
  Costume & Make-Up, Hair Designer, 1414090, Tina Earnshaw
  Costume & Make-Up, Makeup Designer, 1414090, Tina Earnshaw
  Visual Effects, Visual Effects Supervisor, 1419604, Justin Cornish
  Visual Effects, Visual Effects Supervisor, 1419605, Brooke Lyndon-Stanford
  Crew, CG Supervisor, 1426327, Nicolas Hernandez
  Visual Effects, Visual Effects Producer, 1426846, Priyanka Balasubramanian
  Costume & Make-Up, Makeup Artist, 1427822, Rita Balla
  Visual Effects, Visual Effects Supervisor, 1450948, Tim Ledbury
  Camera, Camera Operator, 1458446, Imre Juhasz
  Sound, ADR & Dubbing, 1459875, Rachael Tate
  Editing, Dialogue Editor, 1459875, Rachael Tate
  Visual Effects, Visual Effects Producer, 1459902, Daniel Matley
  Visual Effects, Visual Effects Supervisor, 1461613, Chris Lawrence
  Crew, Second Unit Cinematographer, 1494566, Mark Patten
  Costume & Make-Up, Costume Supervisor, 1515573, Gábor Homonnay
  Crew, Armorer, 1515635, Péter Behan
  Art, Assistant Art Director, 1518764, Shira Hockman
  Costume & Make-Up, Seamstress, 1533496, Zsofia Laczko
  Production, Casting Associate, 1538204, Wittney Horton
  Sound, Orchestrator, 1544377, Alastair King
  Art, Art Direction, 1548936, László Rajk
  Crew, Carpenter, 1548937, Norbert Alte Fieszl
  Crew, Carpenter, 1548938, Zoltán Harányi
  Art, Assistant Art Director, 1548939, Rhys Ifan
  Art, Assistant Art Director, 1548940, Will Newton
  Art, Assistant Art Director, 1548941, Gergely Rieger
  Sound, Orchestrator, 1548942, David Butterworth
  Sound, Foley, 1548943, Adam Mendez
  Crew, Sound Recordist, 1548945, Tim Maxwell
  Costume & Make-Up, Assistant Costume Designer, 1548948, Bea Merkovits
  Costume & Make-Up, Makeup Artist, 1548952, Móni Csomós
  Production, Researcher, 1548953, Dan Clay
  Visual Effects, Animation Supervisor, 1548954, Dale Newton
  Crew, CG Supervisor, 1548957, Gourdal Sebastien
  Crew, CG Supervisor, 1548958, Martin Waters
  Crew, CG Supervisor, 1548959, Louis Paré
  Visual Effects, VFX Production Coordinator, 1548960, Fausto Appiolaza
  Visual Effects, VFX Supervisor, 1548961, James D. Fleming
  Visual Effects, Visual Effects Supervisor, 1548962, Anders Langlands
  Lighting, Gaffer, 1563261, Krisztián Paluch
  Visual Effects, Color Designer, 1567986, Dogu Abaris

Titulo: Blade Runner
Id: 78
Fecha Emision: 1982-06-25
Presupuesto: 33139618
Ingresos: 28000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Additional Photography, 473, Brian Tufano
  Directing, Director, 578, Ridley Scott
  Production, Producer, 581, Michael Deeley
  Writing, Screenplay, 583, Hampton Fancher
  Writing, Novel, 584, Philip K. Dick
  Crew, Thanks, 584, Philip K. Dick
  Camera, Director of Photography, 594, Jordan Cronenweth
  Sound, Original Music Composer, 595, Vangelis
  Art, Production Design, 596, Lawrence G. Paull
  Production, Casting, 597, Jane Feinberg
  Production, Casting, 598, Mike Fenton
  Production, Casting, 599, Marci Liroff
  Editing, Editor, 600, Marsha Nakashima
  Art, Art Direction, 601, David L. Snyder
  Art, Set Decoration, 602, Linda DeScenna
  Art, Set Decoration, 603, Leslie McCarthy-Frankenheimer
  Costume & Make-Up, Costume Design, 605, Michael Kaplan
  Costume & Make-Up, Costume Design, 606, Charles Knode
  Camera, Additional Photography, 1590, Steven Poster
  Art, Set Decoration, 4712, Thomas L. Roysden
  Writing, Screenplay, 7191, David Webb Peoples
  Production, Production Manager, 50237, Alan Collis
  Production, Publicist, 55244, Saul Kahan
  Art, Production Illustrator, 60283, Tom Southwell
  Sound, Sound mixer, 91875, Bud Alper
  Crew, Stunt Coordinator, 999716, Gary Combs
  Camera, Still Photographer, 1390535, Stephen Vaughan
  Art, Assistant Art Director, 1404757, Stephen Dane
  Art, Construction Coordinator, 1404758, James F. Orendorff
  Crew, Property Master, 1404759, Terry E. Lewis
  Art, Production Illustrator, 1404760, Mentor Huebner
  Art, Production Illustrator, 1404761, Sherman Labby
  Editing, Dialogue Editor, 1404763, Mike Hopkins
  Sound, Sound Editor, 1404764, Peter Pennell
  Camera, Camera Operator, 1404765, Albert Bettcher
  Camera, Camera Operator, 1404766, Dick Colean
  Camera, Camera Operator, 1404767, Robert C. Thomas

Titulo: Gladiator
Id: 98
Fecha Emision: 2000-05-01
Presupuesto: 457640427
Ingresos: 103000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Executive Producer, 578, Ridley Scott
  Production, Producer, 929, David Franzoni
  Writing, Screenplay, 929, David Franzoni
  Production, Producer, 930, Branko Lustig
  Production, Producer, 931, Douglas Wick
  Writing, Screenplay, 932, John Logan
  Writing, Screenplay, 933, William Nicholson
  Camera, Director of Photography, 943, John Mathieson
  Art, Production Design, 944, Arthur Max
  Art, Set Decoration, 945, Crispian Sallis
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Sound, Original Music Composer, 947, Hans Zimmer
  Sound, Original Music Composer, 948, Lisa Gerrard
  Production, Casting, 949, Louis DiGiaimo
  Editing, Editor, 950, Pietro Scalia
  Visual Effects, Visual Effects, 951, Colin Coull
  Production, Executive Producer, 2212, Walter F. Parkes
  Sound, Sound, 3193, Scott Martin Gershin
  Art, Supervising Art Director, 4710, Benjamín Fernández
  Crew, Animatronic and Prosthetic Effects, 6060, Neil Corbould
  Art, Art Direction, 7790, Peter Russell
  Crew, Post Production Supervisor, 8532, Lisa Dennis Kennedy
  Art, Art Direction, 8646, Keith Pain
  Production, Executive Producer, 8701, Laurie MacDonald
  Costume & Make-Up, Makeup Artist, 8939, Paul Engelen
  Costume & Make-Up, Hairstylist, 9161, Carmel Jackson
  Art, Assistant Art Director, 9822, Adam O'Neill
  Production, Associate Producer, 12785, Terry Needham
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Crew, Second Unit Cinematographer, 17649, Alexander Witt
  Art, Supervising Art Director, 34513, John King
  Production, Casting Associate, 54489, Stephanie Corsalini
  Art, Supervising Art Director, 71579, David Allday
  Crew, Property Master, 117226, Graeme Purdy
  Sound, Foley, 548439, James Moriana
  Sound, Foley, 548445, Jeffrey Wilhoit
  Camera, Camera Operator, 569913, Branko Knez
  Directing, Assistant Director, 1102140, Adam Somner
  Crew, Stunts, 1185530, Eddie Stacey
  Visual Effects, Visual Effects Producer, 1290901, Nikki Penny
  Costume & Make-Up, Makeup Artist, 1317305, Trefor Proud
  Costume & Make-Up, Hairstylist, 1319624, Alex King
  Costume & Make-Up, Hairstylist, 1319625, Marese Langan
  Costume & Make-Up, Makeup Artist, 1332186, Ivana Primorac
  Camera, Steadicam Operator, 1332515, Klemens Becker
  Costume & Make-Up, Makeup Artist, 1334490, Laura McIntosh
  Art, Greensman, 1335543, Roger Holden
  Sound, Foley, 1338372, Dan O'Connell
  Sound, Sound Effects Editor, 1342657, Jon Title
  Sound, Sound Re-Recording Mixer, 1345595, Scott Millan
  Sound, Foley, 1367493, John T. Cucci
  Crew, Property Master, 1370841, Philip McDonald
  Crew, Stunt Coordinator, 1378239, Phil Neilson
  Editing, First Assistant Editor, 1388921, Chisako Yokoyama
  Sound, Sound Re-Recording Mixer, 1391571, Bob Beemer
  Sound, Sound Effects Editor, 1392081, Randy Kelley
  Camera, Camera Operator, 1392246, Clive Jackson
  Crew, Compositors, 1392629, Simon Stanley-Clamp
  Editing, Dialogue Editor, 1392901, Lauren Stephens
  Camera, Camera Operator, 1393364, Peter Taylor
  Camera, Still Photographer, 1393448, Jaap Buitendijk
  Sound, Sound Re-Recording Mixer, 1394130, Frank A. Montaño
  Art, Assistant Art Director, 1394775, José Luis del Barco
  Visual Effects, Visual Effects Supervisor, 1404221, Tim Burke
  Crew, Unit Publicist, 1405246, Rob Harris
  Sound, ADR & Dubbing, 1406616, Chris Jargo
  Sound, ADR & Dubbing, 1408672, Laura Graham
  Sound, ADR & Dubbing, 1408779, David A. Cohen
  Production, Location Manager, 1410333, Jeremy Johns
  Visual Effects, Visual Effects Supervisor, 1411090, Rob Harvey
  Production, Location Manager, 1411120, Terry Blyther
  Costume & Make-Up, Hairstylist, 1419186, Ivana Nemec
  Crew, CG Supervisor, 1425484, Laurent Hugueniot
  Costume & Make-Up, Hairstylist, 1427823, Graham Johnston
  Art, Property Master, 1428473, Bruce Bigg
  Editing, Color Timer, 1429549, Dale E. Grahn
  Costume & Make-Up, Hairstylist, 1429628, Anita Burger
  Editing, Dialogue Editor, 1454536, Simon Coke
  Costume & Make-Up, Makeup Artist, 1456365, Melissa Lackersteen
  Costume & Make-Up, Makeup Artist, 1456366, Jo Allen
  Crew, Scenic Artist, 1456369, Cynthia Sadler
  Crew, Scenic Artist, 1456370, Bob Walker
  Crew, Animatronic and Prosthetic Effects, 1456371, Astrig Akseralian
  Crew, Visual Effects Editor, 1456373, Wesley Sewell
  Visual Effects, Visual Effects Supervisor, 1456374, John Nelson
  Camera, Camera Operator, 1456375, Ben Gooder
  Camera, Camera Operator, 1456376, Felix Schroer
  Camera, Camera Technician, 1456378, Agapios Louka
  Production, Casting, 1456379, Mustapha Charif
  Production, Casting, 1456380, Kathleen Mackie
  Editing, First Assistant Editor, 1456381, Michael Reynolds
  Sound, Music Editor, 1456383, Dashiell Rae
  Crew, Transportation Coordinator, 1456384, Gerry Gore
  Production, Location Manager, 1456385, Mike Higgins
  Crew, Stunts, 1506768, Miroslav Lhotka
  Lighting, Gaffer, 1597990, Daniele Botteselle
  Crew, Special Effects, 1603859, John Evans
  Crew, Title Graphics, 1604352, Robert Dawson
  Directing, Assistant Director, 1643667, Ali Cherkaoui

Titulo: Alien
Id: 348
Fecha Emision: 1979-05-25
Presupuesto: 104931801
Ingresos: 11000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Casting, 668, Mary Selway
  Production, Producer, 915, David Giler
  Production, Producer, 1723, Walter Hill
  Sound, Original Music Composer, 1760, Jerry Goldsmith
  Art, Production Design, 4616, Michael Seymour
  Writing, Screenplay, 5045, Dan O'Bannon
  Production, Executive Producer, 5046, Ronald Shusett
  Writing, Writer, 5046, Ronald Shusett
  Production, Producer, 5053, Gordon Carroll
  Production, Producer, 5054, Ivor Powell
  Camera, Director of Photography, 5055, Derek Vanlint
  Editing, Editor, 5056, Terry Rawlings
  Editing, Editor, 5057, Peter Weatherley
  Art, Art Direction, 5058, Roger Christian
  Art, Production Design, 5058, Roger Christian
  Art, Art Direction, 5059, Leslie Dilley
  Art, Set Decoration, 5060, Ian Whittaker
  Costume & Make-Up, Costume Design, 5061, John Mollo
  Sound, Sound Editor, 5062, Robert Hathaway
  Art, Production Design, 9136, H.R. Giger
  Crew, Special Effects, 9402, Brian Johnson
  Production, Casting, 23349, Mary Goldberg
  Art, Conceptual Design, 62460, Jean Giraud
  Art, Assistant Art Director, 1378834, Jonathan Amberston
  Crew, Property Master, 1378835, Dave Jordan
  Editing, Dialogue Editor, 1378836, Bryan Tilling
  Sound, Dolby Consultant, 1378837, Max Bell
  Crew, Stunt Coordinator, 1378838, Roy Scammell
  Camera, Still Photographer, 1378839, Bob Penn

Titulo: Black Hawk Down
Id: 855
Fecha Emision: 2001-12-28
Presupuesto: 172989651
Ingresos: 92000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Producer, 770, Jerry Bruckheimer
  Production, Casting, 897, Bonnie Timmermann
  Production, Executive Producer, 930, Branko Lustig
  Production, Unit Production Manager, 930, Branko Lustig
  Art, Production Design, 944, Arthur Max
  Sound, Original Music Composer, 947, Hans Zimmer
  Editing, Editor, 950, Pietro Scalia
  Camera, Director of Photography, 1129, Slawomir Idziak
  Production, Executive Producer, 2444, Mike Stenson
  Production, Executive Producer, 2446, Chad Oman
  Production, Associate Producer, 2448, Pat Sandston
  Sound, Music Supervisor, 5132, Bob Badami
  Art, Supervising Art Director, 5673, Marco Trentini
  Visual Effects, Special Effects Supervisor, 6060, Neil Corbould
  Art, Art Direction, 7789, Cliff Robinson
  Art, Art Direction, 8646, Keith Pain
  Camera, Steadicam Operator, 8673, Daniele Massaccesi
  Costume & Make-Up, Costume Design, 11271, Sammy Sheldon
  Sound, Supervising ADR Editor, 12562, Anna MacKenzie
  Writing, Novel, 12782, Mark Bowden
  Writing, Screenplay, 12783, Ken Nolan
  Production, Associate Producer, 12785, Terry Needham
  Directing, First Assistant Director, 12785, Terry Needham
  Production, Executive Producer, 12786, Simon West
  Art, Set Decoration, 12787, Elli Griff
  Costume & Make-Up, Costume Design, 12788, David Murphy
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Production, Executive In Charge Of Production, 15004, Charles Newirth
  Art, Art Direction, 16595, Pier Luigi Basile
  Crew, Additional Music, 19016, Michael Brook
  Art, Art Direction, 23364, Gianni Giovagnoni
  Art, Art Direction, 34512, Ivo Hušnjak
  Production, Assistant Production Coordinator, 40838, Damian Anderson
  Production, Casting Associate, 60935, Seth Yanklewitz
  Sound, Music Editor, 63421, Marc Streitenfeld
  Camera, Aerial Camera (suggest in addition to Helicopter Camera), 91123, Michael Kelem
  Editing, Dialogue Editor, 91891, Mark L. Mangino
  Sound, Production Sound Mixer, 105780, Chris Munro
  Crew, Property Master, 117226, Graeme Purdy
  Costume & Make-Up, Key Hair Stylist, 138639, Giancarlo De Leonardis
  Crew, Armorer, 570129, Branko Repalust
  Directing, Script Supervisor, 570136, Nada Pinter
  Production, Production Supervisor, 998152, Lucio Trentini
  Sound, Foley, 1116937, John Roesch
  Crew, Armory Coordinator, 1117347, Simon Atherton
  Sound, Boom Operator, 1311960, Andrew Griffiths
  Costume & Make-Up, Wardrobe Supervisor, 1331983, Dana Schondelmeyer
  Art, Greensman, 1335543, Roger Holden
  Visual Effects, Visual Effects Supervisor, 1337418, Nathan McGuinness
  Sound, Foley, 1338372, Dan O'Connell
  Sound, Additional Sound Re-Recording Mixer, 1342242, Rick Ash
  Sound, Foley Editor, 1352966, Michael Hertlein
  Sound, Foley, 1367493, John T. Cucci
  Sound, Sound Effects Editor, 1367667, Perry Robertson
  Crew, Armorer, 1373558, Nick Komornicki
  Crew, Stunt Coordinator, 1378239, Phil Neilson
  Directing, Script Supervisor, 1385884, Sally Jones
  Editing, First Assistant Editor, 1388921, Chisako Yokoyama
  Editing, Dialogue Editor, 1392901, Lauren Stephens
  Camera, Camera Operator, 1394783, Martin Kenzie
  Production, Casting, 1398505, Suzanne M. Smith
  Sound, Sound Re-Recording Mixer, 1399141, Michael Minkler
  Production, Production Supervisor, 1399484, Angela Quiles
  Lighting, Electrician, 1403545, Dean Brkic
  Costume & Make-Up, Key Makeup Artist, 1404200, Fabrizio Sforza
  Crew, Makeup Effects, 1404201, Rob Mayor
  Production, Production Manager, 1404202, Ahmed Darif
  Production, Production Manager, 1404203, T. David Pash
  Production, Production Manager, 1404204, Jamal Souissi
  Crew, Post Production Supervisor, 1404205, Teresa Kelly
  Art, Art Department Coordinator, 1404206, Annick Biltresse
  Art, Set Designer, 1404207, Roberta Federico
  Art, Set Designer, 1404208, Monica Sallustio
  Art, Leadman, 1404209, Erik Mulet
  Sound, Supervising Sound Editor, 1404212, Karen Baker Landers
  Crew, Sound Recordist, 1404213, Andrea Eliseyan
  Editing, Dialogue Editor, 1404214, Stephanie Flack
  Sound, Sound Effects Editor, 1404215, Gregory Hainer
  Sound, Sound Effects Editor, 1404216, Michael A. Reagan
  Sound, Sound Effects Editor, 1404217, Peter Staubli
  Sound, Sound Re-Recording Mixer, 1404218, Myron Nettinga
  Crew, Special Effects Coordinator, 1404219, Carol McAulay
  Crew, Special Effects Coordinator, 1404220, Mark Meddings
  Visual Effects, Visual Effects Supervisor, 1404221, Tim Burke
  Crew, Visual Effects Editor, 1404222, Kristopher Kasper
  Crew, Visual Effects Editor, 1404223, Lars Vinther
  Visual Effects, Visual Effects Producer, 1404225, Lindsay Hallett
  Camera, Still Photographer, 1404230, Sidney Ray Baldwin
  Lighting, Chief Lighting Technician, 1404231, Marek Modzelewski
  Costume & Make-Up, Set Costumer, 1404232, Ali Lammari
  Costume & Make-Up, Set Costumer, 1404233, Adam Roach
  Crew, Transportation Coordinator, 1404234, Ravi Dube
  Crew, Unit Publicist, 1404235, Michael Singer
  Production, Location Manager, 1404238, Khalid Nekmouche
  Crew, Dialect Coach, 1404241, Sandra Butterworth
  Production, Location Manager, 1404243, Majid Aoulad Abdellah
  Camera, Aerial Director of Photography, 1404244, John Marzano
  Sound, ADR Editor, 1404841, Zack Davis
  Crew, Carpenter, 1405377, Francesco Valento
  Sound, Supervising Dialogue Editor, 1405382, Chris Hogan
  Crew, CG Supervisor, 1425484, Laurent Hugueniot
  Crew, Utility Stunts, 1444646, Stanislav Satko
  Editing, Associate Editor, 1456373, Wesley Sewell
  Editing, First Assistant Editor, 1456381, Michael Reynolds
  Writing, Storyboard, 1487590, Sylvain Despretz
  Writing, Story Editor, 1510846, René Brar
  Crew, Stand In, 1525014, Baron Jay
  Sound, Music Supervisor, 1530166, Kathy Nelson
  Art, Construction Coordinator, 1532615, Dan Pemberton
  Costume & Make-Up, Costume Coordinator, 1535950, Darryl M. Athons
  Production, Researcher, 1536521, Vanessa Bendetti
  Crew, Armorer, 1536582, Tommy Dunne
  Crew, Armorer, 1536588, John Nixon
  Crew, Armorer, 1536589, Trevor Rochester
  Camera, First Assistant Camera, 1536592, Henryk Jedynak
  Lighting, Lighting Technician, 1536593, Jacek Kurowski
  Visual Effects, Visual Effects Coordinator, 1536594, Laya Armian
  Editing, Color Timer, 1550730, Bob Kaiser
  Art, Painter, 1554018, Glauco Isidori
  Costume & Make-Up, Hairstylist, 1554019, Michele Vigliotta
  Costume & Make-Up, Prosthetic Supervisor, 1554020, Simon Rose
  Crew, Second Unit, 1554023, Nicholas Livesey
  Crew, Set Medic, 1554024, Celine Dechanet Painchaux
  Crew, Set Production Assistant, 1554025, Pierre Ellul
  Crew, Stunts, 1554026, Younes Afroukh
  Crew, Transportation Captain, 1554028, David Pash
  Production, Unit Production Manager, 1554029, Pamela Hochschartner
  Lighting, Best Boy Electric, 1554030, Najib Ben Fares
  Production, Associate Producer, 1554033, Harry Humphries
  Production, Production Accountant, 1554037, Donna Glasser-Hancock
  Sound, First Assistant Sound Editor, 1554039, Tony Negrete
  Sound, Orchestrator, 1554041, Bruce Fowler
  Sound, Sound Engineer, 1554044, Kevin Globerman
  Visual Effects, 3D Artist, 1554045, Paul Amer
  Visual Effects, Digital Compositors, 1554046, Chris Elson
  Camera, Camera Technician, 1554047, Stefan Baur
  Art, Set Dresser, 1554048, Mark Allett
  Sound, Assistant Sound Editor, 1580665, Todd Egan
  Camera, Key Grip, 1592605, David Appleby
  Lighting, Gaffer, 1610679, Mateusz Kuzniak
  Crew, Aerial Coordinator, 1685460, David Paris
  Art, Assistant Property Master, 1739747, Steve Payne
  Camera, Camera Loader, 1739760, Abdellatif El Ansary
  Camera, Dolly Grip, 1739761, Mic Mueller
  Camera, Grip, 1739763, Lahcen Herraf
  Costume & Make-Up, Makeup Artist, 1739770, Gianbattista Graziano
  Crew, Pilot, 1739822, Francisco Paco Garcia
  Directing, Second Assistant Director, 1739825, Darin Rivetti
  Directing, Third Assistant Director, 1739826, William Dodds
  Production, Casting Assistant, 1739828, Jose Cabrera
  Sound, Musician, 1739829, Jim Dooley
  Visual Effects, 2D Artist, 1739830, Hani AlYousif

Titulo: 1492: Conquest of Paradise
Id: 1492
Fecha Emision: 1992-10-09
Presupuesto: 7191399
Ingresos: 47000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Sound, Music Editor, 296, Robin Clarke
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Sound, Original Music Composer, 595, Vangelis
  Costume & Make-Up, Costume Design, 606, Charles Knode
  Production, Casting, 949, Louis DiGiaimo
  Editing, Editor, 2705, William M. Anderson
  Production, Casting, 3311, Priscilla John
  Art, Supervising Art Director, 4710, Benjamín Fernández
  Art, Supervising Art Director, 5021, Leslie Tomkins
  Camera, Director of Photography, 7783, Adrian Biddle
  Art, Assistant Art Director, 7790, Peter Russell
  Production, Executive Producer, 8374, Iain Smith
  Art, Art Direction, 8382, Kevin Phipps
  Sound, Supervising Sound Editor, 9854, Jim Shields
  Visual Effects, Visual Effects Supervisor, 10721, Kent Houston
  Crew, Stunt Coordinator, 10976, Greg Powell
  Editing, Editor, 16403, Françoise Bonnot
  Production, Producer, 16928, Alain Goldman
  Production, Executive Producer, 17398, Mimi Polk Gitlin
  Art, Production Design, 17400, Norris Spencer
  Writing, Author, 21269, Roselyne Bosch
  Editing, Editor, 21271, Armen Minasian
  Editing, Editor, 21272, Les Healey
  Camera, Camera Operator, 40765, David Worley
  Camera, Still Photographer, 40796, David Appleby
  Editing, Editor, 44046, Deborah Zeitman
  Art, Art Direction, 75799, Martin Hitchcock
  Production, Location Manager, 75804, Kevin De La Noy
  Art, Set Decoration, 100983, Ann Mollo
  Art, Art Direction, 190090, Luke Scott
  Production, Producer, 550414, Rose Bosch
  Production, Casting, 577810, Dan Parada
  Production, Location Manager, 947694, Mark Albela
  Production, Producer, 948498, Marc Boyman
  Production, Producer, 980086, Garth Thomas
  Lighting, Gaffer, 1010007, Francesc Brualla
  Production, Producer, 1102072, Pere Fages
  Directing, Script Supervisor, 1262129, Luca Kouimelis
  Art, Art Direction, 1327919, Antonio Patón
  Costume & Make-Up, Costume Design, 1327921, Barbara Rutter
  Crew, Property Master, 1335181, Terry Wells
  Art, Assistant Art Director, 1377119, Tony Rimmington
  Art, Assistant Art Director, 1394774, Luciano Arroyo
  Art, Assistant Art Director, 1394775, José Luis del Barco
  Art, Assistant Art Director, 1394776, Amado Conejo
  Crew, Property Master, 1394777, Charles Torbett
  Art, Greensman, 1394778, Camilo Lira Colin
  Art, Greensman, 1394779, German Ramirez
  Art, Sculptor, 1394780, Peter Voysey
  Lighting, Gaffer, 1394782, Kevin Day
  Camera, Camera Operator, 1394783, Martin Kenzie
  Directing, Script Supervisor, 1394786, Guillermo Cano
  Production, Location Manager, 1394787, Juan Carlos Caro
  Crew, Chef, 1394789, Gina McShane
  Crew, Chef, 1394790, Luis Puig
  Production, Location Manager, 1394791, Eduardo Santana
  Crew, Chef, 1394792, John Whelan

Titulo: Kingdom of Heaven
Id: 1495
Fecha Emision: 2005-05-03
Presupuesto: 211643158
Ingresos: 130000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Casting, 474, Jina Jay
  Production, Casting, 495, Debra Zane
  Editing, Editor, 563, Dody Dorn
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Executive Producer, 930, Branko Lustig
  Production, Unit Production Manager, 930, Branko Lustig
  Camera, Director of Photography, 943, John Mathieson
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Production, Casting, 4406, Antoinette Boulat
  Sound, Original Music Composer, 5553, Harry Gregson-Williams
  Art, Supervising Art Director, 5673, Marco Trentini
  Visual Effects, Special Effects Supervisor, 6060, Neil Corbould
  Camera, Steadicam Operator, 8673, Daniele Massaccesi
  Camera, Camera Operator, 8674, Martin Hume
  Costume & Make-Up, Makeup Designer, 8939, Paul Engelen
  Production, Co-Producer, 10903, Henning Molfenter
  Production, Executive Producer, 12785, Terry Needham
  Sound, Sound Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Sound, Sound Effects Editor, 15331, Bryan Bowen
  Production, Co-Producer, 19619, Thierry Potok
  Art, Set Decoration, 20507, Sonja Klaus
  Crew, Second Unit Cinematographer, 22100, Hugh Johnson
  Art, Art Direction, 23453, Robert Cowper
  Writing, Screenplay, 34510, William Monahan
  Production, Executive Producer, 34511, Lisa Ellzey
  Art, Art Direction, 34512, Ivo Hušnjak
  Art, Art Direction, 34513, John King
  Sound, Assistant Sound Editor, 40769, David Mackie
  Sound, Sound Mixer, 40772, David Stephenson
  Sound, Boom Operator, 40773, Gary Dodkin
  Camera, Still Photographer, 40796, David Appleby
  Crew, Post-Production Manager, 60934, Patrick Esposito
  Camera, First Assistant Camera, 60941, Ben Wilson
  Sound, Music Supervisor, 63421, Marc Streitenfeld
  Crew, Visual Effects Editor, 67201, Ian Differ
  Art, Construction Coordinator, 92214, Alain Brochu
  Visual Effects, Visual Effects Producer, 113674, Victoria Alonso
  Art, Sculptor, 117220, Colin Jackman
  Art, Property Master, 117226, Graeme Purdy
  Visual Effects, Visual Effects Supervisor, 122274, Peter Chiang
  Production, Line Producer, 582915, José Luis Escolar
  Production, Co-Producer, 947694, Mark Albela
  Production, Co-Producer, 959332, Denise O'Dell
  Crew, Additional Music, 1001706, Stephen Barton
  Art, Construction Foreman, 1085575, Damir Gabelica
  Art, Art Direction, 1087318, Carlos Bodelón
  Production, Unit Manager, 1119466, Alex Corven Caronia
  Lighting, Rigging Grip, 1141914, Emanuele Salvatore
  Costume & Make-Up, Hairstylist, 1182554, Marcelle Genovese
  Production, Casting Associate, 1212071, Tannis Vallely
  Costume & Make-Up, Costume Supervisor, 1322137, Clare Spragge
  Art, Set Designer, 1323112, Iñigo Navarro
  Crew, CG Supervisor, 1373716, Gary Brozenich
  Lighting, Gaffer, 1373728, Chuck Finch
  Sound, Sound Recordist, 1374790, Daniel Urdiales
  Crew, Post Production Assistant, 1389524, Carmen Ruiz de Huidobro
  Directing, Script Supervisor, 1389548, Anna Worley
  Crew, Sequence Supervisor, 1394721, Adam Gascoyne
  Art, Assistant Art Director, 1398083, Abdellah Baadil
  Lighting, Lighting Artist, 1400403, Shawn Walsh
  Lighting, Rigging Gaffer, 1403545, Dean Brkic
  Production, Publicist, 1403550, Steve Newman
  Production, Associate Producer, 1404205, Teresa Kelly
  Crew, Special Effects Coordinator, 1404220, Mark Meddings
  Camera, Aerial Director of Photography, 1404244, John Marzano
  Crew, Transportation Coordinator, 1405243, Brian Baverstock
  Art, Art Department Coordinator, 1405374, Francesca Birri
  Editing, Dialogue Editor, 1408378, Simon Chase
  Art, Art Direction, 1412085, Alessandro Alberti
  Visual Effects, Visual Effects Coordinator, 1417821, Claudia Dehmel
  Sound, Foley Editor, 1418322, Harry Barnes
  Sound, ADR & Dubbing, 1424935, Paul Conway
  Crew, Dialect Coach, 1457374, Roisin Carty
  Production, Associate Producer, 1463279, Ty Warren
  Production, Co-Producer, 1471199, Bruce Devan
  Production, Production Manager, 1471199, Bruce Devan
  Crew, Set Production Assistant, 1475344, Topaz Adizes
  Production, Line Producer, 1476831, Karim Abouobayd
  Crew, Motion Capture Artist, 1559186, Gary Roberts
  Art, Painter, 1574114, Giancarlo Di Fusco
  Writing, Storyboard, 1574145, Cristiano Donzelli
  Crew, Video Assist Operator, 1578650, Robert Hamilton
  Costume & Make-Up, Makeup Artist, 1579406, Mariam Lee Abounouom
  Costume & Make-Up, Costume Design, 1583781, Louis Joon
  Camera, Grip, 1592605, David Appleby
  Production, Production Accountant, 1607659, Giorgio Catalano
  Art, Production Illustrator, 1621395, Lora E. Revitt
  Crew, Stunts, 1627984, Rachid Abbad
  Crew, Armorer, 1698595, Brian Bero
  Art, Art Department Assistant, 1733726, Saida Elidrissi
  Costume & Make-Up, Assistant Costume Designer, 1739256, Andrea Cripps
  Art, Greensman, 1846280, Fatiha Aitbadi
  Camera, Additional Camera, 1846288, Brahim Ait Belkas
  Costume & Make-Up, Set Costumer, 1846738, Gabi Brown
  Crew, Carpenter, 1846739, Robert Capan
  Crew, CGI Supervisor, 1846740, John Harvey
  Crew, Driver, 1846742, Diego Campos
  Crew, Loader, 1846744, Lewis Hume
  Crew, Mix Technician, 1846746, Esther Smith
  Crew, Stand In, 1846747, Abdellah Achir
  Crew, Stunt Coordinator, 1846748, Gustáv Kyselica
  Crew, Transportation Captain, 1846749, El Mahjoub Najma
  Crew, Unit Publicist, 1846750, Quinn Donoghue
  Crew, Utility Stunts, 1846751, Oleg Botin
  Directing, Assistant Director, 1846755, Adil Abdelwahab
  Lighting, Electrician, 1846758, Sam Horsefield
  Lighting, Lighting Technician, 1846759, Fred Brown
  Production, Location Manager, 1846762, Gonzalo Cañellas
  Production, Production Coordinator, 1846763, Patricia Nieto
  Production, Production Supervisor, 1846764, Kimberley Ann Berdy
  Visual Effects, Digital Compositors, 1846766, Judy Barr

Titulo: Thelma & Louise
Id: 1541
Fecha Emision: 1991-05-24
Presupuesto: 45361000
Ingresos: 16000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Sound, Original Music Composer, 947, Hans Zimmer
  Production, Casting, 949, Louis DiGiaimo
  Costume & Make-Up, Costume Design, 5710, Elizabeth McBride
  Sound, Music Editor, 5712, Laura Perlman
  Camera, Director of Photography, 7783, Adrian Biddle
  Art, Art Direction, 7849, Lisa Dean
  Sound, Supervising Sound Editor, 9854, Jim Shields
  Crew, Dialect Coach, 13050, Tim Monich
  Art, Set Decoration, 13677, Anne H. Ahrens
  Sound, ADR Editor, 14459, John Poyner
  Crew, Stunt Coordinator, 16659, Bobby Bass
  Production, Co-Producer, 17397, Callie Khouri
  Writing, Screenplay, 17397, Callie Khouri
  Production, Producer, 17398, Mimi Polk Gitlin
  Editing, Editor, 17399, Thom Noble
  Art, Production Design, 17400, Norris Spencer
  Camera, Camera Operator, 17649, Alexander Witt
  Directing, First Assistant Director, 55600, Steve Danton
  Costume & Make-Up, Hairstylist, 74968, Leslie Ann Anderson
  Costume & Make-Up, Makeup Artist, 74969, Richard Arrington
  Production, Unit Production Manager, 76160, Mel Dellar
  Costume & Make-Up, Hairstylist, 90194, Anthony Cortino
  Costume & Make-Up, Hairstylist, 548413, Karl Wesson
  Camera, Key Grip, 557873, Bob Rose
  Directing, Script Supervisor, 1262129, Luca Kouimelis
  Camera, Still Photographer, 1272269, Roland Neveu
  Crew, Aerial Coordinator, 1278542, Robert 'Bobby Z' Zajonc
  Costume & Make-Up, Key Costumer, 1380704, Taneia Lednicky
  Art, Property Master, 1389589, Vic Petrotta Jr.
  Crew, Special Effects Coordinator, 1403399, Stan Parks
  Camera, Aerial Director of Photography, 1403415, David B. Nowell
  Art, Leadman, 1425908, Kenneth Turek
  Production, Co-Producer, 1434780, Dean O'Brien
  Production, Unit Production Manager, 1434780, Dean O'Brien
  Sound, Music Supervisor, 1530166, Kathy Nelson
  Costume & Make-Up, Makeup Artist, 1531899, Bonita DeHaven
  Art, Painter, 1565941, Gary Clark
  Sound, Boom Operator, 1574659, Timothy P. Salmon
  Sound, Sound Effects Editor, 1621243, Bob Risk
  Camera, Dolly Grip, 1760567, Brad Rea
  Art, Set Designer, 1805997, Alan S. Kaye
  Art, Title Designer, 1806132, Anthony Goldschmidt
  Art, Construction Coordinator, 1875004, Richard J. Bayard
  Art, Construction Foreman, 1875007, Roger M. Janson
  Art, Construction Foreman, 1875009, Jim Olson
  Art, Greensman, 1875012, Robert Butch Samarzich
  Art, Construction Foreman, 1875014, Scott Snyder
  Art, Construction Foreman, 1875015, Mark Vitale
  Lighting, Best Boy Electrician, 1875016, Paul Amorelli
  Camera, Dolly Grip, 1875017, R. Scott Judge
  Production, Production Coordinator, 1875075, Christine Baer
  Crew, Pilot, 1875076, Don Hildebrand

Titulo: Black Rain
Id: 4105
Fecha Emision: 1989-09-22
Presupuesto: 45892212
Ingresos: 30000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Art, Set Decoration, 796, John M. Dwyer
  Sound, Original Music Composer, 947, Hans Zimmer
  Editing, Editor, 1047, Tom Rolf
  Production, Casting, 1221, Dianne Crittenden
  Art, Art Direction, 2083, Herman F. Zimmerman
  Camera, Director of Photography, 2209, Jan de Bont
  Art, Art Direction, 2999, John Jay Moore
  Art, Set Decoration, 4188, Leslie Bloom
  Costume & Make-Up, Costume Design, 7735, Ellen Mirojnick
  Art, Set Decoration, 14342, Richard C. Goddard
  Art, Production Design, 17400, Norris Spencer
  Production, Unit Production Manager, 17630, Michael Tadross
  Art, Set Decoration, 17877, Alan Hicks
  Writing, Author, 19893, Warren Lewis
  Production, Casting Assistant, 25830, Debi Manwiller
  Writing, Author, 34692, Craig Bolotin
  Production, Executive Producer, 34692, Craig Bolotin
  Production, Producer, 34693, Stanley R. Jaffe
  Production, Executive Producer, 34694, Julie Kirkham
  Production, Producer, 34695, Sherry Lansing
  Production, Line Producer, 34696, Yosuke Mizuno
  Production, Casting Associate, 35491, Joy Dickson
  Production, Unit Production Manager, 76160, Mel Dellar
  Crew, Pilot, 91042, Al Cerullo
  Production, Associate Producer, 113225, Alan Poul
  Production, Location Manager, 553347, Atsushi Takayama
  Directing, Script Supervisor, 1262129, Luca Kouimelis
  Crew, Pilot, 1278542, Robert 'Bobby Z' Zajonc
  Production, Location Manager, 1453320, Eric Klosterman
  Production, Unit Production Manager, 1551963, David Salven
  Production, Location Manager, 1645977, Ken Haber
  Production, Casting, 1685817, Nobuaki Murooka
  Art, Set Designer, 1691936, James R. Bayliss
  Production, Unit Production Manager, 1782974, William Watkins
  Art, Set Designer, 1805997, Alan S. Kaye
  Art, Set Designer, 1805998, Robert Maddy
  Production, Location Manager, 1806126, Robert Doyle
  Production, Location Manager, 1806127, Susumu Ejima
  Production, Location Manager, 1806128, Kazuaki Enomoto
  Production, Location Manager, 1806129, Kenichi Horii
  Production, Location Manager, 1806130, Steven Shkolnik
  Art, Title Designer, 1806132, Anthony Goldschmidt

Titulo: G.I. Jane
Id: 4421
Fecha Emision: 1997-08-22
Presupuesto: 48169156
Ingresos: 50000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Producer, 551, Suzanne Todd
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Production, Casting, 949, Louis DiGiaimo
  Editing, Editor, 950, Pietro Scalia
  Production, Producer, 3416, Demi Moore
  Production, Producer, 4504, Roger Birnbaum
  Sound, Original Music Composer, 7020, Trevor Jones
  Costume & Make-Up, Costume Design, 7719, Marilyn Vance
  Art, Art Direction, 8285, Richard L. Johnson
  Art, Set Decoration, 11079, Cindy Carr
  Camera, Director of Photography, 22100, Hugh Johnson
  Writing, Screenplay, 28239, David Twohy
  Writing, Screenplay, 37208, Danielle Alexandra
  Production, Casting, 577752, Brett Goldstein

Titulo: American Gangster
Id: 4982
Fecha Emision: 2007-11-02
Presupuesto: 266465037
Ingresos: 100000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Producer, 339, Brian Grazer
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Executive Producer, 930, Branko Lustig
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Production, Executive Producer, 2260, Steven Zaillian
  Writing, Screenplay, 2260, Steven Zaillian
  Production, Casting, 2952, Avy Kaufman
  Production, Co-Producer, 5286, Jonathan Filley
  Art, Set Decoration, 6191, Leslie E. Rollins
  Production, Executive Producer, 7163, Nicholas Pileggi
  Camera, Director of Photography, 10688, Harris Savides
  Art, Set Decoration, 12258, Beth A. Rubino
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Art, Art Direction, 27040, Nicholas Lundy
  Writing, Writer, 34542, Mark Jacobson
  Production, Executive Producer, 40374, Michael Costigan
  Production, Executive Producer, 40375, James Whitaker
  Directing, Assistant Director, 60858, Apichart Chusakul
  Sound, Original Music Composer, 63421, Marc Streitenfeld
  Crew, Thanks, 65605, Muhammad Ali
  Crew, Thanks, 107375, Joe Frazier
  Crew, Utility Stunts, 206398, John Cenatiempo
  Editing, Dialogue Editor, 548437, Kimaree Long
  Camera, Camera Operator, 957361, Craig Haagensen
  Camera, Camera Operator, 983118, Larry McConkey
  Camera, Steadicam Operator, 983118, Larry McConkey
  Editing, First Assistant Editor, 1017296, Billy Rich
  Sound, Music Editor, 1049333, Del Spiva
  Crew, Stunt Coordinator, 1074163, G.A. Aguilar
  Sound, Additional Soundtrack, 1216495, Anthony Hamilton
  Costume & Make-Up, Set Costumer, 1333607, Hartsell Taylor
  Sound, Sound Effects Editor, 1342657, Jon Title
  Editing, Dialogue Editor, 1342658, Frederick H. Stahly
  Costume & Make-Up, Makeup Artist, 1353528, Felice Diamond
  Costume & Make-Up, Makeup Artist, 1378068, Carl Fullerton
  Sound, Sound Re-Recording Mixer, 1391571, Bob Beemer
  Sound, Sound Re-Recording Mixer, 1399141, Michael Minkler
  Production, Production Coordinator, 1399484, Angela Quiles
  Crew, Post Production Supervisor, 1404205, Teresa Kelly
  Sound, Supervising Sound Editor, 1404212, Karen Baker Landers
  Sound, Sound Effects Editor, 1404217, Peter Staubli
  Crew, Unit Publicist, 1405246, Rob Harris
  Sound, Sound Effects Editor, 1406390, Dan Hegeman
  Costume & Make-Up, Hairstylist, 1410208, Bert Reo Anderson
  Costume & Make-Up, Hair Department Head, 1414488, Kenneth Walker
  Directing, Script Supervisor, 1464541, Mary A. Kelly
  Production, Casting Associate, 1473182, Elizabeth Greenberg
  Sound, Music Supervisor, 1530166, Kathy Nelson
  Camera, Still Photographer, 1537446, David Lee
  Sound, Production Sound Mixer, 1551041, William Sarokin
  Editing, Color Timer, 1552549, David Orr
  Sound, Boom Operator, 1565211, George Leong
  Art, Art Department Coordinator, 1565212, Julia G. Hickman
  Crew, Stunts, 1579312, Gabriel Hansen
  Camera, Grip, 1606370, Matt Blades

Titulo: Matchstick Men
Id: 7270
Fecha Emision: 2003-09-01
Presupuesto: 65565672
Ingresos: 62000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Executive Producer, 24, Robert Zemeckis
  Production, Producer, 30, Steve Starkey
  Production, Casting Associate, 494, Terri Taylor
  Production, Casting, 495, Debra Zane
  Editing, Editor, 563, Dody Dorn
  Sound, Music Supervisor, 563, Dody Dorn
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Costume & Make-Up, Costume Design, 605, Michael Kaplan
  Camera, Director of Photography, 943, John Mathieson
  Sound, Original Music Composer, 947, Hans Zimmer
  Production, Producer, 1886, Ted Griffin
  Writing, Screenplay, 1886, Ted Griffin
  Sound, ADR & Dubbing, 12562, Anna MacKenzie
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Production, Producer, 23779, Jack Rapke
  Costume & Make-Up, Hair Department Head, 32282, Mary L. Mastro
  Production, Producer, 39387, Sean Bailey
  Art, Set Decoration, 53182, Nancy Nye
  Art, Production Design, 56518, Tom Foden
  Production, Co-Producer, 58787, Giannina Facio
  Sound, Music Editor, 63421, Marc Streitenfeld
  Production, Co-Producer, 77512, Charles J.D. Schlissel
  Writing, Book, 114406, Eric Garcia
  Costume & Make-Up, Makeup Artist, 134564, Amy L. Disarro
  Costume & Make-Up, Hairstylist, 578729, Larry Waggoner
  Crew, Special Effects Coordinator, 1172335, Martin Bresin
  Camera, Still Photographer, 1177850, François Duhamel
  Writing, Screenplay, 1196739, Nicholas Griffin
  Costume & Make-Up, Makeup Department Head, 1269670, Tarra D. Day
  Costume & Make-Up, Costume Supervisor, 1319744, Linda Matthews
  Art, Art Direction, 1324829, Michael Manson
  Art, Assistant Art Director, 1338148, Daniel R. Jennings
  Art, Construction Coordinator, 1376897, John Villarino
  Art, Art Department Coordinator, 1378752, Cheree Welsh
  Camera, Camera Operator, 1395463, Mitch Dubin
  Sound, Sound Re-Recording Mixer, 1399141, Michael Minkler
  Visual Effects, Visual Effects Producer, 1400563, Cari Thomas
  Sound, Sound Re-Recording Mixer, 1404218, Myron Nettinga
  Visual Effects, Visual Effects Supervisor, 1405385, Sheena Duggal
  Sound, ADR & Dubbing, 1406616, Chris Jargo
  Crew, CG Supervisor, 1415628, David Alexander Smith
  Costume & Make-Up, Makeup Artist, 1427397, Kristina Vogel
  Costume & Make-Up, Makeup Artist, 1458527, Allen Weisinger
  Sound, Sound Re-Recording Mixer, 1459647, Tom Lalley
  Camera, First Assistant Camera, 1476175, Steven Meizler
  Costume & Make-Up, Set Costumer, 1532197, Lorraine Crossman
  Lighting, Rigging Gaffer, 1538440, James Keys
  Crew, Visual Effects Editor, 1546812, Andrea Maxwell
  Art, Art Department Coordinator, 1549276, Adam Khalid
  Camera, Helicopter Camera, 1549288, Ralph Mendoza

Titulo: A Good Year
Id: 9726
Fecha Emision: 2006-09-09
Presupuesto: 42064105
Ingresos: 35000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Casting, 474, Jina Jay
  Editing, Editor, 563, Dody Dorn
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Casting, 4406, Antoinette Boulat
  Costume & Make-Up, Costume Design, 19058, Catherine Leterrier
  Art, Production Design, 20507, Sonja Klaus
  Art, Art Direction, 23453, Robert Cowper
  Costume & Make-Up, Hairstylist, 32354, Hayat Ouled Dahhou
  Art, Set Decoration, 54745, Bárbara Pérez-Solero
  Writing, Author, 58789, Marc Klein
  Writing, Author, 58790, Peter Mayle
  Sound, Original Music Composer, 63421, Marc Streitenfeld
  Camera, Director of Photography, 63422, Philippe Le Sourd
  Art, Art Direction, 63601, Frederic Evard
  Crew, Unit Publicist, 91941, Ernie Malik
  Costume & Make-Up, Makeup Artist, 1404200, Fabrizio Sforza
  Art, Art Department Coordinator, 1419166, Amy Simons
  Directing, Script Supervisor, 1462919, Nikki Clapp

Titulo: Hannibal
Id: 9740
Fecha Emision: 2001-02-08
Presupuesto: 351692268
Ingresos: 87000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Executive Producer, 930, Branko Lustig
  Camera, Director of Photography, 943, John Mathieson
  Art, Set Decoration, 945, Crispian Sallis
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Sound, Original Music Composer, 947, Hans Zimmer
  Production, Casting, 949, Louis DiGiaimo
  Editing, Editor, 950, Pietro Scalia
  Writing, Screenplay, 1255, David Mamet
  Writing, Screenplay, 2260, Steven Zaillian
  Production, Producer, 5398, Dino De Laurentiis
  Camera, Additional Camera, 8673, Daniele Massaccesi
  Camera, Camera Operator, 11113, David M. Dunlap
  Camera, Still Photographer, 12579, Phil Bray
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Costume & Make-Up, Makeup Artist, 15907, Alessandra Sampaolo
  Costume & Make-Up, Hairstylist, 15908, Elisabetta De Leonardis
  Art, Supervising Art Director, 16595, Pier Luigi Basile
  Writing, Novel, 16786, Thomas Harris
  Art, Production Design, 17400, Norris Spencer
  Crew, Second Unit Cinematographer, 17649, Alexander Witt
  Production, Producer, 19051, Martha De Laurentiis
  Sound, Music Editor, 63421, Marc Streitenfeld
  Art, Assistant Art Director, 77251, Halina Gebarowicz
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Art, Art Direction, 958921, David Crank
  Art, Assistant Art Director, 968175, Doug Huszti
  Directing, Script Supervisor, 1262129, Luca Kouimelis
  Costume & Make-Up, Costume Supervisor, 1328406, Dan Bronson
  Camera, Steadicam Operator, 1332515, Klemens Becker
  Sound, Foley, 1338372, Dan O'Connell
  Sound, Sound Effects Editor, 1342657, Jon Title
  Sound, Foley, 1367493, John T. Cucci
  Sound, Sound Re-Recording Mixer, 1377220, Doug Hemphill
  Crew, Stunt Coordinator, 1378239, Phil Neilson
  Costume & Make-Up, Set Costumer, 1378766, Catharine Fletcher Incaprera
  Editing, First Assistant Editor, 1388921, Chisako Yokoyama
  Editing, Dialogue Editor, 1392901, Lauren Stephens
  Costume & Make-Up, Set Costumer, 1400735, Marci R. Johnson
  Sound, ADR & Dubbing, 1401631, Michelle Pazer
  Lighting, Gaffer, 1401997, Bill O'Leary
  Costume & Make-Up, Makeup Department Head, 1404200, Fabrizio Sforza
  Sound, Supervising Sound Editor, 1404212, Karen Baker Landers
  Visual Effects, Visual Effects Supervisor, 1404221, Tim Burke
  Crew, Unit Publicist, 1405246, Rob Harris
  Editing, Dialogue Editor, 1405382, Chris Hogan
  Sound, ADR & Dubbing, 1405814, Jessica Gallavan
  Sound, Sound Effects Editor, 1406390, Dan Hegeman
  Editing, Dialogue Editor, 1408779, David A. Cohen
  Sound, Sound Effects Editor, 1423757, Scott Sanders
  Crew, CG Supervisor, 1425484, Laurent Hugueniot
  Sound, Music Editor, 1433743, Vicki Hiatt
  Costume & Make-Up, Hairstylist, 1445469, Aaron F. Quarles
  Costume & Make-Up, Hairstylist, 1464513, Barbara De Leonardis
  Art, Art Department Coordinator, 1464515, Susan Maye
  Crew, Property Master, 1464516, Douglas T. Madison
  Art, Construction Coordinator, 1464517, Richard Blankenship
  Crew, Visual Effects Editor, 1464518, Nicholas Atkinson
  Visual Effects, Visual Effects Producer, 1464519, Emma Norton
  Lighting, Gaffer, 1464520, Alberico Novelli
  Lighting, Rigging Gaffer, 1464521, Richie Ford
  Costume & Make-Up, Set Costumer, 1464522, Linda M. Boyland
  Crew, Picture Car Coordinator, 1464523, Mike Barbour
  Crew, Transportation Coordinator, 1464524, Bob Foster
  Lighting, Gaffer, 1597990, Daniele Botteselle

Titulo: White Squall
Id: 10534
Fecha Emision: 1996-02-02
Presupuesto: 10300000
Ingresos: 38000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Executive Producer, 578, Ridley Scott
  Editing, Editor, 9163, Gerry Hambling
  Writing, Screenplay, 16829, Todd Robinson
  Production, Producer, 17398, Mimi Polk Gitlin
  Camera, Director of Photography, 22100, Hugh Johnson
  Production, Producer, 27148, Rocky Lang
  Sound, Original Music Composer, 59472, Jeff Rona
  Writing, Novel, 65546, Charles Gieg Jr.
  Writing, Novel, 65547, Felix Sutton

Titulo: Legend
Id: 11976
Fecha Emision: 1985-07-19
Presupuesto: 15502112
Ingresos: 25000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Producer, 376, Arnon Milchan
  Directing, Director, 578, Ridley Scott
  Sound, Original Music Composer, 1760, Jerry Goldsmith
  Editing, Editor, 5056, Terry Rawlings
  Writing, Writer, 9167, William Hjortsberg
  Camera, Director of Photography, 21516, Alex Thomson
  Production, Co-Producer, 57241, Tim Hampton
  Production, Executive Producer, 71144, Joseph P. Grace
  Costume & Make-Up, Makeup Effects Designer, 101608, Rob Bottin
  Art, Production Design, 589936, Assheton Gorton
  Sound, Music, 942947, Tangerine Dream

Titulo: Body of Lies
Id: 12113
Fecha Emision: 2008-10-10
Presupuesto: 113280098
Ingresos: 70000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Casting, 474, Jina Jay
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Production, Casting, 2952, Avy Kaufman
  Art, Supervising Art Director, 5673, Marco Trentini
  Camera, Steadicam Operator, 8673, Daniele Massaccesi
  Crew, Dialect Coach, 13050, Tim Monich
  Sound, Sound Effects Editor, 13166, Dino Dimuro
  Sound, Sound Effects Editor, 14764, Christopher Assells
  Sound, Supervising Sound Editor, 14765, Per Hallberg
  Camera, Director of Photography, 17649, Alexander Witt
  Art, Set Decoration, 20507, Sonja Klaus
  Art, Art Direction, 23453, Robert Cowper
  Writing, Screenplay, 34510, William Monahan
  Production, Executive Producer, 40374, Michael Costigan
  Visual Effects, Visual Effects Producer, 42291, Jacquie Barnbrook
  Art, Supervising Art Director, 56697, Charley Beal
  Lighting, Gaffer, 57600, Robert Steadman
  Production, Producer, 58470, Donald De Line
  Crew, Dialect Coach, 59040, Judy Dickerson
  Camera, Camera Operator, 59370, David Insley
  Sound, Music, 63421, Marc Streitenfeld
  Writing, Novel, 71311, David Ignatius
  Writing, Screenplay, 71311, David Ignatius
  Production, Line Producer, 77511, Zakaria Alaoui
  Production, Executive Producer, 77512, Charles J.D. Schlissel
  Art, Art Direction, 77513, Alessandro Santucci
  Crew, Dialect Coach, 83114, Sam Sako
  Crew, Unit Publicist, 91941, Ernie Malik
  Art, Assistant Art Director, 119180, Saverio Sammali
  Costume & Make-Up, Makeup Artist, 142152, Bernadette Mazur
  Camera, Steadicam Operator, 983118, Larry McConkey
  Production, Production Manager, 998152, Lucio Trentini
  Crew, Visual Effects Editor, 1017296, Billy Rich
  Sound, Music Editor, 1049333, Del Spiva
  Crew, Stunt Coordinator, 1074163, G.A. Aguilar
  Visual Effects, Visual Effects Producer, 1169459, Julia Frey
  Camera, Still Photographer, 1177850, François Duhamel
  Crew, Special Effects Coordinator, 1224272, John McLeod
  Costume & Make-Up, Costume Supervisor, 1322137, Clare Spragge
  Costume & Make-Up, Costume Supervisor, 1331895, Abdelkrim Akallach
  Crew, Property Master, 1334779, Brad Einhorn
  Sound, Foley, 1338372, Dan O'Connell
  Editing, Dialogue Editor, 1342658, Frederick H. Stahly
  Sound, Foley, 1367493, John T. Cucci
  Art, Art Department Coordinator, 1387217, Wendy Means
  Directing, Script Supervisor, 1390388, Annie Penn
  Sound, Sound Re-Recording Mixer, 1391571, Bob Beemer
  Art, Assistant Art Director, 1398083, Abdellah Baadil
  Sound, Sound Re-Recording Mixer, 1399141, Michael Minkler
  Art, Set Designer, 1400066, Rich Romig
  Production, Location Manager, 1401599, Christian McWilliams
  Camera, Helicopter Camera, 1403415, David B. Nowell
  Art, Assistant Art Director, 1403698, Antonio Tarolla
  Crew, Post Production Supervisor, 1404205, Teresa Kelly
  Art, Assistant Art Director, 1404208, Monica Sallustio
  Sound, Supervising Sound Editor, 1404212, Karen Baker Landers
  Sound, Sound Effects Editor, 1404217, Peter Staubli
  Camera, Helicopter Camera, 1404244, John Marzano
  Costume & Make-Up, Hairstylist, 1405373, Audrey L. Anzures
  Art, Art Department Coordinator, 1405374, Francesca Birri
  Art, Supervising Art Director, 1405375, Peter J. Hampton
  Art, Set Designer, 1405376, Alex McCarroll
  Art, Construction Foreman, 1405377, Francesco Valento
  Art, Leadman, 1405378, R. Scott Doran
  Art, Leadman, 1405379, Chris Ashley
  Editing, Dialogue Editor, 1405382, Chris Hogan
  Visual Effects, Visual Effects Supervisor, 1405385, Sheena Duggal
  Camera, Camera Operator, 1405388, Alessandro Chiara
  Camera, Camera Operator, 1405389, Ronald Hersey
  Camera, Camera Operator, 1405391, Stefan H. Fritz Hummel
  Camera, Camera Operator, 1405394, Marco Sacerdoti
  Camera, Camera Operator, 1405401, Mark Schmidt
  Editing, Digital Intermediate, 1405419, Nick Monton
  Crew, Transportation Coordinator, 1405420, Gary Shephard
  Crew, Picture Car Coordinator, 1405422, Gary Duncan
  Crew, Picture Car Coordinator, 1405423, Mounir Badia
  Production, Location Manager, 1405427, Carol Flaisher
  Production, Location Manager, 1405428, J. Chan Claggett
  Production, Location Manager, 1405429, Driss Benchhiba
  Art, Construction Coordinator, 1532615, Dan Pemberton
  Lighting, Gaffer, 1553236, Stefano Marino

Titulo: The Duellists
Id: 19067
Fecha Emision: 1977-08-31
Presupuesto: 0
Ingresos: 900000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Directing, Director, 578, Ridley Scott
  Production, Casting, 668, Mary Selway
  Production, Associate Producer, 5054, Ivor Powell
  Writing, Story, 8327, Joseph Conrad
  Production, Producer, 8967, David Puttnam
  Editing, Editor, 22104, Pamela Power
  Sound, Original Music Composer, 33319, Howard Blake
  Camera, Director of Photography, 59955, Frank Tidy
  Costume & Make-Up, Costume Design, 75801, Tom Rand
  Writing, Screenplay, 1073190, Gerald Vaughan-Hughes
  Art, Art Direction, 1370814, Bryan Graves
  Art, Production Design, 1405375, Peter J. Hampton

Titulo: Robin Hood
Id: 20662
Fecha Emision: 2010-05-12
Presupuesto: 310669540
Ingresos: 200000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Production, Producer, 339, Brian Grazer
  Production, Casting, 474, Jina Jay
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Producer, 934, Russell Crowe
  Camera, Director of Photography, 943, John Mathieson
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Writing, Screenplay, 4723, Brian Helgeland
  Art, Set Decoration, 20507, Sonja Klaus
  Camera, Still Photographer, 40796, David Appleby
  Sound, Original Music Composer, 63421, Marc Streitenfeld
  Directing, Script Supervisor, 190914, Elizabeth West
  Sound, Music Editor, 1049333, Del Spiva
  Art, Art Department Coordinator, 1335179, Katie Gabriel
  Sound, Music Editor, 1378722, Joseph Bonn
  Art, Art Department Coordinator, 1400008, Heather Noble

Titulo: Someone to Watch Over Me
Id: 31650
Fecha Emision: 1987-10-09
Presupuesto: 10278549
Ingresos: 17000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Costume & Make-Up, Costume Design, 557, Colleen Atwood
  Directing, Director, 578, Ridley Scott
  Writing, Writer, 2357, Howard Franklin

Titulo: Prometheus
Id: 70981
Fecha Emision: 2012-05-30
Presupuesto: 403170142
Ingresos: 130000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Producer, 915, David Giler
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Production, Producer, 1723, Walter Hill
  Production, Casting, 2952, Avy Kaufman
  Production, Executive Producer, 8401, Mark Huffam
  Camera, Camera Operator, 8673, Daniele Massaccesi
  Camera, Steadicam Operator, 8673, Daniele Massaccesi
  Sound, Supervising Sound Editor, 15332, Mark P. Stoeckinger
  Sound, Sound Re-Recording Mixer, 16177, Ron Bartlett
  Production, Casting, 16363, Nina Gold
  Art, Set Decoration, 20507, Sonja Klaus
  Costume & Make-Up, Makeup Artist, 25060, Jana Carboni
  Production, Executive Producer, 28974, Damon Lindelof
  Writing, Writer, 28974, Damon Lindelof
  Art, Art Direction, 30463, Paul Inglis
  Art, Art Direction, 34005, Karen Wakefield
  Art, Supervising Art Director, 34513, John King
  Production, Executive Producer, 40374, Michael Costigan
  Crew, Stunt Coordinator, 40713, Rob Inch
  Sound, Original Music Composer, 63421, Marc Streitenfeld
  Costume & Make-Up, Hair Designer, 75081, Nana Fischer
  Art, Assistant Art Director, 80424, Philip Elton
  Crew, Sound Recordist, 113048, Tim Gomillion
  Crew, Sound Recordist, 113089, Dennis Rogers
  Visual Effects, Visual Effects Supervisor, 141483, Jamie Dixon
  Writing, Writer, 564940, Jon Spaihts
  Production, Executive Producer, 1018939, Michael Ellenberg
  Sound, Music Editor, 1049333, Del Spiva
  Art, Art Direction, 1327139, Alex Cameron
  Art, Art Direction, 1327141, Marc Homes
  Art, Assistant Art Director, 1330898, Claudio Campana
  Art, Assistant Art Director, 1335552, Tom Whitehead
  Sound, Foley, 1338372, Dan O'Connell
  Editing, Dialogue Editor, 1352966, Michael Hertlein
  Editing, Dialogue Editor, 1352968, Margit Pfeiffer
  Editing, Dialogue Editor, 1364410, Julie Feiner
  Sound, Foley, 1367493, John T. Cucci
  Sound, Sound Re-Recording Mixer, 1377220, Doug Hemphill
  Visual Effects, Visual Effects Producer, 1377294, Michelle Eisenreich
  Sound, Music Editor, 1378722, Joseph Bonn
  Art, Art Direction, 1385883, Anthony Caron-Delion
  Art, Art Direction, 1388850, Peter Dorme
  Crew, Transportation Coordinator, 1388881, Peter Devlin
  Camera, Camera Operator, 1388899, Gary Spratling
  Costume & Make-Up, Set Costumer, 1389543, Calandra Meredith
  Art, Construction Coordinator, 1390340, Laura Davison
  Art, Art Department Coordinator, 1390344, Sarah Griggs
  Art, Assistant Art Director, 1390349, Tom Weaving
  Art, Assistant Art Director, 1390350, Helen Xenopoulos
  Crew, Scenic Artist, 1390352, James Newell
  Sound, Supervising Sound Editor, 1390353, Victor Ray Ennis
  Visual Effects, Visual Effects Supervisor, 1390357, Trent Claus
  Visual Effects, Visual Effects Supervisor, 1390360, Dick Edwards
  Visual Effects, Visual Effects Supervisor, 1390362, Martin Hill
  Visual Effects, Visual Effects Producer, 1390363, Annette Wullems
  Visual Effects, Visual Effects Producer, 1390364, Allen Maris
  Camera, Still Photographer, 1390366, Kerry Brown
  Lighting, Gaffer, 1390367, Perry Evans
  Camera, Camera Operator, 1390368, Graham Hall
  Camera, Camera Operator, 1390372, David Morgan
  Costume & Make-Up, Costume Supervisor, 1390373, Gordon Harmer
  Costume & Make-Up, Set Costumer, 1390375, Georgiana Sayer
  Costume & Make-Up, Set Costumer, 1390376, Bruno de Santa
  Sound, Music Editor, 1390382, Kirsty Whalley
  Directing, Script Coordinator, 1390384, Amal Baggar
  Crew, Dialect Coach, 1390386, Catherine Charlton
  Production, Location Manager, 1390387, Steve Hart
  Directing, Script Supervisor, 1390388, Annie Penn
  Directing, Script Supervisor, 1390389, Louise Wade
  Art, Conceptual Design, 1405574, David Vyle Levy
  Costume & Make-Up, Hairstylist, 1437620, Peta Dunstall
  Crew, Compositors, 1457935, Michael Queen
  Costume & Make-Up, Hair Designer, 1462918, Enzo Angileri
  Production, Production Coordinator, 1537723, Miranda Marks
  Costume & Make-Up, Makeup Artist, 1537724, Aisling Nairn
  Costume & Make-Up, Hairstylist, 1537725, Nicky Knowles

Titulo: The Counselor
Id: 109091
Fecha Emision: 2013-10-25
Presupuesto: 71009334
Ingresos: 25000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Production, Casting, 2952, Avy Kaufman
  Production, Producer, 6468, Nick Wechsler
  Production, Executive Producer, 8401, Mark Huffam
  Production, Casting, 16363, Nina Gold
  Production, Executive Producer, 22498, Michael Schaefer
  Production, Executive Producer, 40374, Michael Costigan
  Production, Executive Producer, 51736, Cormac McCarthy
  Writing, Writer, 51736, Cormac McCarthy
  Production, Producer, 566958, Paula Mae Schwartz
  Production, Producer, 566962, Steve Schwartz
  Sound, Original Music Composer, 582922, Daniel Pemberton

Titulo: Alien: Covenant
Id: 126889
Fecha Emision: 2017-05-09
Presupuesto: 232380243
Ingresos: 97000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Production, Producer, 915, David Giler
  Writing, Screenplay, 932, John Logan
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Production, Producer, 1723, Walter Hill
  Writing, Characters, 5045, Dan O'Bannon
  Writing, Characters, 5046, Ronald Shusett
  Art, Set Decoration, 6055, Victor J. Zolfo
  Production, Producer, 8401, Mark Huffam
  Art, Art Direction, 9583, Charlie Revai
  Production, Producer, 22498, Michael Schaefer
  Art, Supervising Art Director, 33195, Ian Gracie
  Production, Casting, 51922, Carmen Cuba
  Art, Production Design, 60579, Chris Seagers
  Art, Conceptual Design, 74089, Steve Burg
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Sound, Assistant Sound Editor, 158596, Alex Ferguson
  Writing, Story, 191937, Michael Green
  Writing, Screenplay, 231826, Dante Harper
  Sound, Music, 549315, Jed Kurzel
  Sound, Music Director, 549315, Jed Kurzel
  Costume & Make-Up, Hair Designer, 961143, Lesley Vanderwalt
  Costume & Make-Up, Makeup Designer, 961143, Lesley Vanderwalt
  Costume & Make-Up, Makeup Supervisor, 961143, Lesley Vanderwalt
  Art, Art Direction, 962431, Damien Drew
  Sound, Foley, 1079085, Sue Harding
  Writing, Story, 1155661, Jack Paglen
  Camera, Camera Operator, 1190661, Damian Wyvill
  Crew, In Memory Of, 1247285, Julie Payne
  Costume & Make-Up, Costume Supervisor, 1334493, Sarah Robinson
  Sound, Sound Designer, 1335556, Michael Fentum
  Sound, Music Editor, 1338287, Tony Lewis
  Costume & Make-Up, Costume Supervisor, 1355543, Robyn Elliott
  Camera, Camera Operator, 1357066, P. Scott Sakamoto
  Visual Effects, Visual Effects Supervisor, 1368871, Charley Henley
  Crew, Visual Effects Editor, 1384371, Mark Carr
  Art, Art Direction, 1391711, Jacinta Leong
  Sound, Foley, 1393300, Jack Stew
  Camera, Additional Photography, 1399033, Shaun O'Dell
  Costume & Make-Up, Key Hair Stylist, 1401639, Jennifer Stanfield
  Production, Location Manager, 1401743, Mary Barltrop
  Sound, Sound Designer, 1408373, Oliver Tarney
  Sound, Supervising Sound Editor, 1408373, Oliver Tarney
  Sound, Sound Effects Editor, 1408374, Dillon Bennett
  Lighting, Rigging Gaffer, 1411238, Mark Jefferies
  Camera, Still Photographer, 1418310, Mark Rogers
  Costume & Make-Up, Makeup Artist, 1418802, Tess Natoli
  Sound, ADR & Dubbing, 1432596, Derek Casari
  Crew, Visual Effects Editor, 1444969, Paolo Buzzetti
  Visual Effects, Animation Supervisor, 1453612, Gabriele Zucchelli
  Sound, ADR Supervisor, 1459875, Rachael Tate
  Editing, First Assistant Editor, 1459937, Laurence Johnson
  Crew, Visual Effects Editor, 1461629, Lukasz Bukowiecki
  Visual Effects, Pre-Visualization Supervisor, 1466454, Jason McDonald
  Directing, Script Supervisor, 1470970, Melina Burns
  Art, Assistant Art Director, 1518775, Andrew Chan
  Camera, Camera Operator, 1527926, Matt Toll
  Production, Casting Associate, 1538204, Wittney Horton
  Camera, Steadicam Operator, 1569342, Andrew Johnson
  Visual Effects, Visual Effects Producer, 1574096, Sona Pak
  Directing, Assistant Director, 1578651, Raymond Kirk
  Costume & Make-Up, Hairstylist, 1585743, Lara Jade Birch
  Visual Effects, Visual Effects Producer, 1595166, Tomi Nieminen
  Costume & Make-Up, Hairstylist, 1634542, Rebecca Allen
  Production, Unit Production Manager, 1634544, Dean Hood
  Art, Set Designer, 1634555, Belinda Cusmano
  Art, Conceptual Design, 1634557, Wayne John Haag
  Art, Conceptual Design, 1634558, Dane Hallett
  Art, Conceptual Design, 1634559, Mark Hatton
  Camera, Aerial Director of Photography, 1644252, Peter Beeh
  Production, Researcher, 1649534, Lizzy Jane Klein
  Visual Effects, 2D Supervisor, 1721454, Anthony Smith
  Sound, ADR & Dubbing, 1737654, Judah Getz
  Art, Art Department Coordinator, 1746248, Lauren Wild
  Directing, Script Supervisor, 1746249, Merran Elliot
  Production, Casting Assistant, 1746251, Ebony Hardin
  Camera, Dolly Grip, 1746428, Mal Booth
  Lighting, Gaffer, 1746429, Mark Glindeman
  Lighting, Rigging Grip, 1746430, Theo Thomas
  Camera, Key Grip, 1746431, Toby Copping
  Visual Effects, Animation Supervisor, 1746432, Alexandre Ronco
  Crew, CG Supervisor, 1746433, Alexandre Cancado
  Visual Effects, Creature Technical Director, 1746434, Maxime Cazaly
  Visual Effects, Creature Technical Director, 1746435, Francis Leong
  Visual Effects, Creature Technical Director, 1746436, Will Fife
  Visual Effects, Creature Technical Director, 1746437, Victor Pillet
  Lighting, Lighting Director, 1746438, Boyan Baynov
  Lighting, Lighting Director, 1746439, Spencer Fitch
  Lighting, Lighting Director, 1746440, Britton Plewes
  Lighting, Lighting Director, 1746441, Leonardo Bianchi
  Lighting, Lighting Director, 1746442, Matthieu Paugam
  Lighting, Lighting Director, 1746443, Manjusha Balachandran
  Lighting, Lighting Director, 1746444, Elisabeth Leeb
  Visual Effects, Modeling, 1746445, Manmath Matondkar
  Visual Effects, Modeling, 1746446, Luke Wilding
  Visual Effects, Modeling, 1746447, William Bell
  Visual Effects, Special Effects Supervisor, 1746449, Dan Oliver
  Costume & Make-Up, Assistant Costume Designer, 1746451, Mark Campbell
  Costume & Make-Up, Costume Coordinator, 1746452, Bronwyn Doughty
  Costume & Make-Up, Costume Coordinator, 1746453, Maria Salcher
  Costume & Make-Up, Set Costumer, 1746454, Anna Burstall
  Costume & Make-Up, Set Costumer, 1746455, Ivana Daniele
  Costume & Make-Up, Set Costumer, 1746456, Dan Owen
  Costume & Make-Up, Costume Illustrator, 1746457, Anna Haigh
  Directing, Second Assistant Director, 1805808, Scott Lovelock
  Directing, Third Assistant Director, 1805809, Greg Tynan
  Editing, Additional Editing, 1816348, Cheryl Potter
  Editing, Assistant Editor, 1816349, Justin Tillett
  Production, Location Manager, 1816350, Jeremy Peek
  Sound, Assistant Sound Editor, 1816351, Arabella Winter
  Camera, Camera Operator, 1816353, Ben Ruffell
  Directing, Second Assistant Director, 1816354, Danielle Blake
  Camera, Additional Photography, 1816355, Claire Frayn
  Directing, Third Assistant Director, 1816355, Claire Frayn
  Camera, Additional Photography, 1816356, Sarah Hood
  Directing, Second Assistant Director, 1816356, Sarah Hood
  Directing, Third Assistant Director, 1816357, Matthew Webb
  Art, Set Dresser, 1816358, Dion Boothby
  Art, Set Designer, 1816359, Tony Drew
  Art, Set Designer, 1816360, Andrew Kattie
  Art, Set Designer, 1816361, Kate McCowage
  Art, Set Designer, 1816362, Alasdair Mott
  Crew, Stunt Coordinator, 1830633, Kyle Gardiner

Titulo: Exodus: Gods and Kings
Id: 147441
Fecha Emision: 2014-12-03
Presupuesto: 268031828
Ingresos: 140000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Sound, Music, 405, Alberto Iglesias
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Writing, Screenplay, 2260, Steven Zaillian
  Art, Supervising Art Director, 4710, Benjamín Fernández
  Production, Producer, 8401, Mark Huffam
  Writing, Screenplay, 10704, Jeffrey Caine
  Production, Casting, 16363, Nina Gold
  Sound, Sound Designer, 16683, James Harrison
  Art, Set Decoration, 16995, Pilar Revuelta
  Production, Producer, 22498, Michael Schaefer
  Costume & Make-Up, Hairstylist, 23426, Nicola Buck
  Costume & Make-Up, Makeup Artist, 27205, Luigi Rocchetti
  Production, Producer, 36427, Jenno Topping
  Crew, Stunt Coordinator, 40713, Rob Inch
  Sound, Foley, 40823, Peter Burgis
  Writing, Screenplay, 59265, Adam Cooper
  Writing, Screenplay, 59266, Bill Collage
  Crew, Second Unit Cinematographer, 59528, Flavio Martínez Labiano
  Art, Art Direction, 71577, Matthew Gray
  Costume & Make-Up, Hairstylist, 75081, Nana Fischer
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Visual Effects, Visual Effects Supervisor, 122274, Peter Chiang
  Editing, Digital Intermediate, 134572, James Long
  Production, Producer, 266920, Peter Chernin
  Art, Art Direction, 422701, Luigi Marchione
  Art, Set Decoration, 957666, Celia Bobak
  Lighting, Gaffer, 1002096, José Luis Rodríguez
  Editing, Editor, 1017296, Billy Rich
  Camera, Underwater Camera, 1189807, Tim Wooster
  Art, Art Direction, 1299324, Gavin Fitch
  Art, Art Direction, 1299326, Matt Wynne
  Costume & Make-Up, Costume Supervisor, 1319160, Ken Crouch
  Art, Art Direction, 1327139, Alex Cameron
  Art, Supervising Art Director, 1327141, Marc Homes
  Art, Art Direction, 1331893, Alejandro Fernández
  Crew, Property Master, 1335047, Dennis Wiseman
  Art, Greensman, 1335543, Roger Holden
  Art, Greensman, 1335544, Will Holden
  Sound, Sound Designer, 1335556, Michael Fentum
  Sound, Foley, 1337412, Jason Swanscott
  Sound, Music Editor, 1337420, Robert Houston
  Sound, Music Editor, 1338287, Tony Lewis
  Art, Art Direction, 1340110, Ashley Winter
  Art, Art Direction, 1354916, Ravi Bansal
  Directing, Script Supervisor, 1357600, Julia Chiavetta
  Costume & Make-Up, Hairstylist, 1359989, Denise Kum
  Visual Effects, Visual Effects Supervisor, 1387184, Simon Carr
  Camera, Camera Operator, 1388897, Julian Morson
  Camera, Still Photographer, 1390366, Kerry Brown
  Camera, Camera Operator, 1390368, Graham Hall
  Directing, Script Supervisor, 1390388, Annie Penn
  Visual Effects, Visual Effects Producer, 1392622, Lisa Goldberg
  Sound, Sound Effects Editor, 1393119, Mark Taylor
  Sound, Foley, 1393300, Jack Stew
  Sound, Foley, 1398918, Andrea King
  Visual Effects, Visual Effects Producer, 1398927, Stefan Drury
  Costume & Make-Up, Wigmaker, 1401126, Alex Rouse
  Crew, Visual Effects Editor, 1403467, Xinyi Puah
  Visual Effects, Visual Effects Supervisor, 1403468, Stephan Trojansky
  Camera, Helicopter Camera, 1404244, John Marzano
  Camera, Helicopter Camera, 1405241, Adam Dale
  Crew, Visual Effects Editor, 1406757, Abi Cadogan
  Sound, Sound Designer, 1408373, Oliver Tarney
  Crew, Visual Effects Editor, 1408812, Aled Robinson
  Crew, Unit Publicist, 1408850, Linda Gamble
  Costume & Make-Up, Wigmaker, 1409293, Orlando Bassi
  Production, Location Manager, 1409308, Matt Jones
  Production, Location Manager, 1409858, Félix Rosell
  Costume & Make-Up, Wigmaker, 1411074, Ray Marston
  Crew, Animatronic and Prosthetic Effects, 1411086, Darren Robinson
  Costume & Make-Up, Makeup Department Head, 1414090, Tina Earnshaw
  Crew, Visual Effects Editor, 1417820, Nick Dacey
  Crew, Visual Effects Editor, 1418807, Matthew Ozerski
  Crew, Animatronic and Prosthetic Effects, 1424925, Peter Hawkins
  Art, Art Direction, 1428907, Hayley Easton Street
  Costume & Make-Up, Makeup Artist, 1428914, Jessica Brooks
  Camera, Camera Operator, 1428917, Stefan Stankowski
  Costume & Make-Up, Makeup Artist, 1439132, Nora Robertson
  Crew, Special Effects Coordinator, 1439161, Victoria Stokes
  Production, Location Manager, 1439756, Izaskun Montilla
  Crew, Visual Effects Editor, 1442139, Andrew Edmondson
  Crew, Sequence Supervisor, 1450948, Tim Ledbury
  Crew, Compositors, 1456696, Brian N. Bentley
  Crew, Dialect Coach, 1457374, Roisin Carty
  Crew, Visual Effects Editor, 1458115, Leanne Young
  Production, Producer, 1459846, Mohamed El Raie
  Art, Art Direction, 1459850, Óscar Sempere
  Costume & Make-Up, Hairstylist, 1459851, Carolyn Cousins
  Costume & Make-Up, Hairstylist, 1459852, Sian Miller
  Costume & Make-Up, Hairstylist, 1459853, Pippa Woods
  Costume & Make-Up, Hairstylist, 1459854, Alexis Continente
  Costume & Make-Up, Hairstylist, 1459855, Eva Marieges Moore
  Costume & Make-Up, Makeup Artist, 1459856, Robb Crafer
  Costume & Make-Up, Makeup Artist, 1459857, Audrey Doyle
  Costume & Make-Up, Makeup Artist, 1459858, Kristin Rasch
  Costume & Make-Up, Makeup Artist, 1459859, Matteo Silvi
  Crew, Animatronic and Prosthetic Effects, 1459860, Matthew MacMurray
  Crew, Animatronic and Prosthetic Effects, 1459861, Rubén Serra
  Art, Art Department Coordinator, 1459862, Felicity Hickson
  Art, Assistant Art Director, 1459864, Quinn Robinson
  Art, Assistant Art Director, 1459865, Florian Müller
  Crew, Property Master, 1459866, Juan Aguirre
  Art, Assistant Art Director, 1459867, Philip Gilmore
  Art, Construction Coordinator, 1459870, Sarah Hunt
  Art, Lead Painter, 1459872, Alan Gooch
  Art, Sculptor, 1459873, Mike Jones
  Art, Set Decoration Buyer, 1459874, Elena Machado Hernandez
  Sound, ADR & Dubbing, 1459875, Rachael Tate
  Editing, Dialogue Editor, 1459875, Rachael Tate
  Visual Effects, Animation Director, 1459878, Marlene Chazot
  Visual Effects, Animation Supervisor, 1459879, Paul Chung
  Visual Effects, Animation Supervisor, 1459880, Stafford Lawrence
  Crew, Visual Effects Editor, 1459895, Shawn Broes
  Crew, Visual Effects Editor, 1459896, Lauren Camilleri
  Visual Effects, Visual Effects Producer, 1459897, Pierre Escande
  Visual Effects, Visual Effects Producer, 1459898, Moriah Etherington-Sparks
  Crew, Visual Effects Editor, 1459899, Struan Farquhar
  Visual Effects, Visual Effects Producer, 1459901, Paul Kolsanoff
  Visual Effects, Visual Effects Producer, 1459902, Daniel Matley
  Visual Effects, Visual Effects Producer, 1459905, Charlotte Raffi
  Visual Effects, Visual Effects Producer, 1459906, Jamie Stevenson
  Visual Effects, Visual Effects Producer, 1459909, Abbie Tucker-Williams
  Crew, Visual Effects Editor, 1459910, Garrett Wilson
  Crew, Visual Effects Editor, 1459911, Mark S. Wright
  Visual Effects, Visual Effects Supervisor, 1459912, Asregadoo Arundi
  Visual Effects, Visual Effects Supervisor, 1459913, Jessica Norman
  Crew, Visual Effects Art Director, 1459914, Stefano Trivelli
  Crew, Visual Effects Art Director, 1459915, Claas Henke
  Crew, Sequence Supervisor, 1459917, Jennifer Herbert
  Crew, Sequence Supervisor, 1459921, Tom Rolfe
  Crew, CG Supervisor, 1459922, James Rustad
  Crew, CG Supervisor, 1459923, Tim Zaccheo
  Crew, CGI Supervisor, 1459924, Lukas Lepicovsky
  Crew, CG Supervisor, 1459925, Daniel Pastore
  Camera, Camera Operator, 1459927, David Acereto
  Camera, Camera Operator, 1459929, Al Hindley
  Camera, Camera Operator, 1459930, Imanol Nabea
  Camera, Camera Operator, 1459931, Julio Vallejo
  Camera, Camera Operator, 1459932, Ibon Antuñano
  Camera, Still Photographer, 1459933, Inesa De La Roche
  Costume & Make-Up, Costume Supervisor, 1459935, Cristina Sopeña
  Costume & Make-Up, Set Costumer, 1459936, Amanda Trewin
  Editing, First Assistant Editor, 1459937, Laurence Johnson
  Crew, Transportation Coordinator, 1459938, Andrés Leal Chele
  Crew, Transportation Coordinator, 1459939, Melina Frías
  Crew, Transportation Coordinator, 1459940, Lee David Hollingsworth
  Crew, Transportation Coordinator, 1459941, David Louis Jones
  Crew, Transportation Coordinator, 1459942, Aline Rajan-Harjani
  Production, Location Manager, 1459944, Ahmed Sobhy
  Crew, Actor's Assistant, 1459946, Luis Gamazo
  Production, Casting, 1459947, Sandra Mooney

Titulo: The Martian
Id: 286217
Fecha Emision: 2015-09-30
Presupuesto: 630161890
Ingresos: 108000000
Reparto(Orden, Personaje, Id, Actriz/Actor)
Personal del equipo (Departamento, Trabajo, Id, Nombre)
  Camera, Director of Photography, 120, Dariusz Wolski
  Directing, Director, 578, Ridley Scott
  Production, Producer, 578, Ridley Scott
  Art, Production Design, 944, Arthur Max
  Costume & Make-Up, Costume Design, 946, Janty Yates
  Editing, Editor, 950, Pietro Scalia
  Sound, Original Music Composer, 5553, Harry Gregson-Williams
  Visual Effects, Special Effects Supervisor, 6060, Neil Corbould
  Production, Producer, 8401, Mark Huffam
  Camera, Camera Operator, 8673, Daniele Massaccesi
  Production, Producer, 11092, Simon Kinberg
  Visual Effects, Visual Effects Producer, 15357, Nina Fallon
  Production, Casting, 16363, Nina Gold
  Sound, Sound Effects Editor, 16683, James Harrison
  Production, Producer, 22498, Michael Schaefer
  Art, Art Direction, 23453, Robert Cowper
  Costume & Make-Up, Makeup Artist, 25060, Jana Carboni
  Editing, Digital Intermediate, 32806, Paul Carlin
  Sound, Foley, 40815, Hugo Adams
  Writing, Screenplay, 47506, Drew Goddard
  Production, Casting, 49670, Zsolt Csutak
  Production, Casting, 51922, Carmen Cuba
  Lighting, Gaffer, 75117, Julian White
  Sound, Sound Re-Recording Mixer, 113073, Paul Massey
  Art, Set Decoration, 957666, Celia Bobak
  Art, Art Direction, 962164, Jason Knox-Johnston
  Art, Art Direction, 968805, Mónika Esztán
  Visual Effects, Special Effects Supervisor, 1129208, Steven Warner
  Art, Set Decoration, 1177771, Zoltán Horváth
  Costume & Make-Up, Assistant Costume Designer, 1285933, Michael Mooney
  Art, Art Direction, 1299326, Matt Wynne
  Production, Casting Associate, 1300064, Theo Park
  Visual Effects, Visual Effects Supervisor, 1318830, Sara Bennett
  Production, Executive Producer, 1320090, Aditya Sood
  Art, Supervising Art Director, 1327141, Marc Homes
  Art, Art Direction, 1334420, Phil Sims
  Costume & Make-Up, Costume Supervisor, 1334493, Sarah Robinson
  Sound, Sound Designer, 1335556, Michael Fentum
  Sound, Music Editor, 1338287, Tony Lewis
  Writing, Novel, 1352085, Andy Weir
  Costume & Make-Up, Assistant Costume Designer, 1354914, Richard Sale
  Visual Effects, Visual Effects Producer, 1376804, Clare Norman
  Directing, Script Supervisor, 1379059, Lizzie Pritchard
  Visual Effects, VFX Editor, 1384371, Mark Carr
  Visual Effects, Visual Effects Supervisor, 1384386, Richard Stammers
  Visual Effects, Visual Effects Supervisor, 1386912, Mohen Leo
  Art, Assistant Art Director, 1388860, Matt Sims
  Art, Art Department Coordinator, 1392588, Éva Zöld
  Art, Assistant Art Director, 1392589, Annamária Orosz
  Sound, Foley, 1393300, Jack Stew
  Visual Effects, Visual Effects Producer, 1393323, Barrie Hemsley
  Camera, Still Photographer, 1393883, Peter Mountain
  Crew, Property Master, 1398913, Noel Cowell
  Sound, Foley, 1398918, Andrea King
  Camera, Camera Operator, 1399639, László Bille
  Visual Effects, Visual Effects Producer, 1400077, Paula Pope
  Costume & Make-Up, Wigmaker, 1401126, Alex Rouse
  Camera, Helicopter Camera, 1404244, John Marzano
  Sound, Sound Designer, 1408373, Oliver Tarney
  Sound, Supervising Sound Editor, 1408373, Oliver Tarney
  Editing, Digital Intermediate, 1409305, Todd Kleparski
  Costume & Make-Up, Key Hair Stylist, 1411067, Maralyn Sherman
  Visual Effects, Visual Effects Producer, 1411249, Clare Heneghan
  Art, Art Direction, 1411329, Stefan Speth
  Costume & Make-Up, Hair Designer, 1414090, Tina Earnshaw
  Costume & Make-Up, Makeup Designer, 1414090, Tina Earnshaw
  Visual Effects, Visual Effects Supervisor, 1419604, Justin Cornish
  Visual Effects, Visual Effects Supervisor, 1419605, Brooke Lyndon-Stanford
  Crew, CG Supervisor, 1426327, Nicolas Hernandez
  Visual Effects, Visual Effects Producer, 1426846, Priyanka Balasubramanian
  Costume & Make-Up, Makeup Artist, 1427822, Rita Balla
  Visual Effects, Visual Effects Supervisor, 1450948, Tim Ledbury
  Camera, Camera Operator, 1458446, Imre Juhasz
  Sound, ADR & Dubbing, 1459875, Rachael Tate
  Editing, Dialogue Editor, 1459875, Rachael Tate
  Visual Effects, Visual Effects Producer, 1459902, Daniel Matley
  Visual Effects, Visual Effects Supervisor, 1461613, Chris Lawrence
  Crew, Second Unit Cinematographer, 1494566, Mark Patten
  Costume & Make-Up, Costume Supervisor, 1515573, Gábor Homonnay
  Crew, Armorer, 1515635, Péter Behan
  Art, Assistant Art Director, 1518764, Shira Hockman
  Costume & Make-Up, Seamstress, 1533496, Zsofia Laczko
  Production, Casting Associate, 1538204, Wittney Horton
  Sound, Orchestrator, 1544377, Alastair King
  Art, Art Direction, 1548936, László Rajk
  Crew, Carpenter, 1548937, Norbert Alte Fieszl
  Crew, Carpenter, 1548938, Zoltán Harányi
  Art, Assistant Art Director, 1548939, Rhys Ifan
  Art, Assistant Art Director, 1548940, Will Newton
  Art, Assistant Art Director, 1548941, Gergely Rieger
  Sound, Orchestrator, 1548942, David Butterworth
  Sound, Foley, 1548943, Adam Mendez
  Crew, Sound Recordist, 1548945, Tim Maxwell
  Costume & Make-Up, Assistant Costume Designer, 1548948, Bea Merkovits
  Costume & Make-Up, Makeup Artist, 1548952, Móni Csomós
  Production, Researcher, 1548953, Dan Clay
  Visual Effects, Animation Supervisor, 1548954, Dale Newton
  Crew, CG Supervisor, 1548957, Gourdal Sebastien
  Crew, CG Supervisor, 1548958, Martin Waters
  Crew, CG Supervisor, 1548959, Louis Paré
  Visual Effects, VFX Production Coordinator, 1548960, Fausto Appiolaza
  Visual Effects, VFX Supervisor, 1548961, James D. Fleming
  Visual Effects, Visual Effects Supervisor, 1548962, Anders Langlands
  Lighting, Gaffer, 1563261, Krisztián Paluch
  Visual Effects, Color Designer, 1567986, Dogu Abaris
------------------------------------------------------------------------
BUILD SUCCESS
------------------------------------------------------------------------
Total time:  14.437 s
Finished at: 2023-12-22T11:58:13+01:00
------------------------------------------------------------------------
