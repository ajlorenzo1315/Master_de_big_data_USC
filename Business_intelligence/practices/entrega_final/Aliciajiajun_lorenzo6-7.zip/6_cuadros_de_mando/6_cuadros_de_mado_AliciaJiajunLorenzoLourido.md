## Pentaho

![Alt text](cuadro_de_comados_1.png)
![Alt text](cuadro_de_comados_2.png)

## Tableu
conexión con Tableu